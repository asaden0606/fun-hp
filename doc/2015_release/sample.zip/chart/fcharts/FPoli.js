"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');



class FPoli extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fpoli";
    }

    draw(g)
    {
        var poliPlus1Data = g.parsePoliData(this.rawData,1,"avgMids");
        var poliPlus2Data = g.parsePoliData(this.rawData,2,"avgMids");
        var poliMinus1Data = g.parsePoliData(this.rawData,-1,"avgMids");
        var poliMinus2Data = g.parsePoliData(this.rawData,-2,"avgMids");

        g.setLinesStyle("poli");
        g.drawLines(poliPlus1Data);
        g.drawLines(poliPlus2Data);
        g.drawLines(poliMinus1Data);
        g.drawLines(poliMinus2Data);
    }
}


module.exports = FPoli;