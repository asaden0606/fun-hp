"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');


class FMa3 extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fma3";
    }

    draw(g)
    {
        var avgLngstData = g.parseAvarageData(this.rawData,"avgLongests");
        g.setLinesStyle("sma-lngst");
        g.drawLines(avgLngstData);
    }
}

module.exports = FMa3;