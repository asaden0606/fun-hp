"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');


class FMa0 extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fma0";
    }

    draw(g)
    {
        var avgSrtData = g.parseAvarageData(this.rawData,"avgShorts");
        g.setLinesStyle("sma-srt");
        g.drawLines(avgSrtData);
    }
}

module.exports = FMa0;