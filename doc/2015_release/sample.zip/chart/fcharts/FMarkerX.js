"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');
var d3 = require('d3');


class FMarkerX extends FChartBase
{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fmarker";
    }



    draw(g)
    {
        var xMarkerData = g.parseXMarkerData(this.rawData);
        var markerDate = this.markerDate = this.param["marker"];
        var parseDate = d3.timeParse("%d-%b-%y");
        if(markerDate !== null)
        {
            xMarkerData.push(
                    {
                        value:parseDate(markerDate)
                    }
               );
        }

        g.drawMarkerX(xMarkerData);
    }
}


module.exports = FMarkerX;