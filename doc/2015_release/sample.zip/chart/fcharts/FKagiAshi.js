"use strict";

var GraphicsPopup = require('../GraphicsPopup');
var PointFigure = require('../charts/KagiAshi');


class FKagiAshi extends PointFigure{

    getData(g)
    {
        return this.data;
    }

    getGraphic(layout)
    {
        var g = new GraphicsPopup(
                layout,
                this.getChartID(),
                0.1,
                0.0,
                0.4,
                0.6,
                GraphicsPopup.LEFT_FIX,
                GraphicsPopup.CENTER_FIX
             );
        g.drawBackground();
        g.setDrawAxisTopFlag(false);
        g.setDrawAxisLeftFlag(false);


        return g;
    }
}

module.exports = FKagiAshi;

