"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');

class FTrendline extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "trend";
    }

    draw(g)
    {
        var trendlineData = g.parseTrendlineData(this.rawData);
        g.drawTrendline(trendlineData);
    }
}

module.exports = FTrendline;