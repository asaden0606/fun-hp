"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');
var FGraphics = require('../FGraphics');
var d3 = require('d3');

class FVolume extends FChartBase
{
    Candle()
    {
    }

    getGraphic(layout)
    {
        var g = new FGraphics(
                        layout,
                        ChartBase.VOLUME_GRAPHIC,
                        2);

        g.setAxisFormatY(d3.format(",.3s"));

        return g;
    }

    getChartID()
    {
        return "volume";
    }

    draw(g)
    {
        g.setDomainY(g.volume2domainY(this.data));
        g.drawVolumes(this.data);
    }
}

module.exports = FVolume;