"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');

class FTradeArrow extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "trade";
    }

    draw(g)
    {
        var arrowData = g.parseArrowData(this.rawData);
        g.drawTradeArrows(arrowData);
    }
}

module.exports = FTradeArrow;