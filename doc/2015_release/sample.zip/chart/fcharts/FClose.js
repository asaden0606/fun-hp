"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');
var FGraphics = require('../FGraphics');
class FClose extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new FGraphics(
                layout,
                ChartBase.PRICE_GRAPHIC,
                10
             );
    }

    getChartID()
    {
        return "close";
    }



    draw(g)
    {
        g.setDomainX(g.candle2domainX(this.data));   //全フレームの中で一回呼び出せばOK
        g.setDomainY(g.candle2domainY(this.data));
        g.drawClose(this.data);
    }
}

module.exports = FClose;