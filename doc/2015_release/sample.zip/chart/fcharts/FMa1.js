"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');


class FMa1 extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fma1";
    }

    draw(g)
    {
        var avgMidData = g.parseAvarageData(this.rawData,"avgMids");
        g.setLinesStyle("sma-mid");
        g.drawLines(avgMidData);
    }
}

module.exports = FMa1;