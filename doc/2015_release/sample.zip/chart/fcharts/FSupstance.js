"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');


class FSupstance extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "sups";
    }

    draw(g)
    {
        var supstanceData = g.parseSupportData(this.rawData);
        g.drawSupstance(supstanceData);
    }
}


module.exports = FSupstance;