"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');

class FMa2 extends FChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "fma2";
    }

    draw(g)
    {
        var avgLngData = g.parseAvarageData(this.rawData,"avgLongs");
        g.setLinesStyle("sma-lng");
        g.drawLines(avgLngData);
    }
}

module.exports = FMa2;