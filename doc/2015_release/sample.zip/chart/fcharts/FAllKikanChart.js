"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');
var GraphicsUtils = require('../utils/GraphicsUtils');
var FGraphics = require('../FGraphics');
var d3 = require('d3');
class FAllKikanChart extends FChartBase{
    constructor()
    {
        super();
        this.fontMap = {};
        this.fontMap["kikan_2"] = "gs";
        this.fontMap["kikan_3"] = "nomura";
        this.fontMap["kikan_4"] = "meriru";
        this.fontMap["kikan_7"] = "amuro";
        this.fontMap["kikan_10"] = "morugan";
    }

    getGraphic(layout)
    {
        return new FGraphics(
                layout,
                ChartBase.PRICE_GRAPHIC,
                10
             );
    }

    getChartID()
    {
        return "all_kikan";
    }


    toLines(data)
    {
        return data.map(function(d){
            return {
                date:d.date,
                value:d.close
            };
        });
    }



    getRange()
    {

        var DEFAULT_MAX =-100000;
        var DEFAULT_MIN =100000;

        var max = DEFAULT_MAX;
        var min = DEFAULT_MIN;

        for(var i = 0; i < this.prices.length; i++)
        {
            var raw = this.prices[i];
            var newMax = d3.max(raw,function(d){return d.close;});
            var newMin = d3.min(raw,function(d){return d.close;});
            max = Math.max(max,newMax);
            min = Math.min(min,newMin);
        }

        if(max === DEFAULT_MAX || min === DEFAULT_MIN)
        {
            return null;
        }

        return [min,max];
    }


    getChecked(itemName)
    {
        var item = document.getElementById(itemName);
        return item.checked;
    }

    draw(g)
    {
        var i;
        this.prices = [];
        for(i = 0; i < this.rawData.length;i++)
        {
            var price = g.parsePrice(this.rawData[i].prices);
            this.prices.push(price);
        }


        var range = this.getRange();
        range = GraphicsUtils.wideRange(range,1.3);


        g.setDomainX(g.candle2domainX(g.parsePrice(this.rawData[0].prices)));
        g.setDomainY(range);


        for(i = 0; i < this.prices.length;i++)
        {
            var raw = this.prices[i];
            var kikanID = "kikan_" + String(this.rawData[i].kikanID);
            var css = "default";
            if(kikanID in this.fontMap)
            {
                css = this.fontMap[kikanID];
            }

            if(this.getChecked(kikanID))
            {
                g.setLinesStyle(css);
                g.drawLines(this.toLines(raw));
            }
        }
    }
}

module.exports = FAllKikanChart;