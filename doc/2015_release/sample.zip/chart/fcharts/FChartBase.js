"use strict";

var ChartBase = require('../charts/ChartBase');

class FChartBase extends ChartBase{
    construnctor()
    {
    }


    setRawData(inRawData)
    {
        this.rawData = inRawData;
    }

    setParam(inParam)
    {
        this.param = inParam;
    }
}

module.exports = FChartBase;