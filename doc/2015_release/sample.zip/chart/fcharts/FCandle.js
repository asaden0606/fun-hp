"use strict";
var ChartBase = require('../charts/ChartBase');
var FChartBase = require('./FChartBase');
var GraphicsUtils = require('../utils/GraphicsUtils');
var FGraphics = require('../FGraphics');

class FCandle extends FChartBase{

    getGraphic(layout)
    {
        return new FGraphics(
                layout,
                ChartBase.PRICE_GRAPHIC,
                10
             );
    }

    getChartID()
    {
        return "candle";
    }



    draw(g)
    {
        g.setDomainX(g.candle2domainX(this.data));
        var yRange = g.candle2domainY(this.data);
        yRange = GraphicsUtils.wideRange(yRange,1.1);
        g.setDomainY(yRange);
        g.drawCandles(this.data);
    }
}

module.exports = FCandle;