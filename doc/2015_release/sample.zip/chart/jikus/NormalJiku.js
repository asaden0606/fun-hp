/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


var JikuBase = require('./JikuBase');
var d3 = require('d3');

/**
 * 通常の軸クラス
 */
class NormalJiku extends JikuBase
{
    action(domains)
    {
        return domains;
    }

    setTicks(axis)
    {
        axis.ticks(10);
    }

    getScale()
    {
        return d3.scaleLinear();
    }
}

module.exports = NormalJiku;