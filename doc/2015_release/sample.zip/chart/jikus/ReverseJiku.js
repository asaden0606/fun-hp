/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


var JikuBase = require('./JikuBase');
var d3 = require('d3');
/**
 * 反転の軸クラス
 */
class ReverseJiku extends JikuBase
{
    action(domains)
    {
        return [domains[1],domains[0]];
    }


    /**
     * techanのバグ対応
     * これがないと、株価軸反転時、表示がおかしくなる
     * techanがバージョンアップしてバグが直った場合、本メソッドを削除して
     */
    modifyCandles(svg)
    {
        var modifys = [
            "path.candle.body.up",
            "path.candle.body.down",
        ];

        var change = [
            "candle a body down",
            "candle a body up",
        ];


        var parent = svg.select("g.candlestick").select("g.data");
        var parentNode = parent.node();
        var i;
        var child;
        for(i = 0; i < modifys.length;i++)
        {
            child = parent.select(modifys[i]);
            child.attr("class","tmp" + i);
        }

        for(i = 0; i < modifys.length;i++)
        {
            child = parent.select("path.tmp" + i);
            child.attr("class",change[i]);
        }

        for(i = 0; i < modifys.length;i++)
        {
            child = parent.select(modifys[i]);
            var childNode = child.node();
            if(childNode !== null)
            {
                parentNode.removeChild(childNode);
                parentNode.appendChild(childNode);
            }
        }
    }


    setTicks(axis)
    {
        axis.ticks(10);
    }

    getScale()
    {
        return d3.scaleLinear();
    }
}

module.exports = ReverseJiku;