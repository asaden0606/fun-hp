/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

/**
 * 軸データを管理する基底クラス
 */
class JikuBase
{
    action()
    {

    }

    modifyCandles()
    {

    }

    setTicks()
    {
    }

    getScale()
    {

    }
}

module.exports = JikuBase;