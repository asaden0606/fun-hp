/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

const dummy = 50; // 既存ソースから流用したオシレータのデフォルト値

/**
 * オシレーター Oscillator
 */
class OSI extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "osi";
    }

    _sample2OSI(samples) {
        var high = Number.MIN_VALUE;
        var low  = Number.MAX_VALUE;

        for (var i=0; i<samples.length; i++) {
            var d = samples[i];
            if (d.close > 0) {
                high = Math.max(high, d.high);
                low  = Math.min(low,  d.low);
            }
        }

        var bottom = samples[samples.length - 1];
        var value = dummy;
        if (low < high) {
            value = (high - bottom.close) / (high - low) * 100;
        }

        return {
            date: bottom.date,
            value: value
        };
    }

    createOSI(kikan)
    {
        var result = [];
        var samples = [];

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var osi = this._sample2OSI(samples);
                if(osi !== null)
                {
                    result.push(osi);
                }
            }
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_osi");
        var osi = this.createOSI(kikan);

        //グラフ描画
        g.setDomainY([0,100]);

        this.options.setTypesOfAnalyticsData("osi", osi);
        g.setLinesStyle("osi");
        g.drawLines(osi);

        var unit = this.options.getUnit();
        g.drawTitle("オシレーター(" + kikan + unit + ")");

        //最後の値
        var last = osi[osi.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = OSI;