/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";

var ChartBase = require('./ChartBase');
var CreateAvgBase = require('../utils/CreateAvgBase');

/**
 * 高値平均を生成するクラス
 */
class CreateHighAvg extends CreateAvgBase
{
    toArray(data)
    {
        return [data.high];
    }

    toValue(date,array)
    {
        return {
            date:date,
            value:array[0]
        };
    }
}

/**
 * 安値平均を生成するクラス
 */
class CreateLowAvg extends CreateAvgBase
{
    toArray(data)
    {
        return [data.low];
    }

    toValue(date,array)
    {
        return {
            date:date,
            value:array[0]
        };
    }
}



/**
 * 高値・安値移動平均を表示するクラス
 */
class HighLowAvg extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "high_low_avg";
    }

    draw(g)
    {
        var hla = Number(this.options.get("txt_hla"));

        var createHigh = new CreateHighAvg();
        var highLine = createHigh.create(this.data,hla);
        this.options.setTypesOfAnalyticsData("high_avg", highLine);
        g.setLinesStyle("high_avg");
        g.drawLines(highLine);

        var createLow = new CreateLowAvg();
        var lowLine = createLow.create(this.data,hla);
        this.options.setTypesOfAnalyticsData("low_avg", lowLine);
        g.setLinesStyle("low_avg");
        g.drawLines(lowLine);
    }
}

module.exports = HighLowAvg;