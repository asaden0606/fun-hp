/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModoriBase = require('./ModoriBase');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 戻り（終値）を表示するクラス
 */
class ModoriOwari extends ModoriBase
{
    constructor()
    {
        super();
    }

    getChartID()
    {
        return "ModoriOwari";
    }

    /**
     * 戻り（終値）の最大値・最小値は終値を基準
     */
    getMinMax(innerData)
    {
        var min = GraphicsUtils.min(innerData,function(d){return d.close;});
        var max = GraphicsUtils.max(innerData,function(d){return d.close;});

        return [min,max];
    }
}

module.exports = ModoriOwari;