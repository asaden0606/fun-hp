/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 強弱レシオ (AB Ratio)
 */
class ABRatio extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "abratio";
    }


    _sample2ABR(samples)
    {
        var aStrong = 0; // 強エネルギー（当日の高値 - 当日の始値）
        var aWeak = 0;   // 弱エネルギー（当日の始値 - 当日の安値）
        var bStrong = 0; // 強エネルギー（当日の高値 - 前日の終値）
        var bWeak = 0;   // 弱エネルギー（前日の終値 - 当日の安値）

        var old = samples[0];

        for(var i=1; i<samples.length; i++) {
            let d = samples[i];
            if (d.close > 0) {
                aStrong += d.high - d.open;
                aWeak += d.open - d.low;

                bStrong += d.high - old.close;
                bWeak += old.close - d.low;
            }

            old = d;
        }

        var aRatio = aStrong / aWeak * 100;
        var bRatio = bStrong / bWeak * 100;

        var bottom = samples[samples.length - 1];

        return {
            date: bottom.date,
            aRatio: aRatio,
            bRatio: bRatio
        };
    }

    createABR(kikan)
    {
        var samples = [];
        var aLine = []; // Aレシオ(強人気)
        var bLine = []; // Bレシオ(弱人気)

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var abr = this._sample2ABR(samples);
                if(abr !== null)
                {
                    aLine.push({date: abr.date, value: abr.aRatio});
                    bLine.push({date: abr.date, value: abr.bRatio});
                }
            }
        }

        return {
            aLine: aLine,
            bLine: bLine
        };
    }


    draw(g)
    {
        const kikan = +this.options.get("txt_abr");

        //データ生成
        var abr = this.createABR(kikan);
        var amax = Math.max.apply(Math, abr.aLine.map((d) => d.value));
        var amin = Math.min.apply(Math, abr.aLine.map((d) => d.value));
        var bmax = Math.max.apply(Math, abr.bLine.map((d) => d.value));
        var bmin = Math.min.apply(Math, abr.bLine.map((d) => d.value));
        var max = Math.max(amax, bmax);
        var min = Math.min(amin, bmin);


        //グラフ描画
        g.setDomainY([min,max]);

        this.options.setTypesOfAnalyticsData("abr1", abr.aLine);
        g.setLinesStyle("abr1");
        g.drawLines(abr.aLine);

        this.options.setTypesOfAnalyticsData("abr2", abr.bLine);
        g.setLinesStyle("abr2");
        g.drawLines(abr.bLine);


        var unit = this.options.getUnit();
        g.drawTitle("強弱レシオ(" + kikan + unit + ")");

        //最後の値
        var last = abr.bLine[abr.bLine.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = ABRatio;