/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 順位相関指数 RCI (Rank Correlation Index)
 */
class RCI extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "rci";
    }


    _sample2RCI(samples)
    {
        var d = 0; // (日付順位 - 価格) 2乗 の合計用
        var ranking = samples.slice(); // 価格順位

        ranking.sort((b, a) => a.close - b.close); // 価格降順ソート

        for (var i=0, j=samples.length; i<samples.length; i++, j--) {
            var data = samples[i];
            var rank = ranking.findIndex((a) => +a.date === +data.date);

            d += (rank - j) * (rank - j);
        }

        var n = samples.length; // 期間
        var d6 = 6 * d;
        var nnn = n * (n*n - 1);
        return {
            date: samples[n - 1].date,
            value: (1 - (d6 / nnn)) * 100
        };
    }

    createRCI(kikan)
    {
        var result = [];
        var samples = [];
        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var addSample = this._sample2RCI(samples);
                if(addSample !== null)
                {
                    result.push(addSample);
                }
            }
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_rci");
        if (kikan < 2) {
            return; // 何も描画しない
        }

        var rci = this.createRCI(kikan);

        this.options.setTypesOfAnalyticsData("rci", rci);

        //グラフ描画
        g.setDomainY([-100,100]);
        g.drawColorBands( 50,  100, 'up-down-band');
        g.drawColorBands(-50, -100, 'up-down-band');
        g.setLinesStyle("rci");
        g.drawLines(rci);

        var unit = this.options.getUnit();
        g.drawTitle("RCI(" + kikan + unit + ")");

        //最後の値
        var last = rci[rci.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }


}

module.exports = RCI;