/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var d3 = require('d3');

/**
 * 出来高を表示するクラス
 */
class Volume extends ChartBase
{
    Candle()
    {
    }

    getGraphic(layout)
    {
        var g =  new Graphics(
                      layout,
                      ChartBase.VOLUME_GRAPHIC,
                      3
              );

        g.setAxisFormatY(d3.format(",.3s"));

        return g;
    }

    getChartID()
    {
        return "volume";
    }

    draw(g)
    {
        this.options.setTypesOfAnalyticsData("volume", this.data);

        g.setDomainY(g.volume2domainY(this.data));
        g.drawVolumes(this.data);
    }
}


module.exports = Volume;
