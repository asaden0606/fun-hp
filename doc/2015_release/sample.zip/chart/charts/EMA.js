/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * EMA (指数平滑移動平均) Exponential Moving Average
 */
class EMA extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "ema";
    }

    draw(g)
    {
        var kikan1 = +this.options.get("txt_ema1");
        var kikan2 = +this.options.get("txt_ema2");
        var ema1 = g.createEma(kikan1, this.data);
        var ema2 = g.createEma(kikan2, this.data);

        this.options.setTypesOfAnalyticsData("ema1", ema1);
        g.setLinesStyle("ema1");
        g.drawLines(ema1);

        this.options.setTypesOfAnalyticsData("ema2", ema2);
        g.setLinesStyle("ema2");
        g.drawLines(ema2);
    }
}

module.exports = EMA;