/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 移動平均線1を表示するクラス
 */
class Ma1 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }


    getChartID()
    {
        return "ma-1";
    }


    draw(g)
    {
        var avgParam = Number(this.options.get("txt_ma1"));
        g.setLinesStyle("ma-1");

        var sma = g.createSma(avgParam, this.data);

        this.options.setTypesOfAnalyticsData("ma-1", sma);

        g.drawLines(sma);
    }
}

module.exports = Ma1;