**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * ROC(Rate of Change)
 */
class ROC extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "roc";
    }

    createROC(kikan)
    {
        var result = [];

        for(var i = 0; i < this.data.length; i++)
        {
            // モメンタム＝当日の終値 / N日前の終値
            var bottom = this.data[i];
            var prev = this.data[i - kikan];

            if (!prev || bottom.close === 0 || prev.close === 0) {
                continue;
            }

            result.push({
                date: bottom.date,
                value: bottom.close / prev.close
            });
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_roc");
        if (kikan < 1) {
            return; // 何も描画しない
        }

        var roc = this.createROC(kikan);
        var max = Math.max.apply(Math, roc.map((d) => d.value));
        var min = Math.min.apply(Math, roc.map((d) => d.value));

        this.options.setTypesOfAnalyticsData("roc", roc);

        //グラフ描画
        g.setLinesStyle("roc");
        g.setDomainY([min, max]);
        g.drawLines(roc);

        var unit = this.options.getUnit();
        g.drawTitle("ROC(" + kikan + unit + ")");

        //最後の値
        var last = roc[roc.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = ROC;