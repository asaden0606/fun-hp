/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * モメンタム(Momentum)
 */
class Momentum extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "mom";
    }

    createMomentum(kikan)
    {
        var result = [];

        for(var i = 0; i < this.data.length; i++)
        {
            // モメンタム＝当日の終値 - N日前の終値
            var bottom = this.data[i];
            var prev = this.data[i - kikan];

            if (!prev || bottom.close === 0 || prev.close === 0) {
                continue;
            }

            result.push({
                date: bottom.date,
                value: bottom.close - prev.close
            });
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_mom");
        if (kikan < 1) {
            return; // 何も描画しない
        }

        var momentum = this.createMomentum(kikan);
        var max = Math.max.apply(Math, momentum.map((d) => d.value));
        var min = Math.min.apply(Math, momentum.map((d) => d.value));

        this.options.setTypesOfAnalyticsData("mom", momentum);

        //グラフ描画
        g.setLinesStyle("mom");
        g.setDomainY([min, max]);
        g.drawLines(momentum);

        var unit = this.options.getUnit();
        g.drawTitle("モメンタム(" + kikan + unit + ")");

        //最後の値
        var last = momentum[momentum.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = Momentum;