/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');
var STC = require('./STC');

const znum = 3; // Slow%D を求める為の日数
const dummyD = 50; // 既存ソースから流用した%D のダミー値

/**
 * ストキャスティクススロー Stochastics Slow (slow stochastics)
 */
class STCS extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "stcs";
    }

    createSTCS(kikan)
    {
        var stc, stcC = new STC();
        stcC.setData(this.data);
        stc = stcC.createSTC(kikan);

        var queue = new Array(znum).fill(dummyD); // slow%D計算用の %D 配列
        var sline = []; // slow%D のリスト

        for (var d of stc.dline) {
            queue.push(d.value);
            queue.shift();

            var sum = queue.reduce((a, b) => a + b, 0);
            sline.push({
                date: d.date,
                value: sum / znum
            });
        }

        return {
            dline: stc.dline,
            sline: sline
        };
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_stcs");
        var stcs = this.createSTCS(kikan);

        //グラフ描画
        g.setDomainY([0,100]);
        g.drawColorBands( 0,  25, 'up-down-band');
        g.drawColorBands(75, 100, 'up-down-band');

        this.options.setTypesOfAnalyticsData("stcsd", stcs.dline);
        g.setLinesStyle("stcsd");
        g.drawLines(stcs.dline);

        this.options.setTypesOfAnalyticsData("slowd", stcs.sline);
        g.setLinesStyle("slowd");
        g.drawLines(stcs.sline);

        var unit = this.options.getUnit();
        g.setStringStyle("fixed");
        g.drawTitle("スローストキャスティックス(" + kikan + unit + ")");

        //最後の値
        var last = stcs.sline[stcs.sline.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = STCS;