/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModoriBase = require('./ModoriBase');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 戻り（ザラ場）を表示するクラス
 */
class ModoriZaraba extends ModoriBase
{
    constructor()
    {
        super();
    }

    getChartID()
    {
        return "ModoriZaraba";
    }

    /**
     * 戻り（ザラ場）の最大値・最小値はザラ場を基準
     */
    getMinMax(innerData)
    {
        var min = GraphicsUtils.min(innerData,function(d){return d.low;});
        var max = GraphicsUtils.max(innerData,function(d){return d.high;});

        return [min,max];
    }
}

module.exports = ModoriZaraba;