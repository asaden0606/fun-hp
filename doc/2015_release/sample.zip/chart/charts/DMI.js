/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * DMI（方向性指数）Directional Movement Index
 */
class DMI extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "dmi";
    }


    _sample2DMI(samples)
    {
        var dmp = 0;  // プラスの Directional Movement
        var dmm = 0;  // マイナスの Directional Movement
        var tr = 0;   // 値幅 True Range
        var diffHigh; // 当日の高値から前日の高値を引いた差
        var diffLow;  // 前日の安値から当日の安値を引いた差
        var old = samples[0];

        for(var i=1; i<samples.length; i++) {
            let d = samples[i];
            if (d.close > 0) {
                diffHigh = d.high - old.high;
                diffLow = old.low - d.low;

                if (diffHigh >= diffLow) {
                    dmp += diffHigh;
                } else {
                    dmm += diffLow;
                }

                // TR(True Range) は以下３つの値幅の最大値
                // 当日の高値と安値の差
                // 当日の高値と前日の終値の差
                // 当日の安値と前日の終値の差
                var _tr = d.high - d.low;
                _tr = Math.max(_tr, d.high - old.close);
                _tr = Math.max(_tr, d.low  - old.close);
                tr += _tr;

                old = d;
            }
        }

        var bottom = samples[samples.length - 1];

        return {
            date: bottom.date,
            dmp: dmp / tr * 100,
            dmm: dmm / tr * 100
        };
    }

    createDMI(kikanDI, kikanADX)
    {
        var samples = [];
        var dmis = [];
        var dmpLine = [];
        var dmmLine = [];
        var adxLine = [];

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikanDI < samples.length )
            {
                samples.shift();
            }

            if (kikanDI  === samples.length) {
                var dmi = this._sample2DMI(samples);
                if(dmi !== null)
                {
                    dmpLine.push({date: dmi.date, value: dmi.dmp});
                    dmmLine.push({date: dmi.date, value: dmi.dmm});


                    dmis.push(dmi);
                    if (kikanADX < dmis.length) {
                        dmis.shift();
                    }

                    if (kikanADX === dmis.length) {
                        var adx = this.createADX(dmis);
                        dmi.adx = adx;
                        adxLine.push({date: dmi.date, value: dmi.adx});
                    }
                }
            }
        }

        return {
            dmpLine: dmpLine,
            dmmLine: dmmLine,
            adxLine: adxLine
        };
    }

    createADX(dmis) {
        var dx = 0;

        for(var i = 0; i < dmis.length; i++)
        {
            var dmi = dmis[i];
            dx += Math.abs((dmi.dmp - dmi.dmm) / (dmi.dmp + dmi.dmm));
        }

        return dx / dmis.length * 100;
    }

    draw(g)
    {
        const kikanDI = +this.options.get("txt_dmi");
        const kikanADX = +this.options.get("txt_adx");

        //データ生成
        var result = this.createDMI(kikanDI+1, kikanADX); // +1 は前日データが必要なため

        //グラフ描画
        g.setDomainY([0,100]);

        this.options.setTypesOfAnalyticsData("dmi1", result.dmpLine);
        g.setLinesStyle("dmi1");
        g.drawLines(result.dmpLine);

        this.options.setTypesOfAnalyticsData("dmi2", result.dmmLine);
        g.setLinesStyle("dmi2");
        g.drawLines(result.dmmLine);

        this.options.setTypesOfAnalyticsData("adx", result.adxLine);
        g.setLinesStyle("adx");
        g.drawLines(result.adxLine);

        var unit = this.options.getUnit();
        g.drawTitle("DMI(" + kikanDI + unit + ")，ADX(" + kikanADX + unit + ")");

        //最後の値
        var last = result.adxLine[result.adxLine.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = DMI;