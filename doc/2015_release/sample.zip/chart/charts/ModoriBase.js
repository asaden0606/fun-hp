/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var GraphicsUtils = require('../utils/GraphicsUtils');


/**
 * 戻りを表示する基底クラス
 */
class ModoriBase extends ChartBase
{
    constructor()
    {
        super();
        this.isWriteOugonFlag = true;
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    /**
     * 線を描画し、更には価格情報等も書き込む
     */
    drawLine(g,name,left,right,price)
    {
        var screen = g.transY(price);
        var priceText = price.toFixed(2);

        console.log(priceText);


        g.drawLine(left,screen,right - 100,screen);
        g.drawString(priceText + "(" + name + ")",right - 200,screen - 5);
    }

    /**
     * 戻りの最大値・最小値を算出するメソッド
     */
    getMinMax()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    draw(g)
    {
        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();


        var inner = GraphicsUtils.findInnerDatas(left,right,g.getScaleX(),this.data);
        if(inner.length === 0)
        {
            return;
        }


        var minMax = this.getMinMax(inner);
        if(minMax === null)
        {
            return;
        }


        var min = minMax[0];
        var max = minMax[1];

        var ratio1_3 = (min * 1 +  max * 2) / 3;
        var ougon1_3 = (min * 38.2 +  max * 61.8) / 100;
        var half = (min + max) / 2.0;
        var ougon2_3 = (min * 61.8 +  max * 38.2) / 100;
        var ratio2_3 = (min * 2 +  max * 1) / 3;


        var shortLeft = right - 500;
        g.setLineStyle("zaraba");
        g.setStringStyle("zaraba");


        this.drawLine(g,"高値",left,right,max);
        this.drawLine(g,"1/3押",shortLeft,right,ratio1_3);
        this.drawLine(g,"1/2押",shortLeft,right,half);
        this.drawLine(g,"2/3押",shortLeft,right,ratio2_3);
        this.drawLine(g,"安値",left,right,min);

        if(this.isWriteOugonFlag)
        {
            this.drawLine(g,"38.2%押",shortLeft,right,ougon1_3);
            this.drawLine(g,"61.8%押",shortLeft,right,ougon2_3);
        }
    }

    /**
     * 黄金比率を描画するか設定するメソッド
     */
    setIsWriteOugonFlag(flag)
    {
        this.isWriteOugonFlag = flag;
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}

module.exports = ModoriBase;