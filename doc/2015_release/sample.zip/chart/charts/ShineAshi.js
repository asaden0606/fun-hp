/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var GraphicsUtils = require('../utils/GraphicsUtils');


/**
 * 新値足の基底クラス
 */
class ShineAshi extends ChartBase
{
    static get WIDE()
    {
        return 15;
    }

    constructor()
    {
        super();
    }

    /**
     * 新値足情報を生成するメソッド
     */
    createStores(srcDatas)
    {
        var result = [];
        var head = srcDatas[0];
        var next = srcDatas[1];

        var add = new ShineStore(head.date,head.close,next.close);
        add.pushDate(next.date);
        result.push(add);


        for(var i = 2; i < srcDatas.length; i++)
        {
            var data = srcDatas[i];
            this.push(data,result);
        }

        return result;
    }


    /**
     * 新値足情報をshineStoresに追加するメソッド
     */
    push(data,shineStores)
    {
        var currentPrice = data.close;
        var lastStore = shineStores[shineStores.length - 1];
        var tenkan = this.checkTenkan(lastStore,currentPrice,shineStores);
        if(tenkan === -1)
        {
            shineStores.push(lastStore.createRevert(data.date,currentPrice));
        }
        else if(tenkan === 1)
        {
            shineStores.push(lastStore.createSeeq(data.date,currentPrice));
        }
        else
        {
            lastStore.pushDate(data.date);
        }
    }

    /**
     * 転換するか判定するメソッド
     * -1 反転
     *  0 何もしない
     *  1 同じベクトルで追加
     */
    checkTenkan(lastStore,currentPrice,shineStores)
    {
        var newUp =  lastStore.getPeekPrice() < currentPrice;
        var isChange = lastStore.isUp !== newUp;
        if(isChange === false)
        {
            return 1;
        }
        else
        {
            var stores = shineStores.slice(this.sikii);


            if(newUp)
            {
                //下降中の上昇反転時、全てを上回ればOK
                var max = GraphicsUtils.max(stores,function(d){return d.getBeginPrice();});

                //console.log("down=>up,max=" + max + ",cur=" + currentPrice);

                if(max < currentPrice)
                {
                    return -1;
                }

            }
            else
            {
                //上昇中の下降反転時、全てを下回ればOK
                var min = GraphicsUtils.min(stores,function(d){return d.getBeginPrice();});
                //console.log("up=>down,min=" + min + ",cur=" + currentPrice);
                if(currentPrice < min)
                {
                    return -1;
                }
            }
        }

        return 0;
    }

    /**
     * 新値足を文字列化するメソッド
     */
    printString(ShineStores)
    {
        for(var i = 0; i < ShineStores.length; i++)
        {
            var waku = ShineStores[i];
            console.log("Index:" + i + "\n" + waku.toString());
        }
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}


/**
 * 新値足情報を格納するクラス
 */
class ShineStore
{
    constructor(date,inBeginPrice,inPeekPrice)
    {
        this.beginDate = date;
        this.endDate = date;
        this.beginPrice = inBeginPrice;
        this.peekPrice = inPeekPrice;
        this.isUp = inBeginPrice < inPeekPrice;
        this.count = 1;
    }

    /**
     * 本オブジェクトにデータを追加するメソッド
     */
    pushDate(date)
    {
        this.endDate = date;
        this.count++;
    }

    /**
     * 開始時刻を取得するメソッド
     */
    getBeginDate()
    {
        return this.beginDate;
    }

    /**
     * 終了時刻を取得するメソッド
     */
    getEndDate()
    {
        return this.endDate;
    }

    /**
     * 最大価格を取得するメソッド
     */
    getMaxPrice()
    {
        return Math.max(this.beginPrice,this.peekPrice);
    }

    /**
     * 最小価格を取得するメソッド
     */
    getMinPrice()
    {
        return Math.min(this.beginPrice,this.peekPrice);
    }

    /**
     * 上昇か下降かを取得するメソッド
     */
    getIsUp()
    {
        return this.isUp;
    }

    /**
     * ピーク値を取得するメソッド
     */
    getPeekPrice()
    {
        return this.peekPrice;
    }

    /**
     * 開始値を取得するメソッド
     */
    getBeginPrice()
    {
        return this.beginPrice;
    }

    /**
     * 反転情報を生成するメソッド
     */
    createRevert(date,currentPrice)
    {
        var result =  new ShineStore(date,this.beginPrice,currentPrice);
        return result;
    }

    /**
     * 連続情報を生成するメソッド
     */
    createSeeq(date,currentPrice)
    {
        var result =  new ShineStore(date,this.peekPrice,currentPrice);
        return result;
    }



    toString()
    {
        var result = "";
        result += "beginDate:";
        result += this.beginDate;
        result += "\n";

        result += "endDate:";
        result += this.endDate;
        result += "\n";

        result += "count:";
        result += this.count;
        result += "\n";


        result += "isUp:";
        result += this.isUp;
        result += "\n";

        result += "begin:";
        result += this.beginPrice;
        result += "\n";

        result += "peek:";
        result += this.peekPrice;
        result += "\n";

        return result;
    }
}

module.exports = ShineAshi;