/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * ボリンジャーバンド Bollinger Bands
 */
class BBands extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "bbands";
    }

    /**
     * 標準偏差作成
     */
    _sample2StandardDeviation(samples) {
        var sum2Price = 0;  // 期間の価格の２乗の合計
        var sumPrice  = 0;  // 期間の価格の合計
        for (var d of samples) {
            sum2Price += d.close * d.close;
            sumPrice += d.close;
        }

        var val = (samples.length) * sum2Price - (sumPrice * sumPrice);
        var days = samples.length * (samples.length - 1);
        return Math.sqrt(val / days);
    }

    createBBands(g, kikan, sigma1, sigma2) {
        var samples = [];

        var sma = g.createSma(kikan, this.data);
        var upperBB2 = $.extend(true, [], sma);
        var upperBB1 = $.extend(true, [], sma);
        var lowerBB1 = $.extend(true, [], sma);
        var lowerBB2 = $.extend(true, [], sma);

        for(var i = 0, j = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var sd = this._sample2StandardDeviation(samples);
                upperBB2[j].value += sd * sigma2;
                upperBB1[j].value += sd * sigma1;
                lowerBB1[j].value -= sd * sigma1;
                lowerBB2[j].value -= sd * sigma2;
                j++;
            }
        }

        return {
            upperBB2: upperBB2,
            upperBB1: upperBB1,
            sma: sma,
            lowerBB1: lowerBB1,
            lowerBB2: lowerBB2
        };
    }

    draw(g)
    {
        g.drawTitle("ボリンジャーバンド(" + this.options.get("txt_bb") + this.options.getUnit() + ")");
        var sigma1 = +this.options.get("txt_bb1");
        var sigma2 = +this.options.get("txt_bb2");
        var bbands = this.createBBands(g, +this.options.get("txt_bb"), sigma1, sigma2);

        if (sigma1 > 0) {
            g.setLinesStyle("bbandUP1");
            this.options.setTypesOfAnalyticsData("bbandUP1", bbands.upperBB1);
            g.drawLines(bbands.upperBB1);
            g.setLinesStyle("bbandLO1");
            this.options.setTypesOfAnalyticsData("bbandLO1", bbands.lowerBB1);
            g.drawLines(bbands.lowerBB1);
        }

        if (sigma2 > 0) {
            g.setLinesStyle("bbandUP2");
            this.options.setTypesOfAnalyticsData("bbandUP2", bbands.upperBB2);
            g.drawLines(bbands.upperBB2);
            g.setLinesStyle("bbandLO2");
            this.options.setTypesOfAnalyticsData("bbandLO2", bbands.lowerBB2);
            g.drawLines(bbands.lowerBB2);
        }

        g.setLinesStyle("bbandMA");
        this.options.setTypesOfAnalyticsData("bbandMA", bbands.sma);
        g.drawLines(bbands.sma);
    }
}

module.exports = BBands;