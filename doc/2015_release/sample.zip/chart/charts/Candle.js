/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var d3 = require('d3');
/**
 * ローソク足を表示するクラス
 */
class Candle extends ChartBase{
    construnctor()
    {
    }

    /**
     * 価格のGraphicsを新規生成。超重要
     */
    getGraphic(layout)
    {
        var g = new Graphics(
                layout,
                ChartBase.PRICE_GRAPHIC,
                10
        );

        g.setAxisFormatY(d3.format("d"));

        return g;
    }

    getChartID()
    {
        return "candle";
    }

    draw(g)
    {
        g.setDomainY(g.candle2domainY(this.data));

        var chart = this.options.get('rdo_chart');
        if(chart === "bar")
        {
            g.drawBar(this.data);
        }
        else if(chart === "line")
        {
            g.drawClose(this.data);
        }
        else
        {
            g.drawCandles(this.data);
        }
    }
}

module.exports = Candle;