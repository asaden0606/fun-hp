/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * VWAPを表示するクラス
 */
class VWAP extends ChartBase{
    construnctor()
    {
    }

    createVWAP(datas)
    {
        var result = [];
        var sumPrice = 0;
        var sumVolume = 0;

        for(var i = 0; i < datas.length;i++)
        {
            var data = datas[i];

            sumPrice += data.close * data.volume;
            sumVolume += data.volume;

            result.push(
                {
                    date:data.date,
                    value:sumPrice / sumVolume
                }
            );
        }

        return result;
    }

    getGraphic(layout)
    {
        var g =  layout.getGraphic(ChartBase.PRICE_GRAPHIC);

        return g;
    }

    getChartID()
    {
        return "vwap";
    }

    draw(g)
    {
        var vwap = this.createVWAP(this.data);

        this.options.setTypesOfAnalyticsData("vwap", vwap);

        g.setLinesStyle("vwap");
        g.drawLines(vwap);
    }
}

module.exports = VWAP;