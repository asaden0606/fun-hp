/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');

/**
 * 騰落価格を表示するクラス
 */
class TourakuKakaku extends ChartBase{
    constructor()
    {
        super();
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "touraku_kakaku";
    }

    /**
     * 騰落価格データ作成
     */
    buildUpDownPrice(data) {
        var base = data[0].close;

        var udp = data.map((d) => {
            return {
                date: d.date,
                value: d.close - base
            };
        });

        return udp;
    }


    draw(g)
    {
        g.drawTitle("騰落価格");
        //データ生成
        var touraku = this.buildUpDownPrice(this.data);
        console.log(touraku);

        this.options.setTypesOfAnalyticsData("touraku_kakaku", touraku);

        //グラフ描画
        g.setLinesStyle("touraku_kakaku");
        g.setDomainY(g.line2domainY(touraku));
        g.drawLines(touraku);
    }
}

module.exports = TourakuKakaku;