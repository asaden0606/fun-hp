/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');
var StdDev = require('../utils/StdDev');

/**
 * ヒストリカル・ボラリティティ Historical Volatility
 */
class HV extends ChartBase{
    constructor()
    {
        super();
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "hv";
    }


    _sample2HV(samples, sqrtTD)
    {
        var old = samples[0];
        var prevs = []; // 前日比

        for(var i = 1; i < samples.length; i++)
        {
            var data = samples[i];
            if (data.close > 0) {
                var ratio = data.close / old.close;
                prevs.push(ratio);
                old = data;
            }
        }

        var bottom = samples[samples.length - 1];
        var value = StdDev.getStdDev(prevs) * sqrtTD * 100;

        return {
            date: bottom.date,
            value: value
        };
    }

    createHV(kikan, sqrtTD)
    {
        var result = [];
        var samples = [];

        // 前日比が計算に必要なので期間+1する
        kikan++;

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var addSample = this._sample2HV(samples, sqrtTD);
                if(addSample !== null)
                {
                    result.push(addSample);
                }
            }
        }

        return result;
    }

    /**
     * 立会い日数取得
     */
    getTradingDays() {
        var interval = this.options.get("interval");
        if (interval === "y") {
            return 1;
        } else if (interval === "m") {
            return 12;
        } else if (interval === "w") {
            return 52;
        }
        return 250; // 1年間の立会い日数 250～260 を使うことが多い
    }

    draw(g)
    {
        const tradingDays = this.getTradingDays();
        const sqrtTD = Math.sqrt(tradingDays);
        var kikan = +this.options.get("txt_hv");

        //データ生成
        var hv = this.createHV(kikan, sqrtTD);
        var max = Math.max.apply(Math, hv.map((d) => d.value));
        var min = Math.min.apply(Math, hv.map((d) => d.value));

        this.options.setTypesOfAnalyticsData("hv", hv);

        //グラフ描画
        g.setLinesStyle("hv");
        g.setDomainY([min, max]);
        g.drawLines(hv);

        var unit = this.options.getUnit();
        g.drawTitle("ヒストリカリ・ボラティリティ(" + kikan + unit + ")");

        //最後の値
        var last = hv[hv.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = HV;