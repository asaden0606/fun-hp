/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 移動平均線3を表示するクラス
 */
class Ma3 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }


    getChartID()
    {
        return "ma-3";
    }


    draw(g)
    {
        var avgParam = Number(this.options.get("txt_ma3"));
        g.setLinesStyle("ma-3");

        var sma = g.createSma(avgParam, this.data);

        this.options.setTypesOfAnalyticsData("ma-3", sma);

        g.drawLines(sma);
    }
}

module.exports = Ma3;