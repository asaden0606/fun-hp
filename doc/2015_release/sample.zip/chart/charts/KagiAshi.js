/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var GraphicsFullPopup = require('../GraphicsFullPopup');
var GraphicsUtils = require('../utils/GraphicsUtils');


/**
 * カギ足を表示するクラス
 */
class KagiAshi extends ChartBase
{
    static get WIDE()
    {
        return 15;
    }

    constructor()
    {
        super();
    }

    getChartID()
    {
        return "kagi_ashi";
    }

    getGraphic(layout)
    {
        var g= new GraphicsFullPopup(
                layout,
                 this.getChartID()
        );

        return g;
    }

    /**
     * カギ足を生成し、kagiStoresにPushするメソッド
     */
    push(data,kagiStores)
    {
        var currentPrice = data.close;
        if(kagiStores.length === 0)
        {
            kagiStores.push(new KagiStore(data.date,true,currentPrice,this.sikii));
            return;
        }

        var lastStore = kagiStores[kagiStores.length - 1];
        if(lastStore.isTenkan(currentPrice))
        {
            kagiStores.push(lastStore.createRevert(data.date,currentPrice));
        }
        else
        {
            lastStore.push(currentPrice);
        }
    }

    /**
     * カギ足情報を文字列化し、consoleに出力するメソッド
     */
    printString(kagiStores)
    {
        for(var i = 0; i < kagiStores.length; i++)
        {
            var waku = kagiStores[i];
            console.log("Index:" + i + "\n" + waku.toString());
        }
    }

    /**
     * カギ足情報を画面上に表示するメソッド
     */
    printGraphical(g,range,kagiStores)
    {
        g.setDomainX([0,(kagiStores.length + 1)* KagiAshi.WIDE]);
        g.setDomainY(range);

        if(kagiStores.length === 0)
        {
            return;
        }
        var top = kagiStores[0].getBeginPrice();
        var bottom = kagiStores[0].getBeginPrice();
        g.setLineStyle("youten_kagi");

        var lines = [];

        for(var i = 0; i < kagiStores.length;i++)
        {
            var kagi = kagiStores[i];
            var isUp = kagi.getIsUp();
            var peek = kagi.getPeekPrice();
            var begin = kagi.getBeginPrice();
            var x = g.transX(KagiAshi.WIDE * (i + 1));
            var beginY = g.transY(begin);
            var endY = g.transY(peek);

            lines.push({x:x,y:beginY});

            if(isUp)
            {
                if(top < peek)
                {
                    lines.push({x:x,y:g.transY(top)});

                    //陽転転換
                    g.drawLine2(lines);
                    g.setLineStyle("youten_kagi");
                    lines = [];
                    lines.push({x:x,y:g.transY(top)});
                }
            }
            else
            {
                if(peek < bottom)
                {
                    lines.push({x:x,y:g.transY(bottom)});

                    //陰線転換
                    g.drawLine2(lines);
                    g.setLineStyle("inten_kagi");
                    lines = [];
                    lines.push({x:x,y:g.transY(bottom)});
                }
            }

            lines.push({x:x,y:endY});

            if(isUp)
            {
                top = peek;
            }
            else
            {
                bottom = peek;
            }
        }

        g.drawLine2(lines);
    }

    getData(g)
    {
        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();
        var xScale = g.getLayout().getScaleX();
        return GraphicsUtils.findInnerDatas(left,right,xScale,this.data);
    }

    draw(g)
    {
        this.sikii = Number(this.options.get("txt_kagiashi"));
        g.drawTitle("カギ足(" + this.sikii + "%)");
        this.sikii /= 100.0;


        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();
        var xScale = g.getLayout().getScaleX();
        var srcDatas = this.getData(g);
        var min = GraphicsUtils.min(srcDatas,function(d){return d.close;});
        var max = GraphicsUtils.max(srcDatas,function(d){return d.close;});
        var range = GraphicsUtils.wideRange([max,min],1.3);

        var kagiStores = [];
        for(var i = 0; i < srcDatas.length; i++)
        {
            var data = srcDatas[i];
            this.push(data,kagiStores);
        }


        //this.printString(kagiStores);
        this.printGraphical(g,range,kagiStores);
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}

/**
 * カギ足情報クラス
 */
class KagiStore
{
    constructor(date,isUp,inBeginPrice,sikii)
    {
        this.date = date;
        this.beginPrice = inBeginPrice;
        this.peekPrice = inBeginPrice;
        this.isUp = isUp;
        this.count = 1;
        this.sikii = sikii;
    }

    /**
     * カギ足が上に向いているか、下に向いているか
     */
    getIsUp()
    {
        return this.isUp;
    }

    /**
     * カギ足のピーク値
     * 上昇で言うなら、一番高い値。下降で言うなら、一番低い値
     */
    getPeekPrice()
    {
        return this.peekPrice;
    }

    /**
     * カギ足の開始値
     */
    getBeginPrice()
    {
        return this.beginPrice;
    }

    /**
     * 反転情報を生成するメソッド
     */
    createRevert(date,currentPrice)
    {
        var result =  new KagiStore(date,!this.isUp,this.peekPrice,this.sikii);
        result.push(currentPrice);
        return result;
    }

    /**
     * 本オブジェクトにデータを追加するメソッド
     */
    push(current)
    {
        if(this.isTenkan(current))
        {
            return;
        }

        this.count++;

        if(this.isUp === true)
        {
            if(this.peekPrice < current)
            {
                this.peekPrice = current;
            }
        }
        else
        {
            if(current < this.peekPrice)
            {
                this.peekPrice = current;
            }
        }
    }

    /**
     * カギ足を別向きへと転換させるか判定するメソッド
     */
    isTenkan(current)
    {
        if(this.isUp)
        {
            var under = this.peekPrice * (1 - this.sikii);

            return current <= under;
        }
        else
        {
            var over = this.peekPrice * (1 + this.sikii);

            return over <= current;
        }
    }

    /**
     * カギ足を文字列化
     */
    toString()
    {
        var result = "";
        result += "date:";
        result += this.date;
        result += "\n";


        result += "isUp:";
        result += this.isUp;
        result += "\n";

        result += "begin:";
        result += this.beginPrice;
        result += "\n";

        result += "peek:";
        result += this.peekPrice;
        result += "\n";

        result += "count:";
        result += this.count;
        result += "\n";

        return result;
    }
}

module.exports = KagiAshi;