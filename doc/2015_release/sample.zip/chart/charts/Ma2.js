/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 移動平均線2を表示するクラス
 */
class Ma2 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }


    getChartID()
    {
        return "ma-2";
    }


    draw(g)
    {
        var avgParam = Number(this.options.get("txt_ma2"));
        g.setLinesStyle("ma-2");

        var sma = g.createSma(avgParam, this.data);

        this.options.setTypesOfAnalyticsData("ma-2", sma);

        g.drawLines(sma);
    }
}

module.exports = Ma2;