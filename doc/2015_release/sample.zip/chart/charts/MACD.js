/**
 /**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * MACD (Moving Average Convergence/Divergence Trading Method)
 */
class MACD extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "macd";
    }

    draw(g)
    {
        var kikanEMA1 = +this.options.get("txt_ema1");
        var kikanEMA2 = +this.options.get("txt_ema2");
        var kikanSIG = +this.options.get("txt_macd");

        var macd = g.createMACD(kikanEMA1, kikanEMA2, kikanSIG, this.data);

        this.options.setTypesOfAnalyticsData("macd", macd);

        //グラフ描画
        g.setDomainY(g.macd2domainY(macd));
        g.drawMACD(macd);

        var unit = this.options.getUnit();
        g.drawTitle("MACD(" + kikanEMA1 + "-" + kikanEMA2 + unit + ")");

        //最後の値
        var last = macd[macd.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.signal);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.signal.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = MACD;