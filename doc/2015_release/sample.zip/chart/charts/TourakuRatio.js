/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');

/**
 * 騰落レシオを表示するクラス
 */
class TourakuRatio extends ChartBase{
    constructor()
    {
        super();
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "touraku_ratio";
    }

    /**
     * 騰落レシオデータ作成
     */
    buildUpDownRatio(data)
    {
        var base = data[0].close;

        var udr = data.map((d) => {
            return {
                date: d.date,
                value: (d.close - base) / base * 100
            };
        });

        return udr;
    }


    draw(g)
    {
        g.drawTitle("騰落率");
        //データ生成
        var touraku = this.buildUpDownRatio(this.data);
        console.log(touraku);

        this.options.setTypesOfAnalyticsData("touraku_ratio", touraku);

        //グラフ描画
        g.setLinesStyle("touraku_ratio");
        g.setDomainY(g.line2domainY(touraku));
        g.drawLines(touraku);
    }
}

module.exports = TourakuRatio;