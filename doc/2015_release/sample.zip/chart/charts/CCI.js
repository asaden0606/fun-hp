/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * CCI (Commodity Channel Index) 商品チャンネル指数
 */
class CCI extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "cci";
    }

    _sample2CCI(samples)
    {
        var tp;     // 基準値TP(Typical Price) 通常価格 ＝(高値+安値+終値)÷3
        var tpma = 0;
        var md = 0;
        var n = 0;

        samples.forEach((d) => {
            if (d.close > 0) {
                tp = (d.high + d.low + d.close) / 3;
                tpma += tp;
                n++;
            }
        });
        tpma /= n;  // 単純移動平均

        samples.forEach((d) => {
            if (d.close > 0) {
                tp = (d.high + d.low + d.close) / 3;
                md += Math.abs(tp - tpma);
            }
        });
        md /= n;   // 平均偏差MD(Mean Deviation)

        var bottom = samples[samples.length - 1];

        return {
            date: bottom.date,
            value: (tp - tpma) / (0.015 * md)
        };
    }

    createCCI(kikan)
    {
        var result = [];
        var samples = [];

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var addSample = this._sample2CCI(samples);
                if(addSample !== null)
                {
                    result.push(addSample);
                }
            }
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_cci");
        if (kikan < 1) {
            return; // 何も描画しない
        }

        var cci = this.createCCI(kikan);
        var max = Math.max.apply(Math, cci.map((d) => d.value));
        var min = Math.min.apply(Math, cci.map((d) => d.value));

        this.options.setTypesOfAnalyticsData("cci", cci);

        //グラフ描画
        g.setLinesStyle("cci");
        g.setDomainY([min, max]);
        g.drawLines(cci);

        var unit = this.options.getUnit();
        g.drawTitle("CCI(" + kikan + unit + ")");

        //最後の値
        var last = cci[cci.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = CCI;