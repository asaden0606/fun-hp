/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

const dnum = 3; // %D を求める為の日数

/**
 * ストキャスティクス Stochastics (fast stochastics)
 */
class STC extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "stc";
    }


    _sample2STC(samples)
    {
        var high = Number.MIN_VALUE; // 期間中の最高値
        var low  = Number.MAX_VALUE; // 期間中の最安値

        var sumH = 0; // 終値 - 期間中の最安値 の dnum日間合計
        var sumL = 0; // 期間中の最高値 - 期間中の最安値 の dnum日間合計

        for(var i=0; i<samples.length; i++) {
            let d = samples[i];
            if (d.high) high = Math.max(high, d.high);
            if (d.low)  low  = Math.min(low,  d.low);

            if (i >= samples.length-dnum) {
                sumH += d.close - low;
                sumL += high - low;
            }
        }

        var bottom = samples[samples.length - 1];

        return {
            k : (bottom.close - low) / (high - low) * 100,  // %K
            d : sumH / sumL * 100                           // %D
        };
    }

    createSTC(kikan)
    {
        var samples = [];

        var kline = []; // %K のリスト
        var dline = []; // %D のリスト

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var stc = this._sample2STC(samples);
                var bottom = samples[samples.length - 1];
                kline.push({date: bottom.date, value: stc.k});
                dline.push({date: bottom.date, value: stc.d});
            }
        }

        return {
            kline: kline,
            dline: dline
        };
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_stc");
        var stc = this.createSTC(kikan);

        //グラフ描画
        g.setDomainY([0,100]);
        g.drawColorBands( 0,  25, 'up-down-band');
        g.drawColorBands(75, 100, 'up-down-band');

        this.options.setTypesOfAnalyticsData("stck", stc.kline);
        g.setLinesStyle("stck");
        g.drawLines(stc.kline);

        this.options.setTypesOfAnalyticsData("stcd", stc.dline);
        g.setLinesStyle("stcd");
        g.drawLines(stc.dline);

        var unit = this.options.getUnit();
        g.drawTitle("ストキャスティックス(" + kikan + unit + ")");

        //最後の値
        var last = stc.dline[stc.dline.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = STC;