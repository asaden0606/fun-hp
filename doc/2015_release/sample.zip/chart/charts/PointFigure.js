/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";

var ChartBase = require('./ChartBase');
var GraphicsFullPopup = require('../GraphicsFullPopup');
var GraphicsUtils = require('../utils/GraphicsUtils');




/**
 * ポイント＆フィギュアを表示するクラス
 */
class PointFigure extends ChartBase
{
    static get WIDE()
    {
        return 15;
    }

    static get TENKAN()
    {
        return 3;
    }


    constructor()
    {
        super();
    }

    getChartID()
    {
        return "point_figure";
    }

    getGraphic(layout)
    {
        var g= new GraphicsFullPopup(
                layout,
                 this.getChartID()
            );

        return g;
    }

    /**
     * 枠情報を追加するメソッド
     */
    push(data,wakuStores)
    {
        var currentPrice = data.close;
        if(wakuStores.length === 0)
        {
            wakuStores.push(new WakuStore(data.date,true,currentPrice,this.waku));
            return;
        }

        var lastStore = wakuStores[wakuStores.length - 1];
        if(lastStore.isTenkan(currentPrice))
        {
            wakuStores.push(lastStore.createRevert(data.date,currentPrice));
        }
        else
        {
            lastStore.push(currentPrice);
        }
    }

    /**
     * 枠情報を文字列にて表示するメソッド
     */
    printString(wakuStores)
    {
        for(var i = 0; i < wakuStores.length; i++)
        {
            var waku = wakuStores[i];
            console.log("Index:" + i + "\n" + waku.toString());
        }
    }

    /**
     * 湧く情報をGarphicsにて表示するメソッド
     */
    printGraphical(g,range,wakuStores)
    {
        g.setDomainX([0,wakuStores.length * PointFigure.WIDE]);
        g.setDomainY(range);

        var min = range[0];

        var bottomPixel = g.transY(min);
        var topPixel = g.transY(min + this.waku);
        var pixelSize = Math.round(Math.abs(topPixel - bottomPixel));
        g.setStringSize(pixelSize + "px");
        for(var i = 0; i < wakuStores.length; i++)
        {
            var waku = wakuStores[i];
            var x = g.transX(PointFigure.WIDE * i);
            var start = waku.getMin();
            var begin = waku.getBeginIndex(i);
            var end = waku.getEndIndex(i);

            for(var j = begin; j < end; j++)
            {
                var y = g.transY(start + this.waku * j);
                g.drawString(waku.getUpText(),x,y);
            }
        }
    }



    draw(g)
    {
        this.waku = Number(this.options.get("txt_point_and_figure"));
        g.drawTitle("ポイント＆フィギュア(" + this.waku +")" );
        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();
        var xScale = g.getLayout().getScaleX();
        var srcDatas = GraphicsUtils.findInnerDatas(left,right,xScale,this.data);
        var min = GraphicsUtils.min(srcDatas,function(d){return d.close;});
        var max = GraphicsUtils.max(srcDatas,function(d){return d.close;});
        var range = GraphicsUtils.wideRange([max,min],1.3);

        var wakuStores = [];
        for(var i = 0; i < srcDatas.length; i++)
        {
            var data = srcDatas[i];
            this.push(data,wakuStores);
        }

        //this.printString(wakuStores);
        this.printGraphical(g,range,wakuStores);
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}

/**
 * 枠情報クラス
 */
class WakuStore
{
    constructor(date,isUp,inBeginPrice,waku)
    {
        this.date = date;
        this.beginPrice = inBeginPrice;
        this.peekPrice = inBeginPrice;
        this.isUp = isUp;
        this.count = 1;
        this.waku = waku;
    }

    /**
     * 枠を反転させるメソッド
     */
    createRevert(date,currentPrice)
    {
        var result =  new WakuStore(date,!this.isUp,this.peekPrice,this.waku);
        result.push(currentPrice);
        return result;
    }

    /**
     * 枠にデータを追加メソッド
     */
    push(current)
    {
        if(this.isTenkan(current))
        {
            return;
        }

        this.count++;



        if(this.isUp === true)
        {
            if(this.peekPrice < current)
            {
                this.peekPrice = current;
            }
        }
        else
        {
            if(current < this.peekPrice)
            {
                this.peekPrice = current;
            }
        }
    }

    /**
     * 枠を丸めるメソッド
     * 画面表示する際に使う
     */
    toWakuRound(value)
    {
        var result = Math.round(value / this.waku);
        return result * this.waku;
    }

    /**
     * 本オブジェクトの最大値を取得するメソッド
     */
    getMax()
    {
        var result = Math.max(this.beginPrice,this.peekPrice);
        return this.toWakuRound(result);
    }

    /**
     * 本オブジェクトの最小値を取得するメソッド
     */
    getMin()
    {
        var result =  Math.min(this.beginPrice,this.peekPrice);
        return this.toWakuRound(result);
    }

    /**
     * 本オブジェクトの添字の開始位置を取得するメソッド
     */
    getBeginIndex(i)
    {
        return i === 0 || this.isUp === false ? 0: 1;
    }

    /**
     * 本オブジェクトの添字の終了位置を取得するメソッド
     */
    getEndIndex(i)
    {
        var min = this.getMin();
        var max = this.getMax();
        var count = Math.min((max - min) / this.waku,100);
        return i === 0 || this.isUp === true ? count : count - 1;
    }

    /**
     * 画面に表示する文字列を取得するメソッド
     */
    getUpText()
    {
        return this.isUp ? "☓" : "●";
    }

    /**
     * 枠の数を取得するメソッド
     */
    calcWakuCount(current)
    {
        var sub = Math.abs(current - this.peekPrice);
        var result = sub / this.waku;

        return result;
    }

    /**
     * 転換するか判定するメソッド
     */
    isTenkan(current)
    {
        var vectorChange = (this.peekPrice < current) !== this.isUp;
        var wakuOver = PointFigure.TENKAN <= this.calcWakuCount(current);
        var result =  vectorChange === true && wakuOver === true;
        return result;
    }

    /**
     * P&Fを文字列化するメソッド
     */
    toString()
    {
        var result = "";
        result += "date:";
        result += this.date;
        result += "\n";


        result += "isUp:";
        result += this.isUp;
        result += "\n";

        result += "begin:";
        result += this.beginPrice;
        result += "\n";

        result += "peek:";
        result += this.peekPrice;
        result += "\n";

        result += "count:";
        result += this.count;
        result += "\n";

        return result;
    }
}

module.exports = PointFigure;