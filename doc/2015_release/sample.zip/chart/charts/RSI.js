/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * RSIを表示するクラス
 */
class RSI extends ChartBase{
    constructor()
    {
        super();
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "rsi";
    }

    /**
     * サンプル情報からRSIを生成するメソッド
     */
    _sample2RSI(samples)
    {
        if(samples.length === 1)
        {
            return null;
        }

        var sumUp = 0;
        var sumDown = 0;
        var oldData = samples[0];
        for(var i = 1; i < samples.length; i++)
        {
            var data = samples[i];
            var sub = data.close - oldData.close;
            if(0 < sub)
            {
                sumUp += Math.abs(sub);
            }
            else
            {
                sumDown += Math.abs(sub);
            }
            oldData = data;
        }

        var bottom = samples[samples.length - 1];

        return {
            date:bottom.date,
            value: sumUp * 100  / (sumDown + sumUp)
        };
    }

    /**
     * RSIを生成するメソッド
     */
    createRSI(kikan)
    {
        var result = [];
        var samples = [];
        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            var addSample = this._sample2RSI(samples);
            if(samples.length === kikan && addSample !== null)
            {
                result.push(addSample);
            }
        }

        return result;
    }

    draw(g)
    {
        g.drawTitle("RSI(14×5)");

        //データ生成
        this.options.setTypesOfAnalyticsData("rsi", rsi);

        //グラフ描画
        g.setLinesStyle("rsi");
        g.setDomainY([0,100]);
        g.drawColorBands( 0,  25, 'up-down-band');
        g.drawColorBands(75, 100, 'up-down-band');
        var rsi = this.createRSI(Number(this.options.get("txt_rsi")));
        g.drawLines(rsi);
        if(rsi.length === 0)
        {
            return;
        }


        //最後の値
        var last = rsi[rsi.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);


    }
}

module.exports = RSI;