/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 移動平均乖離率 Difference from moving average
 */
class DiffMA extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "diffMA";
    }

    createDiffMA(g, kikan)
    {
        var list = g.createSma(kikan, this.data);
        var index = this.data.findIndex((d) => {
            return +d.date === +list[0].date;
        });

        var i, j;

        for (i=index, j=0; i<this.data.length; i++, j++) {
            var d = this.data[i];
            var ma = list[j].value;

            list[j].value = (d.close - ma) / ma * 100;
        }
        return list;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_dis");
        var list = this.createDiffMA(g, kikan);
        var max = Math.max.apply(Math, list.map((d) => d.value));
        var min = Math.min.apply(Math, list.map((d) => d.value));

        //グラフ描画
        g.setDomainY([min, max]);

        this.options.setTypesOfAnalyticsData("dis", list);
        g.setLinesStyle("diffMA");
        g.drawLines(list);

        var unit = this.options.getUnit();
        g.drawTitle("移動平均乖離率(" + kikan + unit + ")");

        //最後の値
        var last = list[list.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = DiffMA;