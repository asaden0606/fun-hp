/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ShineAshiBase = require('./ShineAshiBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * 時系列新値足を表示するクラス
 */
class TimeShineAshi extends ShineAshiBase
{
    getChartID()
    {
        return "time_shine_ashi";
    }

    /**
     * 時系列情報を表示するメソッド
     */
    printGraphical(g,range,shineStores)
    {
        var domains = g.scaleX.domain();
        var width = g.transX(domains[1]) - g.transX(domains[0]);
        var pad = width / 2.0;
        g.setDomainY(range);

        for(var i = 0; i < shineStores.length; i++)
        {
            var store = shineStores[i];
            var left = g.transX(store.getBeginDate()) - pad;
            var right = g.transX(store.getEndDate()) + pad;
            var top = g.transY(store.getMaxPrice());
            var bottom = g.transY(store.getMinPrice());

            if(store.getIsUp())
            {
                g.setFillRectStyle("shine_up");
            }
            else
            {
                g.setFillRectStyle("shine_down");
            }

            g.fillRect(left,top,right,bottom);
        }
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    draw(g)
    {
        var para = Number(this.options.get('txt_shin_neashi2'));
        g.drawTitle("時系列新値足(" + para + "本)");

        this.sikii = -1 * (para + 1);
        var srcDatas = this.data;
        var min = GraphicsUtils.min(srcDatas,function(d){return d.close;});
        var max = GraphicsUtils.max(srcDatas,function(d){return d.close;});
        var range = GraphicsUtils.wideRange([min,max],1.3);

        if(srcDatas.length < 2)
        {
            return;
        }

        var shineStores = this.createStores(srcDatas);
        this.printString(shineStores);
        this.printGraphical(g,range,shineStores);
    }
}

module.exports = TimeShineAshi;