/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 一目均衡表を表示するクラス
 */
class Ichimoku extends ChartBase{
    constructor()
    {
        super();
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "ichimoku";
    }

    draw(g)
    {
        g.drawTitle("一目均衡表");
        var tenkanFlag = this.options.get('chk_ict');
        var kijunFlag = this.options.get('chk_icb');
        var spanFlag = this.options.get('chk_ics');

        var tenkan = Number(this.options.get('txt_ict'));
        var kijun = Number(this.options.get('txt_icb'));
        var span = Number(this.options.get('txt_ics'));

        var ichimokus = g.createIchimokuData(this.data,tenkan,kijun,span);

        for(var i = 0; i < ichimokus.length;i++)
        {
            var ichi = ichimokus[i];
            if(kijunFlag === false)
            {
                ichi["kijunSen"] = null;
            }

            if(spanFlag === false)
            {
                ichi["senkouSpanA"] = null;
                ichi["senkouSpanB"] = null;
            }

            if(tenkanFlag === false)
            {
                ichi["tenkanSen"] = null;
            }
        }

        this.options.setTypesOfAnalyticsData("ichimoku", ichimokus);

        g.drawIchimoku(ichimokus);
    }
}

module.exports = Ichimoku;