/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 移動平均線0を表示するクラス
 */
class Ma0 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "ma-0";
    }

    draw(g)
    {
        var avgParam = Number(this.options.get("txt_ma0"));
        g.setLinesStyle("ma-0");

        var sma = g.createSma(avgParam, this.data);

        this.options.setTypesOfAnalyticsData("ma-0", sma);

        g.drawLines(sma);
    }
}

module.exports = Ma0;