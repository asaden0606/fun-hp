/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * エンベロープ Envelope
 */
class Envelope extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "bbands";
    }


    /**
     * @param {Graphics} g - 移動平均(単純移動平均線 sma) をライブラリ側で作成させる
     * @param {number} kikan - 移動平均を算出する期間
     * @param {number} width - 値幅(%)
     */
    createEnvelope(g, kikan, width) {
        var sma = g.createSma(kikan, this.data);
        var envUP2 = $.extend(true, [], sma);
        var envUP1 = $.extend(true, [], sma);
        var envLO1 = $.extend(true, [], sma);
        var envLO2 = $.extend(true, [], sma);

        for(var i = 0; i < sma.length; i++)
        {
            // 移動平均を値幅で上下に乖離
            envUP2[i].value *= (1 + 2 *  width / 100);
            envUP1[i].value *= (1 +      width / 100);
            envLO1[i].value *= (1 +     -width / 100);
            envLO2[i].value *= (1 + 2 * -width / 100);
        }

        return {
            envUP2: envUP2,
            envUP1: envUP1,
            envMA: sma,
            envLO1: envLO1,
            envLO2: envLO2
        };
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_env");
        var width = +this.options.get("txt_envw");
        var envelope = this.createEnvelope(g, kikan, width);

        this.options.setTypesOfAnalyticsData("envUP2", envelope.envUP2);
        this.options.setTypesOfAnalyticsData("envUP1", envelope.envUP1);
        this.options.setTypesOfAnalyticsData("envMA",  envelope.envMA);
        this.options.setTypesOfAnalyticsData("envLO1", envelope.envLO1);
        this.options.setTypesOfAnalyticsData("envLO2", envelope.envLO2);

        g.setLinesStyle("envUP2");
        g.drawLines(envelope.envUP2);

        g.setLinesStyle("envUP1");
        g.drawLines(envelope.envUP1);

        g.setLinesStyle("envMA");
        g.drawLines(envelope.envMA);

        g.setLinesStyle("envLO1");
        g.drawLines(envelope.envLO1);

        g.setLinesStyle("envLO2");
        g.drawLines(envelope.envLO2);
    }
}

module.exports = Envelope;