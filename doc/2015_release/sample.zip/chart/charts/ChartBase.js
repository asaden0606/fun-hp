/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";


/**
 * チャートの基底クラス
 */
class ChartBase
{
    construnctor()
    {
        this.data = null;
        this.options = null;
        this.sound = null;
    }

    static get PRICE_GRAPHIC() {
        return "PRICE";
    }

    static get VOLUME_GRAPHIC() {
        return "VOLUME";
    }

    /**
     * Graphicを取得し、Graphicと本オブジェクト、
     * さらにはLayoutに関連付けるメソッド
     */
    createGraphic(layout)
    {
        this.g = this.getGraphic(layout);
        this.layout = layout;

        if(this.g !== null)
        {
            if(layout.containsGraphic(this.g.getID()) === false)
            {
                layout.addGraphic(this.g);
            }
            this.g.addChart(this);
        }
    }

    /**
     * オプションをセットするメソッド
     */
    setOptions(options)
    {
        this.options = options;
    }

    /**
     * サウンドマネージャをセットするメソッド
     */
    setSound(sound)
    {
        this.sound = sound;
    }

    /**
     * チャートデータをセットするメソッド
     */
    setData(data)
    {
        this.data = data;
    }

    /**
     * Graphicsを取得するメソッド
     */
    getGraphic()
    {
        return null;
    }

    /**
     * 本オブジェクトのIDを取得するメソッド
     */
    getChartID()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * 再描画を行うメソッド
     */
    refresh()
    {
        if(this.data === null || this.data === undefined)
        {
            return;
        }

        if(this.g !== null)
        {
            this.g.clear(this.getChartID());
            this.draw(this.g);
        }
    }


    /**
     * 定期的に呼び出されるメソッド
     * ただし、サポートするかは未定
     */
    onUpdate()
    {

    }

    /**
     * スクロールされた際に呼び出されるメソッド
     */
    onScroll()
    {
    }

    /**
     * 画面がリサイズされた際に呼び出されるメソッド
     */
    onResize()
    {

    }

    /**
     * 描画するメソッド
     */
    draw()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }
}


module.exports = ChartBase;