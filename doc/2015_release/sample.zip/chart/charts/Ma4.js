/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');

/**
 * 移動平均線4を表示するクラス
 */
class Ma4 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }


    getChartID()
    {
        return "ma-4";
    }


    draw(g)
    {
        var avgParam = Number(this.options.get("txt_ma4"));
        g.setLinesStyle("ma-4");

        var sma = g.createSma(avgParam, this.data);

        this.options.setTypesOfAnalyticsData("ma-4", sma);

        g.drawLines(sma);
    }
}

module.exports = Ma4;