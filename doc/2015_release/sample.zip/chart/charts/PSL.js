/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var ChartBase = require('./ChartBase');
var Graphics = require('../Graphics');
var GraphicsUtils = require('../Utils/GraphicsUtils');

/**
 * サイコロジカルライン Psychological Line
 */
class PSL extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return new Graphics(layout,this.getChartID(),4);
    }

    getChartID()
    {
        return "psy";
    }


    _sample2PSL(samples)
    {
        var sumUp = 0;
        var old = samples[0];
        for(var i = 1; i < samples.length; i++)
        {
            var data = samples[i];
            var sub = data.close - old.close;
            if(0 < sub)
            {
                sumUp++;
            }

            old = data;
        }

        var bottom = samples[samples.length - 1];

        return {
            date:bottom.date,
            value: sumUp / (samples.length-1) * 100
        };
    }

    createPSL(kikan)
    {
        var result = [];
        var samples = [];

        // 前日比が計算に必要なので期間+1する
        kikan++;

        for(var i = 0; i < this.data.length; i++)
        {
            samples.push(this.data[i]);
            if(kikan < samples.length )
            {
                samples.shift();
            }

            if (kikan  === samples.length) {
                var addSample = this._sample2PSL(samples);
                if(addSample !== null)
                {
                    result.push(addSample);
                }
            }
        }

        return result;
    }

    draw(g)
    {
        var kikan = +this.options.get("txt_psy");
        var psl = this.createPSL(kikan);

        this.options.setTypesOfAnalyticsData("psy", psl);

        //グラフ描画
        g.setDomainY([0,100]);
        g.drawColorBands( 0,  25, 'up-down-band');
        g.drawColorBands(75, 100, 'up-down-band');

        g.setLinesStyle("psl");
        g.drawLines(psl);

        var unit = this.options.getUnit();
        g.drawTitle("サイコロジカルライン(" + kikan + unit + ")");

        //最後の値
        var last = psl[psl.length - 1];
        var x = g.transX(last.date);
        var y = g.transY(last.value);
        var pos = GraphicsUtils.clip(
                     [x,y],
                     0,
                     g.getWidth(),
                     0,
                     g.getHeight());

        var lastPrice = last.value.toFixed(2);
        g.drawString(lastPrice,pos[0],pos[1]);
    }
}

module.exports = PSL;