/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";

var ChartBase = require('./ChartBase');
var GraphicsUtils = require('../utils/GraphicsUtils');
var GraphicsPopup = require('../GraphicsPopup');
var d3 = require('d3');

/**
 * 価格帯別出来高を表示するクラス
 */
class Kakakutai extends ChartBase
{
    constructor()
    {
        super();
    }

    getChartID()
    {
        return "kakakutai";
    }

    getGraphic(layout)
    {
        var g = new GraphicsPopup(
               layout,
                this.getChartID(),
                 0.05,
                 0,
                0.2,
                1.0,
                GraphicsPopup.RIGHT_FIX,
                GraphicsPopup.TOP_FIX
        );


        g.setDrawAxisBottomFlag(false);
        g.setDrawAxisLeftFlag(false);
        g.setDrawAxisRightFlag(false);
        g.setAxisFormatX(d3.format(",.3s"));
        return g;
    }

    /**
     * 価格情報の累計を生成するメソッド
     */
    toPriceVolume(datas,span)
    {
        var volumeMaps = [];
        for(var i = 0; i < datas.length;i++)
        {
            var data = datas[i];
            var keyInt =  parseInt(data.close / span);
            var key = String(keyInt);
            if(volumeMaps[key] === undefined)
            {
                volumeMaps[key] = 0;
            }

            volumeMaps[key] += data.volume;
        }


        var result = [];
        for(key in volumeMaps)
        {
            var volume = volumeMaps[key];
            var addPriceNum = {
                price:Number(key) * span,
                num:volume
            };

            result.push(addPriceNum);
        }

        return result;
    }

    /**
     * 価格情報郡から四角形を生成するメソッド
     */
    toRect(g,priceVolumes,span)
    {
        var result = [];
        for(var i = 0; i < priceVolumes.length;i++)
        {
            var priceVolume = priceVolumes[i];
            var bottom = g.transY(priceVolume.price);
            var top = g.transY(priceVolume.price + span);
            result.push({
                top:top,
                bottom:bottom,
                left:0,
                right:g.transX(priceVolume.num)
            });
        }

        return result;
    }

    /**
     * 価格帯出来高の間隔を取得するメソッド
     */
    calcSpan(datas)
    {
        //暫定対応
        var max = d3.max(datas,function(d){return d.close;});
        var min = d3.min(datas,function(d){return d.close;});

        return (max - min) / 15;
    }

    draw(g)
    {
        var priceGra = this.layout.getGraphic(ChartBase.PRICE_GRAPHIC);
        priceGra.drawTitle("価格帯出来高");
        var heightRatio = priceGra.getHeight() / this.layout.getDisplayHeight();
        g.setHeightRatio(heightRatio);
        var domainY = priceGra.getDomainY();
        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();
        var datas = GraphicsUtils.findInnerDatas(left,right,this.layout.getScaleX(),this.data);
        var span = this.calcSpan(datas);

        var priceVolumes = this.toPriceVolume(datas,span);
        var max = d3.max(priceVolumes,function(d){return d.num;});
        g.setDomainX([0,max]);
        g.setDomainY([domainY[1],domainY[0]]);

        var rects = this.toRect(g,priceVolumes,span);
        for(var i = 0; i < rects.length; i++)
        {
            var rect = rects[i];
            g.setFillRectStyle("kakakutai");
            g.fillRect(rect.left,rect.top,rect.right,rect.bottom);
        }
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}

module.exports = Kakakutai;