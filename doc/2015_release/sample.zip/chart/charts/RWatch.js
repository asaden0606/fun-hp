/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var d3 = require('d3');
var GraphicsUtils = require('../utils/GraphicsUtils');
var CreateAvgForceBase = require('../utils/CreateAvgForceBase');
var GraphicsFullPopup = require('../GraphicsFullPopup');

/**
 * 逆ウォッチ曲線の平均線を生成するメソッド
 */
class RWatchAvg extends CreateAvgForceBase
{
    toArray(data)
    {
        return [data.close,data.volume];
    }

    toValue(date,array)
    {
        return {
            date:date,
            close:array[0],
            volume:array[1]
        };
    }
}

/**
 * 逆ウォッチ曲線を表示するクラス
 */
class RWatch extends ChartBase
{
    constructor()
    {
        super();
    }

    getChartID()
    {
        return "RWatch";
    }

    getGraphic(layout)
    {
        var g= new GraphicsFullPopup(
                layout,
                 this.getChartID()
            );

        g.setAxisFormatX(d3.format(",.3s"));
        return g;
    }

    /**
     * 時刻を文字列化するメソッド
     */
    toDateText(date)
    {
        var year = String(date.getYear()).substr(1);
        var month = date.getMonth() + 1;
        var day = date.getDate();

        return year + "/" + month + "/" + day;
    }

    /**
     * 時刻の位置を取得するメソッド
     */
    toDatePos(g,head)
    {
        var x = g.transX(head.volume);
        var y = g.transY(head.close);

        var right = g.getWidth() - 50;
        var bottom = g.getHeight() - 30;
        var src = [x,y];
        var dst = GraphicsUtils.clip(src,0,right,20,bottom);

        return dst;
    }

    draw(g)
    {
        g.drawTitle("逆ウォッチ曲線");
        var creater = new RWatchAvg();
        var left = g.getDisplayLeft();
        var right = g.getDisplayRight();

        var xScale = g.getLayout().getScaleX();
        var data = GraphicsUtils.findInnerDatas(left,right,xScale,creater.create(this.data,25));

        if(data === null)
        {
            return;
        }

        if(data.length === 0)
        {
            return;
        }


        var volumeMin = d3.min(data,function(d){return d.volume;});
        var volumeMax = d3.max(data,function(d){return d.volume;});
        var priceMin = d3.min(data,function(d){return d.close;});
        var priceMax = d3.max(data,function(d){return d.close;});

        g.setDomainX([volumeMin,volumeMax]);
        g.setDomainY([priceMin,priceMax]);

        var lines = [];
        for(var i = 0; i < data.length; i++)
        {
            var ohlc = data[i];
            var x = g.transX(ohlc.volume);
            var y = g.transY(ohlc.close);

            lines.push({x:x,y:y});
        }

        var head = data[0];


        var pos = this.toDatePos(g,head);
        g.drawString(this.toDateText(head.date),pos[0],pos[1]);
        g.setLineStyle("rwatch");
        g.drawLine2(lines);
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }
}

module.exports = RWatch;