/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ChartBase = require('./ChartBase');
var CreateAvgBase = require('../utils/CreateAvgBase');


/**
 * 出来高移動平均線０を生成するクラス
 */
class CreateVolumeMa0 extends CreateAvgBase
{
    toArray(data)
    {
        return [data.volume];
    }

    toValue(date,array)
    {
        return {
            date:date,
            value:array[0]
        };
    }
}

/**
 * 出来高移動平均線0を表示するクラス
 */
class VolumeMa0 extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.VOLUME_GRAPHIC);
    }

    getChartID()
    {
        return "volume_ma-0";
    }

    draw(g)
    {
        var avgParam = Number(this.options.get("txt_vm1"));
        var creater = new CreateVolumeMa0();
        var lines = creater.create(this.data,avgParam);
        g.setLinesStyle("volume_ma-0");

        this.options.setTypesOfAnalyticsData("volume_ma-0", lines);

        g.drawLines(lines);
    }
}

module.exports = VolumeMa0;