/**
 * Created by y.takahiro on 16/11/01.
 */

"use strict";

var ChartBase = require('./ChartBase');

/**
 * パラボリック生成の基底クラス
 */
class ParaPoriCreaterBase
{
    construnctor()
    {
    }

    /**
     * 上昇しているかを取得するメソッド
     */
    isUp()
    {
    }

    /**
     * 反転するかを判定するメソッド
     */
    isRevert()
    {

    }


    /**
     * 反転メソッド
     */
    revert()
    {

    }

    /**
     * SARを取得するメソッド
     */
    get()
    {
    }

    /**
     * 次のSARを生成するメソッド
     */
    next()
    {
    }
}

/**
 * 上昇パラボリ生成クラス
 */
class UpCreater extends ParaPoriCreaterBase
{
    constructor(ep)
    {
        super();
        this.af = 0.0;
        this.sar = ep;
        this.ep = ep;
        this.ep_max = 0;
        this.ep_min = ep;
    }

    isUp()
    {
        return true;
    }

    isRevert(data)
    {
        return data.low <= this.sar;
    }

    revert()
    {
        return new DownCreater(this.ep_max);
    }

    get(data)
    {
        return {
            date:data.date,
            value:this.sar,
            up:this.isUp(),

            //debug情報
            af:this.af,
            sar:this.sar,
            ep:this.ep,
            ep_max:this.ep_max,
            ep_min:this.ep_min
        };
    }



    next(data)
    {
        this.ep_max = Math.max(this.ep_max,data.high);
        this.ep_min = Math.min(this.ep_min,data.low);
        if(this.ep !== this.ep_max)
        {
            this.ep = this.ep_max;
            this.af = Math.min(this.af + 0.02,0.2);
        }

        this.sar = (this.ep - this.sar) * this.af + this.sar;
    }
}

/**
 * 下降パラボリ生成クラス
 */
class DownCreater extends ParaPoriCreaterBase
{
    constructor(ep)
    {
        super();
        this.af = 0.0;
        this.sar = ep;
        this.ep = ep;
        this.ep_max = ep;
        this.ep_min = 100000;
    }

    isUp()
    {
        return false;
    }

    isRevert(data)
    {
        return this.sar < data.high;
    }

    revert()
    {
        return new UpCreater(this.ep_min);
    }

    get(data)
    {
        return {
            date:data.date,
            value:this.sar,
            up:this.isUp(),

            //debug情報
            af:this.af,
            sar:this.sar,
            ep:this.ep,
            ep_max:this.ep_max,
            ep_min:this.ep_min
        };
    }

    next(data)
    {
        this.ep_max = Math.max(this.ep_max,data.high);
        this.ep_min = Math.min(this.ep_min,data.low);
        if(this.ep !== this.ep_min)
        {
            this.ep = this.ep_min;
            this.af = Math.min(this.af + 0.02,0.2);
        }

        this.sar = (this.ep - this.sar) * this.af + this.sar;
    }
}




/**
 * パラボリックを表示するクラス
 */
class ParaPori extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "ParaPori";
    }

    /**
     * パラボリを生成するメソッド
     */
    createParaPori()
    {
        var result = [];
        if(this.data.length === 0)
        {
            return;
        }

        var head = this.data[0];

        var creater = new UpCreater(head.low);
        for(var i = 1; i < this.data.length;i++)
        {
            var data = this.data[i];
            if(creater.isRevert(data))
            {
                creater.next(data);
                creater = creater.revert();
            }

            result.push(creater.get(data));
            creater.next(data);
        }

        return result;
    }

    /**
     *パラボリをGraphicsにて表示するメソッド
     */
    printGraphics(g,paras)
    {
        for(var i = 0;i < paras.length;i++)
        {
            var para = paras[i];
            var x = g.transX(para.date);
            var y = g.transY(para.value);

            if(para.up)
            {
                g.setStringStyle("parabora_up");
            }
            else
            {
                g.setStringStyle("parabora_down");
            }

            g.drawString("○",x,y);
        }
    }

    /**
     *パラボリを文字列化するメソッド
     */
    printLogs(paras)
    {
        console.log(paras);
    }

    draw(g)
    {
        g.drawTitle("パラボリック");
        var paras = this.createParaPori();


        this.printGraphics(g,paras);
        this.printLogs(paras);
    }

    onResize()
    {
        this.refresh();
    }

    onScroll()
    {
        this.refresh();
    }
}





module.exports = ParaPori;