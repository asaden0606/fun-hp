"use strict";

var Graphics = require('./Graphics');
var d3 = require('d3');
var techan = require('techan');


class FGraphics extends Graphics
{
    constructor(layout,id,weight)
    {
        super(layout,id,weight);


        this.tradearrow = techan.plot.tradearrow()
                        .xScale(this.scaleX)
                        .yScale(this.scaleY)
                        .orient(function(d) { return d.type.startsWith("buy") ? "up" : "down"; });

        this.markerAnnotation = techan.plot.axisannotation()
                        .axis(this.axisBottom)
                        .format(d3.timeFormat('%Y-%m-%d'))
                        .width(100)
                        .translate([0, this.height]);


        this.supstance = techan.plot.supstance()
                .xScale(this.scaleX)
                .yScale(this.scaleY);

        this.trendline = techan.plot.trendline()
                .xScale(this.scaleX)
                .yScale(this.scaleY);

//        this.fixHoseiValue = 60;

        this.parseDate = d3.timeParse("%d-%b-%y");
        this.acc = techan.plot.candlestick().accessor();

        this.isWriteArrow = false;
    }



    drawTrendline(data)
    {
        this.svg.append("g")
                .attr("class", "trendlines")
                .datum(data)
                .call(this.trendline)
                .call(this.trendline.drag);
    }



    drawSupstance(data)
    {
        this.svg.append("g")
                .attr("class", "supstances")
                .datum(data)
                .call(this.supstance)
                .call(this.supstance.drag);
    }


    changeCanvas(x,y,width,height)
    {
        super.changeCanvas(x,y,width,height);

        this.scaleX.range([0, this.width]);

        this.scaleY.range([this.height, 0]);

        this.markerAnnotation.translate([0, this.height]);
    }




    drawTradeArrows(data)
    {
        this.svg.append("g")
                .attr("class","tradearrow")
                .datum(data)
                .call(this.tradearrow);

        this.isWriteArrow = true;
    }

    drawMarkerX(data)
    {
        this.noneClipSvg.append("g")
                .attr("class","x annotation bottom")
                .datum(data)
                .call(this.markerAnnotation);
    }

    parsePrice(datas)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var acc = techan.plot.candlestick().accessor();
        return datas.map(function(d) {
            return {
                date: parseDate(d[0]),
                open: d[1],
                high: d[2],
                low: d[3],
                close: d[4],
                volume: d[5]
        };}).sort(function(a, b) { return d3.ascending(acc.d(a), acc.d(b)); });
    }





    onDisplayChange(poliString)
    {
        var current = this.svg.select(poliString).attr("display");
        if(current === null || current === "true")
        {
            this.svg.selectAll(poliString).attr("display","none");
        }
        else
        {
            this.svg.selectAll(poliString).attr("display","true");
        }
    }

    common()
    {
        this.svg.selectAll("g.supstances").call(this.supstance.refresh);
        this.noneClipSvg.selectAll("g.axis.bottom").call(this.axisBottom);
        this.svg.selectAll("g.trendlines").call(this.trendline);
        this.noneClipSvg.selectAll("g.x.annotation.bottom").call(this.markerAnnotation);

        if(this.isWriteArrow)
        {
            this.svg.selectAll("g.tradearrow").call(this.tradearrow);
        }
    }


    onScroll()
    {
        super.onScroll();
        this.common();
    }

    onResize()
    {
        super.onResize();
        this.common();
    }

    parseData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var acc = this.acc;
        var data = srcData["prices"].map(function(d) {
        return {
            date: parseDate(d[0]),
            open: d[1],
            high: d[2],
            low: d[3],
            close: d[4],
            volume: d[5]
        };
        }).sort(function(a, b) { return d3.ascending(acc.d(a), acc.d(b)); });

        return data;
    }

    printProperties(obj)
    {
        var properties = '';
        for (var prop in obj)
        {
            properties += prop + "=" + obj[prop] + "\n";
        }
        alert(properties);
    }



    parseTrendlineData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var trendlineData = new Array();
        for(var i in srcData["trend"])
        {
            var d = srcData["trend"][i];
            var add =
            {
                start:
                {
                    date: parseDate(d[0]),
                    value:d[1]
                },
                end:
                {
                    date: parseDate(d[2]),
                    value:d[3]
                }
            };
            trendlineData.push(add);
        }

        return trendlineData;
    }

    parseSupportData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var supstanceData = new Array();
        for(var i in srcData["support"])
        {
            var d = srcData["support"][i];
            var add =
            {
                start: new Date(),
                end: parseDate(d[0]),
                value:d[1]
            };
            supstanceData.push(add);
        }

        return supstanceData;
    }



    parseArrowData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var arrows = new Array();
        for(var i in srcData["arrows"])
        {
            var d = srcData["arrows"][i];
            var add =
            {
                date: parseDate(d[0]),
                type: d[1],
                price:d[2],
                quantity:d[3]
            };
            arrows.push(add);
        }


        return arrows;
    }


    parseAvarageData(srcData,inKey)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var datas = new Array();
        for(var i in srcData[inKey])
        {
            var d = srcData[inKey][i];
            var add =
            {
                date: parseDate(d[0]),
                value:d[1]
            };
            datas.push(add);
        }


        return datas;
    }

    parseXMarkerData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var datas = new Array();
        for(var i in srcData["xMarkers"])
        {
            var d = srcData["xMarkers"][i];
            var add =
            {
                value:parseDate(d[0])
            };
            datas.push(add);
        }
        return datas;
    }



    parsePoliData(srcData,inScale,inKey)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var datas = new Array();
        for(var i in srcData[inKey])
        {
            var d = srcData[inKey][i];
            var add =
            {
                date: parseDate(d[0]),
                value:d[1] + inScale * d[2]
            };
            datas.push(add);
        }
        return datas;
    }
}

module.exports = FGraphics;
