"use strict";

class Events
{
    constructor()
    {
        this.events = [];
    }

    add(d)
    {
        this.events.push(d);
    }

    event1(arg1)
    {
        for(var i = 0; i < this.events.length;i++)
        {
            this.events[i](arg1);
        }
    }

    event2(arg1,arg2)
    {
        for(var i = 0; i < this.events.length;i++)
        {
            this.events[i](arg1,arg2);
        }
    }

    clear()
    {
        this.events = [];
    }
}

module.exports = Events;