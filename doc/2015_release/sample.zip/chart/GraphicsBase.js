/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var d3 = require('d3');

/**
 * Graphicsクラスの基底クラス
 */
class GraphicsBase
{
    constructor()
    {
        //以降スタイル名の設定
        this.chartID = "id";
        this.fillRectStyle = "fillRectBasic";
        this.linesStyle = "linesBasic";
        this.lineStyle = "lineBasic";
        this.stringStyle = "stringBasic";
        this.stringSize = null;
        this.line = d3.line()
               .x(function(d) { return d.x; })
               .y(function(d) { return d.y; });

        this.charts = [];
    }

    /**
     * GraphicsBaseにて使用するSVGを設定するメソッド
     */
    create(svg)
    {
        this.drawSvg = svg;
    }

    /**
     * 線分を表示するメソッド
     */
    drawLine(x1,y1,x2,y2)
    {
        var data =
            [
                {
                    x:x1,
                    y:y1
                },
                {
                    x:x2,
                    y:y2
                }
            ];

        this.drawSvg.append("path")
            .datum(data)
            .attr("class", this.lineStyle)
            .attr("id",this.chartID)
            .attr("d", this.line);
    }

    /**
     * 繋がった複数の線分を一度に描画するメソッド
     */
    drawLine2(data)
    {
        this.drawSvg.append("path")
            .datum(data)
            .attr("id",this.chartID)
            .attr("class", this.lineStyle)
            .attr("d", this.line);
    }

    /**
     * drawStringの文字サイズを動的に変えたい場合は設定
     * ※CSSで対応しきれない場合に使う
     */
    setStringSize(size)
    {
        this.stringSize = size;
    }

    /**
     * 文字列を描画するメソッド
     */
    drawString(text,x,y)
    {
        var drawText = this.drawSvg.append('text')
        .attr("class", this.stringStyle)
        .attr("id",this.chartID)
        .attr("x", x)
        .attr("y", y)
        .text(text);

        if(this.stringSize !== null)
        {
            drawText.attr("font-size",this.stringSize);
        }
    }


    /**
     * 四角形に塗りつぶすメソッド
     */
    fillRect(left,top,right,bottom)
    {
        var x = left;
        if(right < left)
        {
            x = left;
        }

        var y = top;
        if(bottom < top)
        {
            y = bottom;
        }

        var width = Math.abs(right - left);
        var height = Math.abs(bottom - top);

        this.drawSvg.append('rect')
            .attr("class",this.fillRectStyle)
            .attr("id",this.chartID)
            .attr("x", x )
            .attr("y", y)
            .attr("width",width)
            .attr("height",height);
    }

    /**
     * drawLines2を描画する際のCSSのクラス名を指定するメソッド
     */
    setLinesStyle(id)
    {
        this.linesStyle = id;
    }

    /**
     * drawLinesを描画する際のCSSのクラス名を指定するメソッド
     */
    setLineStyle(id)
    {
        this.lineStyle = id;
    }

    /**
     * drawStringを描画する際のCSSのクラス名を指定するメソッド
     */
    setStringStyle(id)
    {
        this.stringStyle = id;
    }

    /**
     * fillRectを描画する際のCSSのクラス名を指定するメソッド
     */
    setFillRectStyle(id)
    {
        this.fillRectStyle = id;
    }

    /**
     * データをスクリーンX座標に変換するメソッド
     */
    transX(val)
    {
        return this.getScaleX()(val);
    }

    /**
     * データをスクリーンY座標に変換するメソッド
     */
    transY(val)
    {
        return this.getScaleY()(val);
    }

    /**
     * SVGのマウスカーソルの位置情報を取得するメソッド
     */
    getMouseCursor()
    {
        return d3.mouse(this.drawSvg.node());
    }

    /**
     * スクリーンのX座標からデータのX座標を算出するメソッド
     */
    invertX(screenX)
    {
        return this.getScaleX().invert(screenX);
    }

    /**
     * スクリーンのY座標からデータのY座標を算出するメソッド
     */
    invertY(screenY)
    {
        return this.getScaleY().invert(screenY);
    }

    /**
     * 連続情報をセット
     */
    setSeeqHokan(hokan)
    {
        this.getLayout().setSeeqHokan(hokan);
    }

    /**
     * 画面左位置を取得するメソッド
     */
    getDisplayLeft()
    {
        return this.getLayout().getDisplayLeft();
    }

    /**
     * 画面右位置を取得するメソッド
     */
    getDisplayRight()
    {
        return this.getLayout().getDisplayRight();
    }

    /**
     * マウスアクションを設定する
     */
    setMouseAction(id)
    {
        this.getLayout().setMouseAction(id);
    }

    /**
     * オブジェクトのメソッド一覧を書き出すメソッド
     */
    toString(obj)
    {
        var properties = '';
        for (var prop in obj)
        {
            properties += prop + "=" + obj[prop] + "\n";
        }

        return properties;
    }

    /**
     * 指定したIDのオブジェクトをすべて消去するメソッド
     */
    clear(id)
    {
        this.chartID = id;
        this.drawSvg.selectAll("#" + id)
                 .remove();
    }

    /**
     * チャートを追加するメソッド
     */
    addChart(chart)
    {
        this.charts.push(chart);
    }

    /**
     * Graphicsのサイズを変更する際に呼び出されるメソッド
     */
    changeCanvas()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * X座標のDomainを設定するメソッド
     */
    setDomainX()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * Y座標のDomainを設定するメソッド
     */
    setDomainY()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * GraphicsPopupクラスだった場合に、trueが返る
     */
    isPopup()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     *  layoutを取得するメソッド
     */
    getLayout()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * X座標の座標変換オブジェクトを取得するメソッド
     */
    getScaleX()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * Y座標の座標変換オブジェクトを取得するメソッド
     */
    getScaleY()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * X座標を取得するメソッド
     */
    getX()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * Y座標を取得するメソッド
     */
    getY()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * 幅を取得するメソッド
     */
    getWidth()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * 高さを取得するメソッド
     */
    getHeight()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }
}


module.exports = GraphicsBase;