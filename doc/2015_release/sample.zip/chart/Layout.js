"use strict";
var d3 = require('d3');
var techan = require('techan');

var UserDragInfo = require('./mouses/UserDragInfo');

class Layout {
    constructor(targetNode, inWidth,inHeight,isControl)
    {
        this.margin = {top: 20, right: 50, bottom: 30, left: 50};
        if(isControl)
        {
            this.margin = {top: 20, right: 250, bottom: 30, left: 50};
        }


        this.width = inWidth - this.margin.left - this.margin.right;
        this.height = inHeight - this.margin.top - this.margin.bottom;

        d3.select(targetNode).selectAll("svg").remove();
        this.svg = d3.select(targetNode).append("svg")
                    .attr("width", this.width + this.margin.left + this.margin.right)
                    .attr("height", this.height + this.margin.top + this.margin.bottom);


        this.defs = this.svg.append( "defs" );
        this.userDefs = this.defs.append("g")
                              .attr("id","user_defs");

        this.zoom = d3.zoom();

        var id = "all";
        this.clipRect = this.defs.append("clipPath")
                .attr("id", id)
                .append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", this.width)
                .attr("height", this.height);


        this.noneClipUserSvg = this.svg.append("g")
        .attr("id","none_clip_user_svg");



        this.noneClipSvg = this.svg.append("g")
                         .attr("id","none-cliped-" + id)
                         .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");


        this.clipSvg = this.svg.append("g")
                         .attr("id","cliped" + id)
                         .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")")
                         .attr("clip-path", "url(#" + id + ")");


        this.clipUserSvg = this.svg.append("g")
        .attr("id","clip_user_svg");





        this.scaleX = techan.scale.financetime()
                             .range([0, this.width]);



        this.scaleY = d3.scaleLinear()
                   .range([0, this.height]);

        this.ohlcCrosshair = techan.plot.crosshair()
                .xScale(this.scaleX)
                .yScale(this.scaleY);

        this.fixAxisFlag = false;

        this.seeqHokan = null;

        this.graphics = {};

        var layout = this;
        window.onscroll = function()
        {
            layout.onScroll();
        };


        window.onresize = function()
        {
            layout.onResize();
        };




        this.setDragInfo(new UserDragInfo());

        this.fixHoseiFlag = 50;
    }

    popMouseAction()
    {
        this.dragInfo.current().popData();
    }



    changeCanvas(inWidth,inHeight)
    {
        this.width = inWidth - this.margin.left - this.margin.right;
        this.height = inHeight - this.margin.top - this.margin.bottom;


        this.svg
            .attr("width", this.width + this.margin.left + this.margin.right)
            .attr("height", this.height + this.margin.top + this.margin.bottom);


        this.clipRect
            .attr("width", this.width)
            .attr("height", this.height);

        this.scaleX.
            range([0, this.width]);

        this.scaleY.
            range([0, this.height]);

        this.ohlcCrosshair
             .verticalWireRange([0, this.height]);


        this.noneClipSvg
               .select("g.crosshair")
               .call(this.ohlcCrosshair);

        this.refreshCanvasSize();
    }

    findLastGraphic()
    {
        var lastGraphic = null;
        for(var i in this.graphics)
        {
            var graphic = this.graphics[i];
            if(graphic.isPopup() === false)
            {
                lastGraphic = graphic;
            }
        }

        return lastGraphic;
    }

    changeStyleSheet(id,sheetName)
    {
        document.getElementById(id).href = sheetName;
    }

    changeBodyColor(color)
    {
        d3.select("body")
          .attr("bgcolor",color);
    }


    getDisplayHeight()
    {
        return this.height;
    }

    getScaleX()
    {
        return this.scaleX;
    }

    distinctDate(dates)
    {
        var result = [];
        var oldDate = null;
        for(var i = 0; i < dates.length; i++)
        {
            var date = dates[i];
            if(oldDate === null || oldDate.getTime() !== date.getTime())
            {
                result.push(date);
            }
            oldDate = date;
        }

        return result;
    }


    setFixAxisFlag(flag)
    {
        this.fixAxisFlag= flag;
    }

    getFixAxisFlag()
    {
        return this.fixAxisFlag;
    }




    setDomainX(x)
    {
        //下の行はダミーデータを追加することで不連続を表現している。
        //techanが不連続をサポートしていれば・・・・
        var all = this.createDummyDataAfter(x);
        if(this.seeqHokan !== null)
        {
            all = this.createDummyHokan(all);
        }


        this.scaleX.domain(all);
    }

    candle2domainX(data)
    {
        var candle = techan.plot.candlestick();
        return data.map(candle.accessor().d);
    }


    setSeeqHokan(hokan)
    {
        this.seeqHokan = hokan;
    }


    getClipUserSvg()
    {
        return this.clipUserSvg;
    }


    getNoneClipUserSvg()
    {
        return this.noneClipUserSvg;
    }



    getMargin()
    {
        return this.margin;
    }

    getWidth()
    {
        return this.width;
    }

    getZoom()
    {
        return this.zoom;
    }

    getHeight()
    {
        return this.height;
    }


    getDefs()
    {
        return this.userDefs;
    }



    getDragInfo()
    {
        return this.dragInfo;
    }



    findDate(dates,element)
    {
        for(var i = 0; i < dates.length; i++)
        {
            var date = dates[i];
            if(date.getTime() === element.getTime())
            {
                return true;
            }
        }

        return false;
    }

    addGraphic(inAddGraphic)
    {
        var id = inAddGraphic.getID();
        this.graphics[id] = inAddGraphic;
    }

    containsGraphic(id)
    {
        return id in this.graphics;
    }

    getGraphic(id)
    {
        if(id in this.graphics)
        {
            return this.graphics[id];
        }
        else
        {
            return null;
        }
    }

    getGraphics()
    {
        return this.graphics;
    }

    getGraphicsArray()
    {
        var result = [];
        for(var i in this.graphics)
        {
            result.push(this.graphics[i]);
        }

        return result;
    }

    getGraphicsArrayJouken(isPopup)
    {
        var result = [];
        for(var i in this.graphics)
        {
            var graphic = this.graphics[i];
            if(graphic.isPopup() === isPopup)
            {
                result.push(graphic);
            }
        }

        return result;
    }

    createDummyHokan(data)
    {
        var result = data.slice(0);
        var dateMap = data;
        var extent = d3.extent(dateMap);
        var lastDate = extent[1];
        var currentDate = extent[0];
        var addCount = 0;
        while(currentDate.getTime() < lastDate.getTime())
        {
            currentDate = this.seeqHokan.add(new Date(currentDate.getTime()));
            if(this.findDate(dateMap,currentDate) === false)
            {
                addCount++;
            }
            else
            {
                for(var i = 0; i < addCount; i++)
                {
                    result.push(currentDate);
                }
                addCount = 0;
            }
        }

        result = result.sort(function(a, b){return a.getTime() - b.getTime();});


        return result;
    }


    createDummyDataAfter(data)
    {
        var addDummyNum = data.length * 0.3;
        var result = data.slice(0);
        var currentNum = data.length;
        var extent = d3.extent(data);
        var add = (extent[1].getTime() - extent[0].getTime()) / currentNum;
        var currentDate = extent[1];
        for(var i = 0; i < addDummyNum; i++)
        {
            currentDate = new Date(currentDate.getTime() + add);
            result.push(currentDate);
        }

        return result;
    }

    getDisplayLeft()
    {
        var left =  document.documentElement.scrollLeft || // IE、Firefox、Opera
                document.body.scrollLeft;              // Chrome、Safari

        left -= this.margin.left;
        left = Math.max(left,0);

        return left - 10;
    }


    getDisplayRight()
    {
        if(this.fixAxisFlag)
        {
            return this.width;
        }
        else
        {
            var left =  document.documentElement.scrollLeft || // IE、Firefox、Opera
            document.body.scrollLeft;              // Chrome、Safari

            return left + window.innerWidth - this.margin.right - this.fixHoseiFlag;
        }
    }

    getDisplayWidth()
    {
        if(this.fixAxisFlag)
        {
            return this.width;
        }
        else
        {
            return Math.max(window.innerWidth - this.margin.right - this.margin.left,0);
        }
    }


    sortByDate(data)
    {
        var candle = techan.plot.candlestick();

        var accessor = candle.accessor();
        return data.sort(function(a, b)
        {
            return d3.ascending(accessor.d(a), accessor.d(b));
        });
    }




    refreshCanvasSize()
    {
        var sumWeight = 0;
        var graphics = this.getGraphicsArrayJouken(false);
        var i = 0;
        var graphic;
        for(i = 0;i < graphics.length;i++)
        {
            graphic = graphics[i];
            sumWeight = sumWeight + graphic.getHeightWeight();
        }

        var x = 0;
        var width = this.getWidth();
        var y = 0;
        var empty = 10;
        var maxHeight = this.height - empty * (graphics.length - 1);
        for(i = 0; i < graphics.length; i++)
        {
            graphic = graphics[i];

            var height = maxHeight * graphic.getHeightWeight() / sumWeight;

            graphic.changeCanvas(x,y,width,height);

            y = y + height + empty;
        }

        this.onResize();
    }

    beginScene()
    {
        this.graphics = {};
        this.clipUserSvg.selectAll("g").remove();
        this.noneClipUserSvg.selectAll("g").remove();
        this.userDefs.selectAll("*").remove();
        this.clipSvg.selectAll("g").remove();
        this.noneClipSvg.selectAll("g").remove();

        var names = this.dragInfo.getNames();
        for(var i = 0; i < names.length; i++)
        {
            var name = names[i];
            this.clipSvg.append("g")
                         .attr("id",name);
        }
    }

    onScroll()
    {
        var graphics = this.getGraphicsArray();
        for(var i = 0; i < graphics.length; i++)
        {
            var frm = graphics[i];
            frm.onScroll();
        }

        this.dragInfo.onScroll();
    }

    onResize()
    {
        var graphics = this.getGraphicsArray();
        for(var i = 0; i < graphics.length; i++)
        {
            var frm = graphics[i];
            frm.onResize();
        }

        this.dragInfo.onResize();
    }




    endScene()
    {
        var graphics = this.getGraphicsArray();

        if(graphics.length === 0)
        {
            return;
        }



        var yAnnotation = graphics.map(function (obj) {return obj.getAnnotationY();})
                           .filter(function(element){return element !== null;});


        var xAnnotation = graphics.map(function (obj) {return obj.getAnnotationX();})
                            .filter(function(element){return element !== null;});



        this.ohlcCrosshair
                .xAnnotation(xAnnotation)
                .yAnnotation(yAnnotation)
                .verticalWireRange([0, this.height])
                .on("move", function (coords) {
                    var xIndex = this.ohlcCrosshair.xScale().domain().indexOf(coords.x);
                    if (this.onMouseMove) {
                        this.onMouseMove(xIndex);
                    }
                }.bind(this))
                .on("out", function () {
                    if (this.onMouseMove) {
                        this.onMouseMove(-1);
                    }
                }.bind(this));


        this.noneClipSvg.append('g')
            .attr("class", "crosshair")
            .call(this.ohlcCrosshair);


        var crossRect = this.noneClipSvg.select("g.crosshair")
            .select("rect");

        var dates = this.distinctDate(this.ohlcCrosshair.xScale().domain());
        this.dragInfo.bind(this,this.clipSvg,this.scaleX,graphics[0].scaleY,dates,crossRect);
        this.dragInfo.current().enable();
    }

    setMouseAction(id)
    {
        this.dragInfo.setCurrent(id);
    }

    setDragInfo(dragInfo)
    {
        if(this.dragInfo !== null && this.dragInfo !== undefined)
        {
            this.dragInfo.unbind();
        }
        this.dragInfo = dragInfo;
    }

}

module.exports = Layout;