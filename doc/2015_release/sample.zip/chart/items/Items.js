/**
 * オプションやセッティングのための基底クラス
 * Created by taichi on 2016/10/28.
 */
"use strict";
var Items = class {
    constructor() {
    }

    init(){
        this.items = {};
        this.setDefaultItems();
    }

    set(key, value){
        this.items[key] = value;
    }

    get(key){
        return this.items[key];
    }

    has(key){
        if(typeof this.items[key] === 'undefined'){
            return false;
        }
        return true;
    }

    getItems(){
        return this.items;
    }

    /**
     * option値のマージ
     * @param $options
     */
    setItems($options){
        this.merge(this.items, $options);
    }

    /**
     * デフォルトの値
     */
    setDefaultItems() {
        throw new Error('This method must be defined.');
    }

    /**
     * オブジェクトのマージ
     * jQueryのextendを使っているけど別実装でもいいです。
     * @param base
     * @param newObj
     */
    merge(base, newObj) {
        $.extend(true, base, newObj);
    }


};
module.exports = Items;