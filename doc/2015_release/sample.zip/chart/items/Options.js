/**
 * オプション画面の設定を保持するクラス。
 * Options.jsxでフォームとbindingしている
 * Created by taichi on 2016/10/28.
 */
"use strict";
var d3 = require('d3');
var Data = require('./../Data');
var Items = require('./Items');

const formatMa = d3.format(".2f");
const formatVol0 = d3.format(",d");
const formatVol1 = d3.format(",.1f");

var Options = class extends Items{

    constructor() {
        super();
        this.intervals = {}; // 日足, 月足 等、足毎の options を保存する変数
        this.data = null;   // データクラス
        this.init();
    }

    init(){
        this.items = {};
        this.merge(this.items, {
            interval : 5,
            periodMin : 2,
            periodMon : 3,
            typesOfAnalytics : []
        });
        this.setDefaultItems();
    }


    setData(_data) {
        this.data = _data;

        // 初期値を求めるのにデータが必要な項目の初期化を行う
        this.setDefaultParam();
    }

    isTick() {
        return this.items.interval === "TICK";
    }
    isMinute() {
        let interval = +this.items.interval;
        return 1 <= interval && interval <= 60;
    }
    isHistorical() {
        let interval = this.items.interval;
        return interval==="d" || interval==="w" || interval==="m" || interval==="y";
    }

    /**
     * デフォルトのオプション値
     */
    setDefaultItems() {
        var interval = this.get("interval");

        /**
         * 選択されているTICK別の初期化値
         * 設定例
         *     初期値:25, 週足の場合 13, 月足の場合 12, 年足の場合 3
         *     ini(25, {"w": 13, "m": 12, "y": 3})
         * @param {string} val : 初期値
         * @param {object} opt : this.items.interval 別に初期値を設定したい時に使用する
         */
        var ini = (val, opt) => {
            if (opt && opt[interval]) {
                return opt[interval];
            }
            return val;
        };

        var defaultOptions = {
            bg_color: 'black',
            disp_sep: 'renzoku',
            disp_cur_price: 'relative',
            disp_chg: 'real',
            disp_bidask: 'hendo3',
            disp_bidask_size: 'small',
            disp_vwap: 'show',
            disp_split: 'no',
            disp_scale: 'normal',
            play_sound: 'off',
            rdo_chart: "candle",
            //txt_point_and_figure:  "3", // TODO 計算して初期値を求める
            txt_shin_neashi1: "3",
            txt_shin_neashi2: "3",
            txt_kagiashi:  ini( "5", {"d": "20", "w": "20", "m": "20", "y": "20"}),
            txt_reverse_watch:  ini("25", {"w": "13", "m": "6", "y": "5"}),
            chk_vol: true,
            chk_sb:  true,
            chk_ccnt:false,
            chk_rta: false,
            chk_rtc: false,
            chk_ma0: false,
            txt_ma0: ini("10", {"w":   "6", "m":  "6", "y":  "2"}),
            chk_ma1: true,
            txt_ma1: ini("25", {"w":  "13", "m": "12", "y":  "3"}),
            chk_ma2: false,
            txt_ma2: ini("50", {"w":  "20", "m": "18", "y":  "4"}),
            chk_ma3: true,
            txt_ma3: ini("75", {"w":  "26", "m": "24", "y":  "5"}),
            chk_ma4: false,
            txt_ma4: ini("100",{"w":  "52", "m": "36", "y":  "7"}),
            chk_ma5: false,
            txt_ma5: ini("200",{"w": "100", "m": "60", "y": "10"}),
            chk_hla: false,
            txt_hla: ini("25", {"w":  "13", "m": "12", "y":  "3"}),
            chk_icb: false,
            txt_icb: ini("26", {"w":   "5", "m":  "5", "y":  "5"}),
            chk_ict: false,
            txt_ict: ini( "9", {"w":   "2", "m":  "2", "y":  "2"}),
            chk_ics: false,
            txt_ics: ini("26", {"w":   "5", "m":  "5", "y":  "5"}),
            chk_vm1: false,
            txt_vm1: ini( "5", {"w":   "6", "m":  "3", "y":  "3"}),
            chk_vm2: false,
            txt_vm2: ini("25", {"w":  "13", "m": "12", "y":  "5"}),
            chk_pby: false,
            //txt_pby: "0", // TODO 計算して初期値を求める
            chk_bb:  false,
            txt_bb:  ini("20", {"d": "25", "w":  "13", "m": "12", "y":  "5"}),
            chk_bb1: false,
            txt_bb1: "1.0",
            chk_bb2: false,
            txt_bb2: "2.0",
            chk_par: false,
            chk_rsi: false,
            txt_rsi: ini("14", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_stc: false,
            txt_stc: ini("12", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_stcs:false,
            txt_stcs:ini("12", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_dis: false,
            txt_dis: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_rci: false,
            txt_rci: ini("12", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_psy: false,
            txt_psy: ini("12", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_vr1: false,
            txt_vr1: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_vr2: false,
            txt_vr2: ini("20", {"d": "12", "w":  "13", "m":  "6", "y":  "5"}),
            chk_hv:  false,
            txt_hv:  ini("14", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_dmi: false,
            txt_dmi: ini("14", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_adx: false,
            txt_adx: ini( "9", {"w":   "6", "m":  "3", "y":  "5"}),
            chk_abr: false,
            txt_abr: ini("26", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_ema1:false,
            txt_ema1:ini("12", {"w":   "6", "m":  "3", "y":  "3"}),
            chk_ema2: false,
            txt_ema2:ini("26", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_ema: false,
            chk_macd:false,
            txt_macd:ini("9", {"m":  "5", "y":  "5"}),
            chk_mom: false,
            txt_mom: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_roc: false,
            txt_roc: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_env: false,
            txt_env: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_envw:false,
            txt_envw:ini("1",  {"d": "3", "w": "3", "m": "3", "y": "3"}),
            chk_osi: false,
            txt_osi: ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_vs:  false,
            txt_vs:  "5",
            chk_vsw: false,
            txt_vsw: "2.0",
            chk_cci: false,
            txt_cci: "20",
            chk_rc:  false,
            txt_rc:  ini("25", {"w":  "13", "m":  "6", "y":  "5"}),
            chk_pent: false,
        };

        this.merge(this.items, defaultOptions);
    }

    /**
     * 分足、日足などの間隔入れ替え時の設定初期化
     * 足を変えたらモノによっては期間も変えないといけないどころか足によって使えるオプションがことなる。
     */
    changeInterval(interval) {
        this.set('interval', interval);
        var oldOptions = $.extend(true, {}, this.items);
        this.intervals[this.get("interval")] = oldOptions;

        this.items = this.intervals[interval];

        if (!this.items) {
            this.items = $.extend(true, {}, oldOptions);
            this.setDefaultItems();
        }

        for (var p in oldOptions) {
            if (isNaN(oldOptions[p]) || typeof oldOptions[p]==="boolean") {
                // 数値項目以外は元のままの値を使用する
                this.items[p] = oldOptions[p];
            }
        }

        this.items.interval = interval;
    }

    /**
     * 右メニューに表示するテクニカル分析の項目を作成する
     */
    buildTypesOfAnalytics() {
        var list = this.items.typesOfAnalytics;
        var opt = this.items;

        // まず空にする
        list.splice(0, list.length);

        if (opt.disp_vwap === 'show') {
            // VWAP
            list.push({name: 'vwap', title: 'VWAP', format: formatMa});
        }
        if (opt.chk_vol) {
            // 出来高
            list.push({name: 'volume', title: '出来高', format: this.formatKabu});
        }
        if (opt.chk_ma0 && +opt.txt_ma0 > 0) {
            // 株価移動平均
            list.push({name: 'ma-0', title: 'MA(' + opt.txt_ma0 + ')', param: opt.txt_ma0, format: formatMa});
        }
        if (opt.chk_ma1 && +opt.txt_ma1 > 0) {
            // 株価移動平均
            list.push({name: 'ma-1', title: 'MA(' + opt.txt_ma1 + ')', param: opt.txt_ma1, format: formatMa});
        }
        if (opt.chk_ma2 && +opt.txt_ma2 > 0) {
            // 株価移動平均
            list.push({name: 'ma-2', title: 'MA(' + opt.txt_ma2 + ')', param: opt.txt_ma2, format: formatMa});
        }
        if (opt.chk_ma3 && +opt.txt_ma3 > 0) {
            // 株価移動平均
            list.push({name: 'ma-3', title: 'MA(' + opt.txt_ma3 + ')', param: opt.txt_ma3, format: formatMa});
        }
        if (opt.chk_ma4 && +opt.txt_ma4 > 0) {
            // 株価移動平均
            list.push({name: 'ma-4', title: 'MA(' + opt.txt_ma4 + ')', param: opt.txt_ma4, format: formatMa});
        }
        if (opt.chk_ma5 && +opt.txt_ma5 > 0) {
            // 株価移動平均
            list.push({name: 'ma-5', title: 'MA(' + opt.txt_ma5 + ')', param: opt.txt_ma5, format: formatMa});
        }
        if (opt.chk_hla && +opt.txt_hla > 0) {
            // 高値安値移動平均
            list.push({name: 'high_avg', title: 'HMA(' + opt.txt_hla + ')', param: opt.txt_hla, format: formatMa});
            list.push({name: 'low_avg', title: 'LMA(' + opt.txt_hla + ')', param: opt.txt_hla, format: formatMa});
        }
        if (opt.chk_icb && +opt.txt_icb > 0
            && opt.chk_ict && +opt.txt_ict > 0
            && opt.chk_ics && +opt.txt_ics > 0) {
            // 一目均衡表（基準線）
            // 一目均衡表（転換線）
            // 一目均衡表（スパン）
            list.push({name: 'kijunSen', title: '基準線', param: opt.txt_icb, format: formatMa});
            list.push({name: 'tenkanSen', title: '転換線', param: opt.txt_ict, format: formatMa});
            list.push({name: 'senkouSpanA', title: '先行１', param: opt.txt_ics, format: formatMa});
            list.push({name: 'senkouSpanB', title: '先行２', param: opt.txt_ics, format: formatMa});
            list.push({name: 'chikouSpan', title: '遅行', param: opt.txt_ics, format: formatMa});
        }
        if (opt.chk_vm1 && +opt.txt_vm1 > 0) {
            // 出来高移動平均
            list.push({name: 'volume_ma-0', title: 'VMA(' + opt.txt_vm1 + ')', param: opt.txt_vm1, format: this.formatKabu});
        }
        if (opt.chk_vm2 && +opt.txt_vm2 > 0) {
            // 出来高移動平均
            list.push({name: 'volume_ma-1', title: 'VMA(' + opt.txt_vm1 + ')', param: opt.txt_vm2, format: this.formatKabu});
        }
        if (opt.chk_pby) {
            // 株価帯出来高[円]
            list.push({name: 'pby1', title: '株価帯'});
            list.push({name: 'pby2', title: '株価帯'});
            list.push({name: 'pby3', title: '出来高'});
        }
        if (opt.chk_bb && +opt.txt_bb > 0) {
            var bbFlag1 = opt.chk_bb1 && +opt.txt_bb1 > 0;
            var bbFlag2 = opt.chk_bb2 && +opt.txt_bb2 > 0;
            // ボリンジャーバンド
            // ボリンジャーバンド（σ）
            // ボリンジャーバンド（σ）
            if (bbFlag2)
                list.push({name: 'bbandUP2', title: '+' + opt.txt_bb2 + 'σ', param: opt.txt_bb, format: formatMa});
            if (bbFlag1)
                list.push({name: 'bbandUP1', title: '+' + opt.txt_bb1 + 'σ', param: opt.txt_bb, format: formatMa});

            list.push({name: 'bbandMA', title: 'MA(' + opt.txt_bb + ')', param: opt.txt_bb, format: formatMa});

            if (bbFlag1)
                list.push({name: 'bbandLO1', title: '-' + opt.txt_bb1 + 'σ', param: opt.txt_bb, format: formatMa});
            if (bbFlag2)
                list.push({name: 'bbandLO2', title: '-' + opt.txt_bb2 + 'σ', param: opt.txt_bb, format: formatMa});
        }
        if (opt.chk_par) {
            // パラポリック
            list.push({name: 'par', title: 'ﾊﾟﾗﾎﾟﾘｯｸ'});
        }
        if (opt.chk_rsi && +opt.txt_rsi > 0) {
            // ＲＳＩ
            list.push({name: 'rsi', title: 'RSI(' + opt.txt_rsi + ')', param: opt.txt_rsi, format: formatMa});
        }
        if (opt.chk_stc && +opt.txt_stc > 0) {
            // ストキャスティックス
            list.push({name: 'stck', title: 'STC%K(' + opt.txt_stc + ')', param: opt.txt_stc, format: formatMa});
            list.push({name: 'stcd', title: 'STC%D', param: opt.txt_stc, format: formatMa});
        }
        if (opt.chk_stcs && +opt.txt_stcs > 0) {
            // ストキャスティックススロー
            list.push({name: 'stcsd', title: 'STC%D(' + opt.txt_stcs + ')', param: opt.txt_stcs, format: formatMa});
            list.push({name: 'slowd', title: 'slow%D', param: opt.txt_stcs, format: formatMa});
        }
        if (opt.chk_dis && +opt.txt_dis > 0) {
            // 株価移動平均乖離率
            list.push({name: 'dis', title: '乖離(' + opt.txt_dis + ')', param: opt.txt_dis, format: formatMa});
        }
        if (opt.chk_rci && +opt.txt_rci > 0) {
            // ＲＣＩ
            list.push({name: 'rci', title: 'RCI(' + opt.txt_rci + ')', param: opt.txt_rci, format: formatMa});
        }
        if (opt.chk_psy && +opt.txt_psy > 0) {
            // サイコロジカルライン
            list.push({name: 'psy', title: 'ｻｲｺﾛ(' + opt.txt_psy + ')', param: opt.txt_psy, format: formatMa});
        }
        if (opt.chk_vr1 && +opt.txt_vr1) {
            // ボリュームレシオ(Ⅰ)
            list.push({name: 'vr1', title: 'VRⅠ(' + opt.txt_vr1 + ')', param: opt.txt_vr1, format: formatMa});
        }
        if (opt.chk_vr2 && +opt.txt_vr2) {
            // ボリュームレシオ(Ⅰ)
            list.push({name: 'vr2', title: 'VRⅡ(' + opt.txt_vr2 + ')', param: opt.txt_vr2, format: formatMa});
        }
        if (opt.chk_hv && +opt.txt_hv > 0) {
            // ヒストリカル・ボラリティ
            list.push({name: 'hv', title: 'HV(' + opt.txt_hv + ')', param: opt.txt_hv, format: formatMa});
        }
        if (opt.chk_dmi && +opt.txt_dmi > 0
            && opt.chk_adx && +opt.txt_adx > 0) {
            // ＤＭＩ（ＤＩ）
            // ＤＭＩ（ＡＤＸ）
            list.push({name: 'dmi1', title: '+DI(' + opt.txt_dmi + ')', param: +opt.txt_dmi+1, format: formatMa});
            list.push({name: 'dmi2', title: '-DI(' + opt.txt_dmi + ')', param: +opt.txt_dmi+1, format: formatMa});
            list.push({name: 'adx', title: 'ADX(' + opt.txt_adx + ')', param: +opt.txt_dmi + +opt.txt_adx, format: formatMa});
        }
        if (opt.chk_abr && +opt.txt_abr > 0) {
            // 強弱レシオ
            list.push({name: 'abr1', title: 'Aﾚｼｵ(' + opt.txt_abr + ')', param: +opt.txt_abr+1, format: formatMa});
            list.push({name: 'abr2', title: 'Bﾚｼｵ(' + opt.txt_abr + ')', param: +opt.txt_abr+1, format: formatMa});
        }
        if (opt.chk_macd && +opt.txt_macd > 0) {
            // ＭＡＣＤ
            list.push({name: 'macd', title: 'MACD(' + opt.txt_ema1 + '-' + opt.txt_ema2 + ')', param: +opt.txt_ema2, format: formatMa});
        }
        if (opt.chk_ema1 && +opt.txt_ema1 > 0) {
            // ＥＭＡ１
            list.push({name: 'ema1', title: 'EMA1(' + opt.txt_ema1 + ')', param: +opt.txt_ema1, format: formatMa});
        }
        if (opt.chk_ema1 && +opt.txt_ema1 > 0) {
            // ＥＭＡ２
            list.push({name: 'ema2', title: 'EMA2(' + opt.txt_ema2 + ')', param: +opt.txt_ema2, format: formatMa});
        }
        if (opt.chk_mom && +opt.txt_mom > 0) {
            // モメンタム
            list.push({name: 'mom', title: 'ﾓﾒﾝﾀﾑ(' + opt.txt_mom + ')', param: +opt.txt_mom+2, format: formatMa});
        }
        if (opt.chk_roc && +opt.txt_roc > 0) {
            // ＲＯＣ
            list.push({name: 'roc', title: 'ROC(' + opt.txt_roc + ')', param: +opt.txt_roc+2, format: formatMa});
        }
        if (opt.chk_env && +opt.txt_env > 0
          && opt.chk_envw && +opt.chk_envw > 0) {
            // エンベロープ（本数）
            // エンベロープ（値幅[%}）
            list.push({name: 'envUP2', title: 'MA+' + (+opt.txt_envw * 2) + '%', param: +opt.txt_env, format: formatMa});
            list.push({name: 'envUP1', title: 'MA+' + (+opt.txt_envw)     + '%', param: +opt.txt_env, format: formatMa});
            list.push({name: 'envMA',  title: 'MA(' +   opt.txt_env       + ')', param: +opt.txt_env, format: formatMa});
            list.push({name: 'envLO1', title: 'MA-' + (+opt.txt_envw)     + '%', param: +opt.txt_env, format: formatMa});
            list.push({name: 'envLO2', title: 'MA-' + (+opt.txt_envw * 2) + '%', param: +opt.txt_env, format: formatMa});
        }
        if (opt.chk_osi && +opt.txt_osi > 0) {
            // オシレーター
            list.push({name: 'osi', title: 'OSI(' + opt.txt_osi + ')', param: +opt.txt_osi, format: formatMa});
        }
        if (opt.chk_vs && +opt.txt_vs > 0
            && opt.chk_vsw && +opt.txt_vsw > 0) {
            // ボラティリティ・システム
            // ボラティリティ・システム（係数）
            list.push({name: 'vsh', title: 'VSH(' + opt.txt_vs + ')', param: +opt.txt_vs, format: formatMa});
            list.push({name: 'vsl', title: 'VSL(' + opt.txt_vs + ')', param: +opt.txt_vs, format: formatMa});
        }
        if (opt.chk_cci && +opt.txt_cci > 0) {
            // ＣＣＩ
            list.push({name: 'cci', title: 'CCI(' + opt.txt_cci + ')', param: +opt.txt_cci, format: formatMa});
        }
        if (opt.chk_rc && +opt.txt_rc) {
            // レシオケータ
            list.push({name: 'rc', title: 'ﾚｼｵ(' + opt.txt_rc + ')'});
        }
    }

    /**
     * テクニカル分析データ設定
     * このメソッドはテクニカル分析データ作成部で呼ばれる
     */
    setTypesOfAnalyticsData(name, _data) {
        this.data.analyticsData[name] = _data;
    }

    /**
     * マウスカーソルの位置のテクニカル分析データの値を設定する
     */
    buildTypesOfAnalyticsValues(dataIndex) {
        var list = this.items.typesOfAnalytics;

        for (var i=0; i<list.length; i++) {
            var obj = list[i];

            if (obj.name === 'volume') {
                // 出来高
                this.setVolumeValue(dataIndex, obj);

            } else if (obj.name === 'kijunSen'
                || obj.name === 'tenkanSen'
                || obj.name === 'senkouSpanA'
                || obj.name === 'senkouSpanB'
                || obj.name === 'chikouSpan') {
                // 一目均衡表
                this.setIchimokuValue(dataIndex, obj);

            } else if (obj.name === 'macd') {
                // MACD
                this.setMACDValue(dataIndex, obj);

            } else  if (this.data.analyticsData[obj.name]) {
                var index = this.calcIndex(this.data.analyticsData[obj.name], dataIndex, obj);

                var d = this.data.analyticsData[obj.name][index];
                if (d) {
                    if (obj.format) {
                        obj.value = obj.format.call(this, d.value);
                    } else {
                        obj.value = d.value;
                    }
                } else {
                    obj.value = 0;
                }
            }
        }
    }

    /**
     * 出来高のマウスカーソル位置の値を設定
     * @param {number} dataIndex - マウスカーソル位置のデータ添え字
     * @param {number} obj - テクニカル分析項目
     */
    setVolumeValue(dataIndex, obj) {
        var data = this.data.analyticsData["volume"];
        if(data == undefined)
        {
            return;
        }

        var index = this.calcIndex(data, dataIndex, obj);

        var d = data[index];
        var volume = d ? d.volume : 0;
        obj.value = this.formatKabu(volume);
    }

    /**
     * 一目均衡表のマウスカーソル位置の値を設定
     * @param {number} dataIndex - マウスカーソル位置のデータ添え字
     * @param {number} obj - テクニカル分析項目
     */
    setIchimokuValue(dataIndex, obj) {
        var ichimoku = this.data.analyticsData["ichimoku"];
        var index = this.calcIndex(ichimoku, dataIndex, obj);

        if (!ichimoku || !ichimoku[index]) {
            return;
        }

        obj.value = ichimoku[index][obj.name];
    }

    /**
     * MACDのマウスカーソル位置の値を設定
     * @param {number} dataIndex - マウスカーソル位置のデータ添え字
     * @param {number} obj - テクニカル分析項目
     */
    setMACDValue(dataIndex, obj) {
        var macd = this.data.analyticsData["macd"];
        var index = this.calcIndex(macd, dataIndex, obj);

        if (!macd || !macd[index]) {
            return;
        }

        obj.value = obj.format(macd[index].signal);
    }

    /**
     * 出来高など株表示のフォーマット
     * @param {number} stock - 株数
     * @return {string} 株表示
     */
    formatKabu(stock) {
        var unit, format;

        if (this.data.volDigit === Data.VOL_DIGIT_TEN_THOUSAND) {
            stock /= 10000;
            unit = "万株";
            format = formatVol1;
        } else if (this.data.volDigit === Data.VOL_DIGIT_THOUSAND) {
            stock /= 1000;
            unit = "千株";
            format = formatVol1;
        } else {
            unit = "株";
            format = formatVol0;
        }

        return format(stock) + unit;
    }

    /**
     * データ位置計算
     * @param {array} data - データ配列
     * @param {number} dataIndex - マウスカーソル位置の配列添え字
     * @param {object} obj - テクニカル分析の日数パラメータを持つオブジェクト
     * @return {number} データ位置
     */
    calcIndex(data, dataIndex, obj) {
        if (dataIndex < 0) {
            dataIndex = data.length - 1;
        } else if (obj.param > 0) {
            dataIndex = dataIndex - (+obj.param - 1); // パラメータの日数分配列長がずれるので調整する
        }
        return dataIndex;
    }

    /**
     * 選択されている足に応じた単位を返す
     * @return "日", "週" 等の単位
     */
    getUnit() {
        var unit;
        var interval = this.items.interval;
        if (!isNaN(interval)) {
            interval = +interval; // 数値なら明示的に数値にする
        }

        switch (interval) {
            case "TICK":
                unit = "T";
                break;
            case 1:
                unit = "分";
                break;
            case 3:
            case 5:
            case 10:
            case 15:
            case 20:
            case 30:
            case 60:
                unit = "x" + interval + "分";
                break;
            case "d":
                unit = "日";
                break;
            case "w":
                unit = "週";
                break;
            case "m":
                unit = "月";
                break;
            case "y":
                unit = "年";
                break;
        }
        return unit;
    }

    /**
     * 呼び値を取得する
     * @param {number} c - 株価
     * @return {number} 呼び値
     */
    getYobine(c) {
        // [0]=株価, [1]=呼び値
        var yobine = [
            [      3000,      1 ],
            [      5000,      5 ],
            [     30000,     10 ],
            [     50000,     50 ],
            [    300000,    100 ],
            [    500000,    500 ],
            [   3000000,   1000 ],
            [   5000000,   5000 ],
            [  30000000,  10000 ],
            [  50000000,  50000 ],
            [ 999999999, 100000 ],
            [         0,      0 ]
        ];

        var ret = 1;
        for (var i = 0; 0 < yobine[i][0]; i++) {
            if (c <= yobine[i][0]) {
                ret = yobine[i][1];
                break;
            }
        }
        return ret;
    }

    /**
     * 呼び値単位に変換する
     * @param {number} num - 株価
     */
    getScalingNum(num) {
        var i;
        if (num <= -1 || 1 <= num) {
            var m = num;
            if (num <= -1)
                m = -m;
            for (i = 0; i < 15; i++) {
                if (m < 10) {
                    m = m < 2 ? 1 :
                        m < 5 ? 2 :
                        m < 9 ? 5 : 10;
                    break;
                }
                m /= 10;
            }
            for ( ; i > 0; i--)
                m *= 10;
            num = m;
        } else if (num === 0) {
            num = 1;
        } else {    // num < 1
            for (i = 0; i < 10; i++) {
                if (1 <= num) {
                    num = num < 2 ? 1 :
                          num < 5 ? 2 :
                          num < 9 ? 5 : 10;
                    break;
                }
                num *= 10;
            }
            for ( ; i > 0; i--)
                num /= 10;
        }
        return num;
    }

    /**
     * 株価に応じた初期値求める
     */
    setDefaultParam() {
        var list;
        var interval = this.get("interval");
        if (interval === "TICK") {
            list = this.data.ticklist;
        } else if (1 <= interval && interval <= 60) {
            list = this.data.allMtslist;
        } else {
            list = this.data.allHtslist;
        }

        if (!list || list.length === 0) {
            return;
        }

        var c_max = Number.MIN_VALUE;
        var c_min = Number.MAX_VALUE;
        var i = 0;
        if (interval==="TICK" || (1 <= interval && interval <= 60)) {
            i = 0;
        } else if (list.length > 125) {
            i = list.length - 125;
        }

        for (; i < list.length; i++) {
            var d = list[i];
            if (0 < d.Close) {
                c_max = Math.max(c_max, d.Close);
                c_min = Math.min(c_min, d.Close);
            }
        }

        var yobine = this.getYobine(c_min);

        var a = this.getScalingNum((c_max - c_min) / 30);
        var n_pf = parseInt(a);
        if (n_pf < yobine)
            n_pf = yobine;

        var n_pbv = this.getScalingNum((c_max - c_min) / 20);
        if (n_pbv < yobine)
            n_pbv = yobine;

        // ポイント＆フィギュア及
        this.set("txt_point_and_figure", n_pf);
        // 株価帯出来高[円]
        this.set("txt_pby", n_pbv);
    }
};
module.exports = Options;