"use strict";

var Options = require('./Options');

class FOptions extends Options
{
    constructor()
    {
        super();
        this.items["txt_point_and_figure"] = 100;
        this.items['chk_ict'] = true;
        this.items['chk_icb'] = true;
        this.items['chk_ics'] = true;
        this.items['txt_ics'] = 26;
    }

    setTypesOfAnalyticsData()
    {

    }
}

module.exports = FOptions;