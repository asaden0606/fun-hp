/**
 * Created by taichi on 16/10/14.
 */
"use strict";
var d3 = require('d3');

var testToken = 'GzBXsDdupaUbdxGocj4BzZyMA5Ki5y4W1RTzn3UTF3c=';

/**
 * 証券取引所
 */
const EXCHANGE_NAMES = {
    'T' : '東証',
    'O' : '大阪',
    'NG': '名証',
    'FU': '福証',
    'SP': '札証'
};

const VOL_DIGIT_TEN_THOUSAND = 3;   // 万株 表示
const VOL_DIGIT_THOUSAND = 2;       // 千株 表示
const VOL_DIGIT_NORMAL = 1;         // 株 表示

class Data{
    constructor(ric, _options, callback) {
        this.ric = ric;
        this.assetInfo = null;
        this.chartInfo = null;
        this.options = _options;
        this.allHtslist = [];   // 日足データ(全データ)
        this.allMtslist = [];   // 分足データ(全データ)
        this.htslist = [];      // 日足データ(期間で絞ったサブセット)
        this.mtslist = [];      // 分足データ(期間で絞ったサブセット)
        this.ticklist = [];     // 歩み値データ
        this.todayTick = {};    // 当日データ
        this.holidayList = [];  // 祝日一覧
        this.marketTime = [];   // 取引出来る時間
        this.analyticsData = {};// テクニカル分析データ
        this.splits = [];       // 株式分割 分割係数の配列
        this.volDigit = 0;      // 株の千株、万株 表示判断用

        this.getAssetInfo().then(() => {
            return this.getChartInfo();
        }).then(() => {
            if (typeof callback === "function") {
                return callback(this);
            }
        });
    }

    static get EXCHANGE_NAMES() {
        return EXCHANGE_NAMES;
    }

    static get VOL_DIGIT_TEN_THOUSAND() {
        return VOL_DIGIT_TEN_THOUSAND;
    }
    static get  VOL_DIGIT_THOUSAND() {
        return VOL_DIGIT_THOUSAND;
    }
    static get  VOL_DIGIT_NORMAL() {
        return VOL_DIGIT_NORMAL;
    }

    getAssetInfo() {
        return new Promise((resolve, reject) => {
            if (this.assetInfo) {
                resolve(this.assetInfo);
                return;
            }

            $.ajax({
                url: "http://t1.tr-lfa.com/chart5/si",
                type: 'POST',
                cache: false,
                crossDomain: true,
                dataType: "json",
                data : {
                    ric : this.ric || '9984.T',
                    lang : this.options.get("lang") || 'ja',
                    token : this.options.get("token") || testToken
                }
            }).then(
                (res) => {
                    this.assetInfo = res;

                    resolve(res);
                },
                () => {
                    reject();
                }
            );
        });
    }

    getChartInfo() {
        return new Promise((resolve, reject) => {
            if (this.chartInfo) {
                resolve(this.chartInfo);
                return;
            }

            $.ajax({
                url: "http://t1.tr-lfa.com/chart5/info",
                type: 'POST',
                cache: false,
                crossDomain: true,
                dataType: "json",
                data : {
                    ric : this.ric || '9984.T',
                    token : this.options.get("token") || testToken
                }
            }).then(
                (res) => {
                    this.chartInfo = res;

                    this.setHolidayList(res);

                    this.setMarketTime(res);

                    resolve(res);
                },
                () => {
                    reject();
                }
            );
        });
    }



    /**
     * ティックデータを取得
     */
    getHistoricalTick() {
        if (this.ticklist.length === 0) {
            // 当日分の日足データは当日の歩み値データから作成するため
            // 歩み値データが無い場合は先に歩み値データを呼び出す
            return this.getCurrentTick().then(this._getHistoricalTick.bind(this));
        }
        return this._getHistoricalTick();
    }

    _getHistoricalTick() {
        return new Promise((resolve, reject) => {
            var formatDate = d3.timeFormat("%Y%m%d");

            var interval = this.options.get("interval");
            var period = this.options.get("periodMon");
            if (this.allHtslist.length === 0) {
                period = 36;
            }
            if (period === "データ長") {
                period = 12 * 30;
            }

            var to = this.getLastMarketDate();
            var from = this.getPreviousMarketMonth(interval, period, to);

            if (this.allHtslist.length !== 0 && +this.allHtslist[0].Date <= +from) {
                this.htslist = this.sliceList(this.allHtslist, from);
                if (this.options.get("disp_split") === "yes") {
                    this.htslist = this.adjustSplit(this.htslist);
                }
                this.htslist = this.buildDayData(this.htslist);

                this.options.setData(this);

                resolve(this.htslist);

                return;
            }

            $.ajax({
                url: "http://t1.tr-lfa.com/chart5/htslist",
                type: 'POST',
                cache: false,
                crossDomain: true,
                dataType: "text",
                data : {
                    ric   : this.ric || '9984.T',
                    token : this.options.get("token") || testToken,
                    i     : 'd30',
                    adj   : 0, // 0=権利落ち修正なし
                    fr    : formatDate(from),
                    to    : formatDate(to)
                },
            }).then(
                (res) => {
                    this.csvToHistoricalTick(res);

                    if (this.options.get("periodMon") === "データ長") {
                        if (+this.allHtslist[0].Date <= +this.getPreviousMarketDate(12*4, to)) {
                            this.options.set("periodMon", 12*4);
                        } else {
                            this.options.set("periodMon", 12*3);
                        }
                        if (this.onRightMenuDailyDataChange) {
                            this.onRightMenuDailyDataChange(this.allHtslist);
                        }
                    }

                    this.htslist = this.sliceList(this.allHtslist,
                                            this.getPreviousMarketMonth(
                                                this.options.get("interval"),
                                                this.options.get("periodMon"), to));
                    if (this.options.get("disp_split") === "yes") {
                        this.htslist = this.adjustSplit(this.htslist);
                    }
                    this.htslist = this.buildDayData(this.htslist);

                    this.options.setData(this);

                    resolve(this.htslist);
                },
                () => {
                    reject();
                }
            );
        });
    }

    getSampleData(){
        return new Promise((resolve) => {
            d3.csv("/data.csv", function (error, data) {
                resolve(data);
            });
        });
    }

    getMinuteTick() {
        return new Promise((resolve, reject) => {
            var formatDate = d3.timeFormat("%Y%m%d%H%M");

            var period = this.options.get("periodMin");
            if (this.allMtslist.length === 0) {
                period = 10;
            }
            if (period === "データ長") {
                period = 60;
            }

            var to = this.getLastMarketDate();
            var from = this.getPreviousMarketDate(period, to);

            if (this.allMtslist.length !== 0 && +this.allMtslist[0].Date <= +from) {
                this.mtslist = this.sliceList(this.allMtslist, from);
                this.mtslist = this.buildMinuteData(this.mtslist);

                this.options.setData(this);

                resolve(this.mtslist);
                return;
            }

            $.ajax({
                url: "http://t1.tr-lfa.com/chart5/mtslist",
                type: 'POST',
                cache: false,
                crossDomain: true,
                dataType: "text",
                data : {
                    ric   : this.ric || '9984.T',
                    token : this.options.get("token") || testToken,
                    i     : 'm60',
                    fr    : formatDate(from),
                    to    : formatDate(to)
                },
            }).then(
                (res) => {
                    this.csvToMinuteTick(res);

                    if (this.options.periodMin === "データ長") {
                        if (+this.allMtslist[0].Date <= +this.getPreviousMarketDate(20, to)) {
                            this.options.set("periodMin", 20);
                        } else {
                            this.options.set("periodMin", 10);
                        }
                        if (this.onRightMenuMinuteDataChange) {
                            this.onRightMenuMinuteDataChange(this.mtslist);
                        }
                    }

                    this.mtslist = this.sliceList(this.allMtslist,
                                            this.getPreviousMarketDate(this.options.get("periodMin"), to));

                    this.mtslist = this.buildMinuteData(this.mtslist);

                    this.options.setData(this);

                    resolve(this.mtslist);
                },
                () => {
                    reject();
                }
            );
        });
    }

    getCurrentTick() {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: "http://t1.tr-lfa.com/chart5/ticklist",
                type: 'POST',
                cache: false,
                crossDomain: true,
                dataType: "text",
                data : {
                    ric   : this.ric || '9984.T',
                    token : this.options.get("token") || testToken
                },
            }).then(
                (res) => {
                    res = this.csvToCurrentTick(res);

                    this.options.setData(this);

                    resolve(res);
                },
                () => {
                    reject();
                }
            );
        });
    }

    csvToHistoricalTick(data) {
        var parseDate = d3.timeParse("%Y%m%d");

        data = d3.csvParseRows(data);
        if (data.length > 1) {
         // csvの最下行の空行と件数表示行の削除
            data.length = data.length - 2;
        }

        this.splits = [];
        this.volDigit = VOL_DIGIT_TEN_THOUSAND;

        data = data.map(function(d) {
            var obj = {
                Date:     parseDate(d[0]),
                Open:     +d[1],    // 始値
                High:     +d[2],    // 高値
                Low:      +d[3],    // 安値
                Close:    +d[4],    // 終値
                Volume:   +d[5],    // 出来高
                Turnover: +d[6]     // 売上高
            };

            if (d[7]) {
                // 株式分割 分割係数
                this.splits.push({
                    Date: obj.Date,
                    Division: +d[7]
                });
            }

            obj.VWAP = obj.Turnover / obj.Volume;

            // 株の千株、万株の表示判断
            if (obj.Volume % 1000 === 0 && this.volDigit > VOL_DIGIT_THOUSAND) {
                this.volDigit = VOL_DIGIT_TEN_THOUSAND;
            } else if (obj.Volume % 100 === 0 && this.volDigit > VOL_DIGIT_NORMAL) {
                this.volDigit = VOL_DIGIT_THOUSAND;
            } else {
                this.volDigit = VOL_DIGIT_NORMAL;
            }

            return obj;
        }.bind(this));

        if (data.length > 0 ) {
            // 当日が取引日の場合に日足データは過去日のものしか
            // 取得できないので、ここで日足データの直近のデータ日付を
            // 調べ、過去日だったら歩み値データから当日分を作成する
            var lastDate = data[data.length - 1].Date;
            var lastMarketDate = this.getLastMarketDate();
            if (lastDate.getYear() !== lastMarketDate.getYear()
                || lastDate.getMonth() !== lastMarketDate.getMonth()
                || lastDate.getDate() !== lastMarketDate.getDate()) {
                var todayTick = this.createDailyTick();
                if (todayTick) {
                    data.push(todayTick);
                }
            }
        }

        data = this.paddingDayZeroData(data);

        this.allHtslist = data;

        this.updateHistoricalTick();    // データ加工

        return data;
    }

    csvToMinuteTick(data) {
        var parseDate = d3.timeParse("%Y-%m-%d %H:%M");

        data = d3.csvParseRows(data);
        if (data.length > 1) {
            // csvの最下行の空行と件数表示行の削除
            data.length = data.length - 2;
        }

        this.volDigit = VOL_DIGIT_TEN_THOUSAND;

        var sum_volume = 0, sum_turnover = 0;

        data = data.map(function(d) {
            var obj = {
                Date:     parseDate(d[0]),
                Open:     +d[1],    // 始値
                High:     +d[2],    // 高値
                Low:      +d[3],    // 安値
                Close:    +d[4],    // 終値
                Volume:   +d[5],    // 出来高
                Turnover: +d[6]     // 売上高
            };

            if (obj.Date.getHours()===this.marketTime[0].startHour
                && obj.Date.getMinutes()===this.marketTime[0].startMinute) {
                // 1日の開始時間の時にクリア
                sum_volume = 0;
                sum_turnover = 0;
            }

            sum_volume += obj.Volume;
            sum_turnover += obj.Turnover;

            obj.VWAP = sum_turnover / sum_volume;

            // 株の千株、万株の表示判断
            if (obj.Volume % 1000 === 0 && this.volDigit > VOL_DIGIT_THOUSAND) {
                this.volDigit = VOL_DIGIT_TEN_THOUSAND;
            } else if (obj.Volume % 100 === 0 && this.volDigit > VOL_DIGIT_NORMAL) {
                this.volDigit = VOL_DIGIT_THOUSAND;
            } else {
                this.volDigit = VOL_DIGIT_NORMAL;
            }

            return obj;
        }.bind(this));

        data = this.paddingMinuteZeroData(data);

        this.allMtslist = data;

        this.updateMinuteTick();    // データ加工

        return data;
    }

    csvToCurrentTick(data) {
        var parseDate = d3.timeParse("%Y%m%d%H%M");

        data = d3.csvParseRows(data);
        if (data.length > 1) {
            // csvの最下行の空行と件数表示行の削除
            data.length = data.length - 2;
        }

        var sum_price = 0;

        data = data.map(function(d) {
            var obj = {
                Date:   parseDate(d[0]),
                Price:  +d[1],  // 株価
                Volume: +d[2],  // 出来高
                AccumulatedVolume: +d[3]   // 総出来高
            };

            sum_price += obj.Price * obj.Volume;

            obj.VWAP = sum_price / obj.AccumulatedVolume;

            return obj;
        });

        this.ticklist = data;

        return data;
    }

    /**
     * 設定変更の反映
     */
    update() {
        this.updateMinuteTick();
        this.updateHistoricalTick();
    }

    /**
     * 分足データの加工
     */
    updateMinuteTick() {
        if (this.mtslist.length === 0) {
            return;
        }


    }

    /**
     * 日足データの加工
     */
    updateHistoricalTick() {
        if (this.htslist.length === 0) {
            return;
        }
    }

    /**
     * 過去の取引日取得
     */
    getPreviousMarketDate(previous_day, toDate) {
        var date = new Date(toDate);
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
        date.setMilliseconds(0);

        var cnt = 0;
        while (cnt < previous_day) {
            date.setDate(date.getDate() - 1);
            if (this.isHoliday(date)) {
                continue;
            }
            cnt++;
        }

        date.setHours(this.marketTime[0].startHour);
        date.setMinutes(this.marketTime[0].startMinute);
        date.setSeconds(0);
        date.setMilliseconds(0);

        return date;
    }

    /**
     * 過去の取引日取得
     */
    getPreviousMarketMonth(interval, period, toDate) {
        var date = new Date(toDate);
        date.setHours(0);
        date.setMinutes(0);
        date.setSeconds(0);
        date.setMilliseconds(0);

        date.setMonth(toDate.getMonth() - period); // TODO: 休日計算
        if (interval === "w") {
            var day = date.getDay();
            if (day !== 1) { // 1:月曜日
                date.setDate(date.getDate() - ((day + 6) % 7)); // 前の月曜日にする
            }
        } else if (interval === "m") {
            date.setDate(1);    // 月始め
        } else if (interval === "y") {
            date.setMonth(0);
            date.setDate(1);    // 年初め
        }

        while (this.isHoliday(date)) {
            date.setDate(date.getDate() + 1);
        }

        return date;
    }

    /**
     * 直近の取引日取得
     */
    getLastMarketDate() {
        var date = new Date();
        while (0===date.getDay() || 6===date.getDay() || this.isHoliday(date)) {
            date.setDate(date.getDate() - 1);
        }
        return date;
    }

    /**
     * 指定した日時以降のデータを取得する
     * list チャートデータ
     * fromDate 日時
     */
    sliceList(list, fromDate) {
        var i, len, obj;
        for (i=0, len=list.length; i<len; i++) {
            obj = list[i];
            if (obj.Date.getTime() >= fromDate.getTime()) {
                break;
            }
        }

        // 株式分割 権利落ち修正時にこのサブリストの株価を
        // 編集するので deep copy を返す
        return $.extend(true, [], list.slice(i));
    }

    /**
     * 今日の歩み値データから日足データを作成する
     */
    createDailyTick() {
        if (this.ticklist.length === 0) {
            return null;
        }

        var d = this.ticklist[0].Date;
        var now = new Date();

        if (d.getFullYear() !== now.getFullYear()
            || d.getMonth() !== now.getMonth()
            || d.getDate() !== now.getDate()) {
            return null;
        }

        var obj = {
            Date:     new Date(d.getFullYear(), d.getMonth(), d.getDate()),
            Open:     this.ticklist[0].Price,  // 始値
            High:     Number.MIN_VALUE,         // 高値
            Low:      Number.MAX_VALUE,         // 安値
            Close:    this.ticklist[this.ticklist.length-1].Price,    // 現値
            Volume:   0,    // 出来高
            Turnover: 0     // 売上高
        };

        this.ticklist.forEach((tick) => {
            obj.High = Math.max(obj.High, tick.Price);
            obj.Low  = Math.min(obj.Low, tick.Price);
            obj.Volume += tick.Volume;
            obj.Turnover += tick.Price * tick.Volume;
        });

        obj.VWAP = obj.Turnover / obj.Volume;

        return obj;
    }

    /**
     * 祝日一覧をオブジェクトに保持する
     */
    setHolidayList(chartInfo) {
        this.holidayList = [];
        if (!chartInfo || !chartInfo.hol) {
            return;
        }

        for (var year in chartInfo.hol) {
            var mmddList = chartInfo.hol[year].split(',');
            mmddList.map(function (mmdd) {
                var s = mmdd.split("-");
                var date = new Date(year, (+s[0])-1, s[1]);

                this.holidayList[date.getTime()] = true;
            }.bind(this));
        }
    }

    /**
     * 休日判定
     * @return {boolean} true:休日, false:営業日
     */
    isHoliday(date) {
        if (date.getDay()===0 || date.getDay()===6) {
            return true;
        }
        if (this.holidayList[date.getTime()]) {
            return true;
        }
        return false;
    }

    /**
     * 取引出来る時間をオブジェクトに保持する
     */
    setMarketTime(chartInfo) {
        this.marketTime = {};
        if (!chartInfo || !chartInfo.ses) {
            return;
        }

        this.marketTime = [];

        for (var i in chartInfo.ses) {
            var time = chartInfo.ses[i];

            var start = time.fr.split(":");
            var end   = time.to.split(":");

            this.marketTime.push({
                startHour   : +start[0],
                startMinute : +start[1],
                endHour     : +end[0],
                endMinute   : +end[1]
            });
        }
    }

    /**
     * 1分足データから他の日中足データへ加工する
     */
    buildMinuteData(data) {
        if (+this.options.get("interval")===1 || isNaN(this.options.get("interval"))) {
            return data;
        }

        var div = +this.options.get("interval");
        var i = 0, j = 0;
        var newData = [];
        var endFlag = false;

        for (i=0; i<data.length; i++) {
            if (this.isStartTime(data[i].Date)) {
                break;
            }
        }

        while (i < data.length) {
            var d = {
                Date: null,
                Open: 0,
                High: Number.MIN_VALUE,
                Low: Number.MAX_VALUE,
                Close: 0,
                Volume: 0,
                Turnover: 0
            };
            for (j=i; !endFlag; j++) {
                var wk = data[j];
                if (!wk) {
                    break;
                }

                // 有効な値(0やnull 以外)であればデータを加工する
                if (!d.Date)     d.Date      = wk.Date;     // 初回のデータ時刻
                if (!d.Open && wk.Open) d.Open = wk.Open;   // 初回の始値
                if (wk.High)     d.High      = Math.max(d.High, wk.High);
                if (wk.Low)      d.Low       = Math.min(d.Low, wk.Low);
                if (wk.Close)    d.Close     = wk.Close;
                if (wk.Volume)   d.Volume   += wk.Volume;
                if (wk.Turnover) d.Turnover += wk.Turnover;


                if (this.isEndTime(wk.Date)) {
                    // 取引終了時刻に来たらループを抜ける
                    endFlag = true;
                    i = j;
                }
                if (j > i && wk.Date.getMinutes() % div === div-1) {
                    // 必要な分データが揃ったのでループを抜ける
                    endFlag = true;
                    i = j;
                }
            }

            if (d.Date) {
                if (d.High === Number.MIN_VALUE) d.High = 0;
                if (d.Low  === Number.MAX_VALUE) d.Low  = 0;

                newData.push(d);

                if (!endFlag) {
                    i += div;
                } else {
                    i++;
                    endFlag = false;
                }
            }
        }

        return newData;
    }

    /**
     * 日足データから週足, 月足, 年足データへ加工する
     */
    buildDayData(data) {
        var interval = this.options.get("interval");
        if (!(interval==="w" || interval==="m" || interval==="y")) {
            return data;
        }

        if (interval === "w") {
            return this.buildWeekData(data);

        } else if (interval === "m") {
            return this.buildMonthData(data);

        }
        return this.buildYearData(data);
    }

    /**
     * 日足データから週足データへ加工する
     * @param {Date} d1 - 今のデータの日付
     * @param {Date} d2 - 次のデータの日付
     */
    buildWeekData(data) {
        var checkFunc = function (d1, d2) {
            if (d2.getDay() === 1) { // 1:月曜日
                return false;
            }
            if (((d2-d1) / (24*60*60*1000)) >= 7) {  // 7日以上差
                return false;
            }

            return true;
        };
        var nextFunc = function (date) {
            var n = (8 - date.getDay()) % 7;
            n = n || 7;
            date.setDate(date.getDate() + n); // 次の月曜日

            while (this.isHoliday(date)) {
                date.setDate(date.getDate() + 1);
            }

            return date;
        }.bind(this);

        return this.buildYMData(data, checkFunc, nextFunc);
    }

    /**
     * 日足データから月足データへ加工する
     */
    buildMonthData(data) {
        var checkFunc = function (d1, d2) {
            return d1.getFullYear() === d2.getFullYear()
                    && d1.getMonth() === d2.getMonth();
        };
        var nextFunc = function (date) {
            date.setMonth(date.getMonth() + 1);
            return date;
        };

        return this.buildYMData(data, checkFunc, nextFunc);
    }

    /**
     * 日足データから年足データへ加工する
     */
    buildYearData(data) {
        var checkFunc = function (d1, d2) {
            return d1.getFullYear() === d2.getFullYear();
        };
        var nextFunc = function (date) {
            date.setFullYear(date.getFullYear() + 1);
            return date;
        };

        return this.buildYMData(data, checkFunc, nextFunc);
    }

    /**
     * 日足データから週足、月足、年足へ加工する共通メソッド
     */
    buildYMData(data, checkFunc, nextFunc) {
        var newData = [];
        var date = new Date(data[0].Date);
        var i = 0;
        var notSplited = true;

        while (i < data.length) {
            var d = {
                Date: null,
                Open: 0,
                High: Number.MIN_VALUE,
                Low: Number.MAX_VALUE,
                Close: 0,
                Volume: 0,
                Turnover: 0
            };

            var wk = data[i];
            if (!wk) {
                break;
            }

            do {
                // 有効な値(0やnull 以外)であればデータを加工する
                if (!d.Date)     d.Date      = wk.Date;     // 初回のデータ時刻
                if (!d.Open && wk.Open) d.Open = wk.Open;   // 初回の始値
                if (wk.High)     d.High      = Math.max(d.High, wk.High);
                if (wk.Low)      d.Low       = Math.min(d.Low, wk.Low);
                if (wk.Close)    d.Close     = wk.Close;
                if (wk.Volume)   d.Volume   += wk.Volume;
                if (wk.Turnover) d.Turnover += wk.Turnover;

                wk = data[++i];
                if (!wk) {
                    break;
                }

                if (this.options.get("disp_split") === "no") {
                    notSplited = !this.isSplitDate(wk.Date);
                }

            } while (notSplited && checkFunc(date, wk.Date));

            if (notSplited) {
                date = nextFunc(date);
            }

            newData.push(d);
        }

        return newData;
    }

    /**
     * 取引時間の開始時刻か
     */
    isStartTime(date) {
        var h = date.getHours();
        var m = date.getMinutes();

        for (var time of this.marketTime) {
            if (h===time.startHour && m===time.startMinute) {
                return true;
            }
        }

        return false;
    }

    /**
     * 取引時間の終了時刻か
     */
    isEndTime(date) {
        var h = date.getHours();
        var m = date.getMinutes();

        for (var time of this.marketTime) {
            if (h===time.endHour && m===time.endMinute) {
                return true;
            }
        }

        return false;
    }

    /**
     * 取引がなかった時刻の分データを0値データで埋める
     */
    paddingMinuteZeroData(data) {
        var newData = [];
        var i = 0;
        var now = new Date();
        var lastTime = new Date();
        var eTime = this.marketTime[this.marketTime.length - 1];
        lastTime.setHours(eTime.endHour);
        lastTime.setMinutes(eTime.endMinute);
        lastTime.setSeconds(0);
        lastTime.setMilliseconds(0);

        if (lastTime > now) {
            lastTime = now;
        }

        var date = new Date(data[0].Date);

        while (i < data.length) {
            var startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            var endDate   = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            do {
                date.setDate(date.getDate() + 1);
            } while (this.isHoliday(date));


            for (var time of this.marketTime) {
                startDate.setHours(time.startHour);
                startDate.setMinutes(time.startMinute);
                endDate.setHours(time.endHour);
                endDate.setMinutes(time.endMinute);
                if (startDate > endDate) {
                    endDate.setDate(endDate.getDate() + 1);
                }

                while (startDate <= endDate) {
                    // 取引時間帯の分データを埋める
                    var d = data[i];
                    if (!d) {
                        break;
                    }
                    if (startDate > d.Date) {
                        i++;
                        continue;
                    }

                    if (+d.Date === +startDate) {
                        newData.push(d);
                        i++;
                    } else {
                        newData.push({
                            Date: new Date(startDate),
                            Open: 0,
                            High: 0,
                            Low: 0,
                            Close: 0,
                            Volume: 0,
                            Turnover: 0
                        });
                    }

                    startDate.setMinutes(startDate.getMinutes() + 1);
                    if (lastTime < startDate)
                        break;
                }
                if (lastTime < startDate)
                    break;
            }
            if (lastTime < startDate)
                break;
        }


        return newData;
    }

    /**
     * 取引がなかった日の日足データを0値データで埋める
     */
    paddingDayZeroData(data) {
        var newData = [];

        var day = new Date(data[0].Date);

        data.forEach((d) => {
            while (+d.Date > +day) {
                newData.push({
                    Date: new Date(day),
                    Open: 0,
                    High: 0,
                    Low: 0,
                    Close: 0,
                    Volume: 0,
                    Turnover: 0
                });
                do {
                    day.setDate(day.getDate() + 1);
                } while (this.isHoliday(day));
            }

            newData.push(d);
            do {
                day.setDate(day.getDate() + 1);
            } while (this.isHoliday(day));
        });

        return newData;
    }
    /**
     * 株式分割 権利落ち修正後の調整
     */
    adjustSplit(data) {
        if (this.splits.length === 0) {
            return data; // 分割なし
        }

        var i, j, index, split, d;

        for (i=0; i<this.splits.length; i++) {
            split = this.splits[i];

            index = data.findIndex((d) => {
                return d.Date.getTime() === split.Date.getTime();
            });

            for (j=0; j<index; j++) {
                d = data[j];
                d.Open  /= split.Division;
                d.High  /= split.Division;
                d.Low   /= split.Division;
                d.Close /= split.Division;
            }
        }

        return data;
    }

    /**
     * 株式分割した権利落ち日か
     * @return true:権利落ち日, false:権利落ち日でない、または設定が権利落ち修正なし
     */
    isSplitDate(date) {
        if (this.options.get("disp_split") === "no") {
            return false;
        }
        var index = this.splits.findIndex((d) => {
            return d.Date.getTime() === date.getTime();
        });
        return index > 0;
    }

    /**
     * チャートの上段に表示する銘柄名
     */
    getAssetTitle(){
        if(typeof this.assetInfo.nm !== 'undefined'){
            return this.assetInfo.nm + ' ' + this.assetInfo.symbol;
        }
        return '';
    }

}

module.exports = Data;