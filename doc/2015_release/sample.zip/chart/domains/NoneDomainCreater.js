/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var DomainCreaterBase = require('./DomainCreaterBase');

/**
 * 何もしない基底クラス
 */
class NoneDomainCreater extends DomainCreaterBase
{
    constructor()
    {
        super();
    }

    action()
    {
        return null;
    }
}

module.exports = NoneDomainCreater;