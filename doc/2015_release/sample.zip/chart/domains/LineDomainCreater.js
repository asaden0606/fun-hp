/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var DomainCreaterBase = require('./DomainCreaterBase');

/**
 * LineからDomainを生成する基底クラス
 */
class LineDomainCreater extends DomainCreaterBase
{
    constructor(candleData)
    {
        super();
        this.candleData = candleData;
    }

    action(left,right,x)
    {
        if(this.candleData === null)
        {
            return null;
        }

        var defaultMin = 10000;
        var defaultMax = -1;
        var min = defaultMin;
        var max = defaultMax;
        for(var i = 0; i < this.candleData.length; i++)
        {
            var candle = this.candleData[i];
            var screenX = x(candle.date);
            var high = candle.value;
            var low = candle.value;

            if(left <= screenX && screenX <= right)
            {
                if(min > low)
                {
                    min = low;
                }

                if(max < high)
                {
                    max = high;
                }
            }
        }

        if(min === defaultMin || max === defaultMax)
        {
            return null;
        }
        else
        {
            return [min,max];
        }
    }
}

module.exports = LineDomainCreater;