/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var DomainCreaterBase = require('./DomainCreaterBase');
var GraphicsUtils = require('../utils/GraphicsUtils');

/**
 * ローソク足データからDomainを生成するクラス
 */
class CandleDomainCreater extends DomainCreaterBase
{
    constructor(candleData)
    {
        super();
        this.candleData = candleData;
    }

    action(left,right,x)
    {
        var minMax = GraphicsUtils.candle2MinMax(left,right,x,this.candleData);



        if(minMax === null)
        {
            return null;
        }

        //サイズ調整
        //価格は画面ぎりぎりにならないようにする。

        return GraphicsUtils.wideRange(minMax,1.3);
    }
}

module.exports = CandleDomainCreater;