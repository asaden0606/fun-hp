/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

/**
 * データからDomainを生成する基底クラス
 */
class DomainCreaterBase
{
    action()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }
}

module.exports = DomainCreaterBase;