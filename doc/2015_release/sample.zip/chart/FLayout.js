"use strict";

var Layout = require('./Layout');
var FUserDragInfo = require('./mouses/FUserDragInfo');

class FLayout extends Layout
{
    constructor(targetNode, inWidth,inHeight,isControl)
    {
        super(targetNode, inWidth,inHeight,isControl);
        this.seeqHokan = null;
        this.setFixAxisFlag(true);
        this.setDragInfo(new FUserDragInfo());
    }


    static isCandle(params)
    {
        var type = params["type"];

        return type === "price" ||
                type === "pkikan" ||
                type === "nagi" ||
                type === "sim" ||
                type === "day_higara" ||
                type === "week_higara" ||
                type === "month_higara";
    }


    createDummyDataAfter(data)
    {
        if(this.getFixAxisFlag())
        {
            return data;
        }
        else
        {
            return super.createDummyDataAfter(data);
        }
    }

}

module.exports = FLayout;