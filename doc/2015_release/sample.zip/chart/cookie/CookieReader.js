"use strict";

class CookieReader
{
    constructor(inHeadKey)
    {
        this.headKey = inHeadKey;
        this.values = this.readCokies();
    }

    count()
    {
        return this.values.length;
    }

    readCokies()
    {
        var result = {};
        var allcookies = document.cookie;
        if( allcookies !== '' )
        {
            var cookies = allcookies.split('; ');

            for( var i = 0; i < cookies.length; i++ )
            {
                var cookie = cookies[ i ].split('=');
                result[ cookie[ 0 ] ] = decodeURIComponent( cookie[ 1 ] );
            }
        }

        return result;
    }

    createKey(key)
    {
        var text = this.headKey;
        text += "@";
        text += key;

        return text;
    }

    read(key)
    {
        var newKey = this.createKey(key);
        return this.values[newKey];
    }

    readCheck(key)
    {
        var value = this.read(key);
        if(value === undefined)
        {
            return;
        }

        var item = document.getElementById(key);
        if(value === "true")
        {
            item.checked = "checked";
        }
        else
        {
            item.checked = "";
        }
    }

    readValue(key)
    {
        var value = this.read(key);
        if(value === undefined)
        {
            return;
        }

        var item = document.getElementById(key);
        item.value = value;
    }
}

module.exports = CookieReader;