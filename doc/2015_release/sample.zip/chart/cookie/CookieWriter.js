"use strict";

class CookieWriter
{
    constructor(inHeadKey)
    {
        this.headKey = inHeadKey;
        var date = new Date();
        date.setTime(date.getTime() + 180 * 24 * 60 *60*1000);
        this.expires = date.toGMTString();
    }


    createKey(key)
    {
        var text = this.headKey;
        text += "@";
        text += key;

        return text;
    }

    write(key,value)
    {
        var newKey = this.createKey(key);
        var text = newKey + "=" + value;
        text += ";";
        text += "expires=";
        text += this.expires;

        document.cookie = text;
    }


    writeCheck(key)
    {
        var item = document.getElementById(key);
        this.write(key,item.checked);
    }


    writeValue(key)
    {
        var item = document.getElementById(key);
        this.write(key,item.value);
    }
}

module.exports = CookieWriter;