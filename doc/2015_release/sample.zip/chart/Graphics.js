/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var d3 = require('d3');
var techan = require('techan');
var NoneDomainCreater = require('./domains/NoneDomainCreater');
var LineDomainCreater = require('./domains/LineDomainCreater');
var CandleDomainCreater = require('./domains/CandleDomainCreater');
var VolumeDomainCreater = require('./domains/VolumeDomainCreater');
var GraphicsBase = require('./GraphicsBase');
var NormalJiku = require('./jikus/NormalJiku');

/**
 * 各種描画を行うクラス
 * イメージ的にはjavaのGraphicsクラスと同じ
 * また、各種チャートの管理等も行っている
 */
class Graphics extends GraphicsBase
{
    /**
     * コンストラクタ
     * @layout layoutオブジェクト
     * @id Graphicsの識別ID
     * @heightWeight 高さの重み。
     * この値を元に、Graphicsの高さを自動算出する。
     */
    constructor(layout,id,heightWeight)
    {
        super();
        this.margin = layout.getMargin();
        this.heightWeight = heightWeight;
        this.id = id;
        this.clipid = this.id + "_clip";
        this.layout = layout;
        this.x = 0;
        this.y = 0;
        this.width = 600;
        this.height = 400;

        var clipLeft = this.margin.left + this.x;
        var clipTop = this.margin.top + this.y;

        this.noneClipSvg = this.layout.getNoneClipUserSvg()
                                 .append("g")
                                 .attr("id","none-cliped-" + this.id)
                                 .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");


        this.svg = this.layout.getClipUserSvg()
                         .append("g")
                         .attr("id","cliped-" + this.id)
                         .attr("transform", "translate(" + clipLeft + "," + clipTop + ")")
                         .attr("clip-path", "url(#" + this.clipid + ")");

        this.scrollGroup = this.layout.getClipUserSvg()
                                    .append("g")
                                    .attr("id","scroll");



        this.defs = this.layout.getDefs();

        this.scaleX = this.layout.scaleX;

        this.scaleY = d3.scaleLinear()
                     .range([this.height,0]);



        //縦軸の表示がおかしくなるため、noneClipSvgは専用のscaleを持つ
        this.axisScaleY = this.scaleY.copy()
                              .range([this.y + this.height,this.y]);

        this.candlestick = techan.plot.candlestick()
                             .xScale(this.scaleX)
                             .yScale(this.scaleY);

        this.axisBottom = d3.axisBottom()
                .scale(this.scaleX)
                .tickSizeInner(-1 * this.layout.getHeight())
                .tickSizeOuter(0)
                .tickPadding(5);


        this.axisLeft = d3.axisLeft()
                .scale(this.axisScaleY)
                .tickSizeInner(-1 * this.width)
                .tickSizeOuter(0)
                .tickPadding(5);


        this.axisRight = d3.axisRight()
                .scale(this.axisScaleY)
                .tickSizeOuter(0);
                //.tickFormat(function(d){return d / 1000;});



        this.sma = techan.plot.sma()
                    .xScale(this.scaleX)
                    .yScale(this.scaleY);

        this.volume = techan.plot.volume()
                    .accessor(this.candlestick.accessor())
                    .xScale(this.scaleX)
                    .yScale(this.scaleY);

        this.trendline = techan.plot.trendline()
            .xScale(this.scaleX)
            .yScale(this.scaleY);

        this.rect = this.defs.append("clipPath")
                .attr("id", this.clipid)
                .append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", this.width)
                .attr("height", this.height);

        this.ohlc = techan.plot.ohlc()
                        .xScale(this.scaleX)
                        .yScale(this.scaleY);

        this.close = techan.plot.close()
                        .xScale(this.scaleX)
                        .yScale(this.scaleY);


        this.annotationX = techan.plot.axisannotation()
                                .axis(this.axisBottom)
                                .orient('bottom')
                                .format(d3.timeFormat('%Y-%m-%d'))
                                .width(100)
                                .translate([0, this.layout.getDisplayHeight()]);


        this.annotationY = techan.plot.axisannotation()
                            .axis(this.axisRight)
                            .orient('right')
                            .width(80)
                            .translate([this.layout.getWidth(), 0]);

        this.ichimoku = techan.plot.ichimoku()
                               .xScale(this.scaleX)
                               .yScale(this.scaleY);

        this.macd = techan.plot.macd()
                               .xScale(this.scaleX)
                               .yScale(this.scaleY);

        this.fixHoseiValue = 0;
        this.domainCreater = new NoneDomainCreater();
        this.jiku = new NormalJiku();
        this.titles = [];
        this.create(this.svg);
    }

    /**
     * 縦軸のフォーマットを指定
     */
    setAxisFormatY(format)
    {
        this.axisLeft.tickFormat(format);
        this.axisRight.tickFormat(format);
    }

    /**
     * 横軸のフォーマットを指定
     */
    setAxisFormatX(format)
    {
        this.axisBottom.tickFormat(format);
    }

    /**
     * 高さの重みを取得するメソッド
     */
    getHeightWeight()
    {
        return this.heightWeight;
    }

    drawTitle(text)
    {
        /*
        if(this.titles.indexOf(text) === -1)
        {
            this.titles.push(text);
        }

        var title = this.titles.join(",");

        this.scrollGroup.append('text')
        .attr("class", "title")
        .attr("id",this.chartID)
        .attr("x", 10)
        .attr("y", 0)
        .text(title);
        */
    }


    /**
     * Graphicsのサイズを変更するメソッド
     */
    changeCanvas(x,y,width,height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        var clipLeft = this.margin.left + this.x;
        var clipTop = this.margin.top + this.y;

        this.svg
            .attr("transform", "translate(" + clipLeft + "," + clipTop + ")");

        var left = this.getDisplayLeft();

        this.scrollGroup
            .attr("transform","translate(" + left + "," + clipTop + ")");

        this.scaleY
             .range([this.height,0]);

        this.axisScaleY
            .range([y + height,y]);

        this.axisLeft
            .tickSizeInner(-1 * this.width);

        this.rect
             .attr("width", this.width)
             .attr("height", this.height);

        this.axisBottom = d3.axisBottom()
                            .scale(this.scaleX)
                            .tickSizeInner(-1 * this.layout.getHeight())
                            .tickSizeOuter(0)
                            .tickPadding(5);
    }

    /**
     * IDを取得するメソッド
     */
    getID()
    {
        return this.id;
    }

    /**
     * Layoutを取得するメソッド
     */
    getLayout()
    {
        return this.layout;
    }

    /**
     * Popupではないので、fals
     */
    isPopup()
    {
        return false;
    }

    /**
     * X座標の座標変換オブジェクトを取得
     */
    getScaleX()
    {
        return this.scaleX;
    }

    /**
     * Y座標の座標変換オブジェクトを取得
     */
    getScaleY()
    {
        return this.scaleY;
    }

    /**
     * X座標の取得
     */
    getX()
    {
        return this.x;
    }

    /**
     * Y座標の取得
     */
    getY()
    {
        return this.y;
    }

    /**
     * 幅を取得するメソッド
     */
    getWidth()
    {
        return this.width;
    }

    /**
     * 高さを取得するメソッド
     */
    getHeight()
    {
        return this.height;
    }

    /**
     * 描画を開始するメソッド
     */
    beginDraw()
    {
        this.svg
            .selectAll("g")
            .remove();


        this.noneClipSvg
            .selectAll("g")
            .remove();

        this.domainCreater = new NoneDomainCreater();
    }

    /**
     * 描画を終了するメソッド
     */
    endDraw()
    {
        this.commonRefresh();
    }

    /**
     * X座標のアノテーションを取得するメソッド
     */
    getAnnotationX()
    {
        return this.annotationX;
    }

    /**
     * Y座標のアノテーションを取得するメソッド
     */
    getAnnotationY()
    {
        return this.annotationY;
    }

    /**
     * X座標のドメインを設定するメソッド
     */
    setDomainX(x)
    {
        this.layout.setDomainX(x);
    }

    /**
     * Y座標のドメインを取得するメソッド
     */
    getDomainY()
    {
        return this.scaleY.domain();
    }

    /**
     * Y座標のドメインを設定するメソッド
     */
    setDomainY(y)
    {
        y = this.jiku.action(y);
        this.axisScaleY.domain(y);//.nice();
        this.scaleY.domain(y);//.nice();
    }

    setScaleY(scaleY)
    {
        this.scaleY = scaleY;
        this.scaleY.range([this.height,0]);

        this.axisScaleY = this.scaleY.copy()
                                  .range([this.y + this.height,this.y]);

        this.candlestick.yScale(this.scaleY);

        this.axisLeft.scale(this.axisScaleY);

        this.axisRight.scale(this.axisScaleY);

        this.sma.yScale(this.scaleY);

        this.volume.yScale(this.scaleY);

        this.trendline.yScale(this.scaleY);

        this.ohlc.yScale(this.scaleY);

        this.close.yScale(this.scaleY);

        this.ichimoku.yScale(this.scaleY);

        this.macd.yScale(this.scaleY);
    }



    /**
     * 軸を設定するメソッド
     */
    setJiku(jiku)
    {
        this.jiku = jiku;
        this.setScaleY(this.jiku.getScale());
        this.jiku.setTicks(this.axisLeft);
        this.jiku.setTicks(this.axisRight);
    }

    /**
     * 移動平均線を生成するメソッド
     */
    createSma(period,data)
    {
        return techan.indicator.sma().period(period)(data);
    }

    /**
     * 移動平均線を生成するメソッド
     */
    createEma(period,data)
    {
        return techan.indicator.ema().period(period)(data);
    }

    /**
     * MACDを生成するメソッド
     */
    createMACD(fast, slow, signal, data)
    {
        var macd = techan.indicator.macd();
        macd.fast(fast);
        macd.slow(slow);
        macd.signal(signal);
        return macd(data);
    }

    /**
     * ローソク足をX座標のドメインを取得するメソッド
     */
    candle2domainX(data)
    {
        return data.map(this.candlestick.accessor().d);
    }

    /**
     * ローソク足をY座標のドメインへ変換・取得するメソッド
     */
    candle2domainY(data)
    {
        this.domainCreater = new CandleDomainCreater(data);
        var left = this.getDisplayLeft();
        var right = this.getDisplayRight();


        return this.domainCreater.action(left,right,this.scaleX);
    }

    /**
     * 出来高をY座標のドメインへ変換・取得するメソッド
     */
    volume2domainY(data)
    {
        this.domainCreater = new VolumeDomainCreater(data);

        var left = this.getDisplayLeft();
        var right = this.getDisplayRight();

        return this.domainCreater.action(left,right,this.scaleX);
    }

    /**
     * 線情報をX座標のドメインへ変換・取得するメソッド
     */
    line2domainX(data)
    {
        return data.map(this.close.accessor().d);
    }

    /**
     * 線情報をY座標のドメインへ変換・取得するメソッド
     */
    line2domainY(data)
    {
        this.domainCreater = new LineDomainCreater(data);
        var left = this.getDisplayLeft();
        var right = this.getDisplayRight();

        return this.domainCreater.action(left,right,this.scaleX);
    }

    /**
     * MACDをY座標のドメインへ変換・取得するメソッド
     */
    macd2domainY(data)
    {
        return techan.scale.plot.macd(data).domain();
    }

    /**
     * 出来高を表示するメソッド
     */
    drawVolumes(data)
    {
        this.svg.append("g")
                .attr("class", "volume")
                .datum(data)
                .call(this.volume);
    }

    /**
     * 一目均衡表を生成するメソッド
     */
    createIchimokuData(data,tenkan,kijun,senkou)
    {
        var creater = techan.indicator.ichimoku();
        creater.tenkanSen(tenkan);
        creater.kijunSen(kijun);
        creater.senkouSpanB(senkou);
        return creater(data);
    }

    /**
     * バー情報を表示するメソッド
     */
    drawBar(data)
    {
        this.svg.append("g")
                .attr("class", "ohlc")
                .datum(data)
                .call(this.ohlc);
    }

    /**
     * 一目均衡表を表示するメソッド
     */
    drawIchimoku(data)
    {
        this.svg.append("g")
                .attr("class", "ichimoku")
                .datum(data)
                .call(this.ichimoku);
    }

    /**
     * ローソク足を表示するメソッド
     */
    drawCandles(data)
    {
        this.svg.append("g")
                .attr("class", "candlestick")
                .datum(data)
                .call(this.candlestick);

        this.jiku.modifyCandles(this.svg);
    }

    /**
     * 直線（終値）を表示するメソッド
     */
    drawClose(data)
    {
        this.svg.append("g")
                .attr("class", "close")
                .datum(data)
                .call(this.close);
    }

    /**
     * 直線を描画するメソッド
     * ※drawLineとの違いは、techanによる描画
     */
    drawLines(data)
    {
        this.svg.append("g")
                .attr("class", "lines" +" " + this.linesStyle)
                .datum(data)
                .call(this.sma);
    }

    /**
     * MACDを描画するメソッド
     */
    drawMACD(data)
    {
        this.svg.append("g")
                .attr("class", "macd")
                .datum(data)
                .call(this.macd);
    }

    /**
     * Y座標の縦軸を表示するメソッド
     */
    drawAxisY()
    {
        var posLeft = 0;
        var posTop = 0;
        this.noneClipSvg.append("g")
                .attr("class", "axis left")
                .attr("transform", "translate(" + posLeft + "," + posTop + ")")
                .call(this.axisLeft);

        var posRight = this.width;
        this.noneClipSvg.append("g")
                .attr("class", "axis right")
                .attr("transform", "translate(" + posRight + "," + posTop + ")")
                .call(this.axisRight);
    }

    /**
     * X座標の横軸を表示するメソッド
     */
    drawAxisX()
    {
        var last = this.layout.findLastGraphic();
        if(last !== this)
        {
            return;
        }

        var pos = this.y + this.height;
        this.noneClipSvg.append("g")
                .attr("class", "axis bottom")
                .attr("transform", "translate(0," + pos + ")")
                .call(this.axisBottom);
    }

    /**
     * 帯状の塗りつぶし描画
     * yStart - y座標開始位置
     * yEnd - y座標終了位置
     * className - css クラス名
     */
    drawColorBands(yStart, yEnd, className)
    {
        var xs = 0;
        var xe = this.scaleX(this.scaleX.domain()[this.scaleX.domain().length - 1]);
        var ys = this.scaleY(yStart);
        var ye = this.scaleY(yEnd);

        var path = "M" + xs + "," + ys +
                    "L" + xs + "," + ye +
                    "L" + xe + "," + ye +
                    "L" + xe + "," + ys;

        this.svg.append('g')
            .append('path')
            .attr('d', path)
            .attr('class', className);
    }

    /**
     * 共通の再描画メソッド
     */
    commonRefresh()
    {
        var left = this.getDisplayLeft();
        var right = this.getDisplayRight();


        var domain = this.domainCreater.action(left,right,this.scaleX);
        if(domain !== null && domain !== undefined)
        {
            this.setDomainY(domain);
        }

        var clipTop = this.margin.top + this.y;

        this.scrollGroup
            .attr("transform","translate(" + left + "," + clipTop + ")");

        this.svg.selectAll("g.candlestick").call(this.candlestick);
        this.svg.selectAll("g.ohlc").call(this.ohlc.refresh);
        this.svg.selectAll("g.ichimoku").call(this.ichimoku);
        this.svg.selectAll("g.close").call(this.close.refresh);
        this.svg.selectAll("g.lines").call(this.sma.refresh);
        this.svg.selectAll("g.volume").call(this.volume);
        this.noneClipSvg.select("g.axis.left").call(this.axisLeft);



        if(this.layout.getFixAxisFlag())
        {
            this.noneClipSvg.select("g.axis.right")
            .attr("transform", "translate(" + this.width + ",0)")
            .call(this.axisRight);


            this.annotationY
                .translate([this.width, 0]);
        }
        else
        {
            right -= this.fixHoseiValue;
            this.noneClipSvg.select("g.axis.right")
            .attr("transform", "translate(" + right + ",0)")
            .call(this.axisRight);


            this.annotationY
                .translate([right, 0]);
        }


        this.jiku.modifyCandles(this.svg);
    }

    /**
     * スクロールされた際に呼び出されるメソッド
     */
    onScroll()
    {
        this.commonRefresh();
        for(var i = 0; i < this.charts.length; i++)
        {
            var chart = this.charts[i];
            chart.onScroll();
        }
    }

    /**
     * サイズ変更された際に呼び出されるメソッド
     */
    onResize()
    {
        this.commonRefresh();
        for(var i = 0; i < this.charts.length; i++)
        {
            var chart = this.charts[i];
            chart.onResize();
        }
    }
}

module.exports = Graphics;