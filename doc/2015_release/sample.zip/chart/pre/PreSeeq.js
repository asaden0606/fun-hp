"use strict";


var ChartBase = require('../charts/ChartBase');
var DayHokan = require('../hokan/DayHokan');
var WeekHokan = require('../hokan/WeekHokan');



class PreSeeq extends ChartBase{
    construnctor()
    {
        this.dummy = false;
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "seeq_change";
    }

    draw(g)
    {
        if(this.options.get("disp_sep") === "renzoku")
        {
            g.setSeeqHokan(null);
            return;
        }

        //ずらずらと書いていく
        //週足なら
        if(this.dummy) //パラメータの判定条件がわからないので・・・
        {
            g.setSeeqHokan(new WeekHokan());
        }
        else
        {
            g.setSeeqHokan(new DayHokan());
        }
    }
}

module.exports = PreSeeq;