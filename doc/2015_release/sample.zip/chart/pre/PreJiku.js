"use strict";

var ChartBase = require('../charts/ChartBase');
var NormalJiku = require('../jikus/NormalJiku');
var ReverseJiku = require('../jikus/ReverseJiku');

class PreJiku extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }


    getChartID()
    {
        return "jiku";
    }

    draw(g)
    {
        var dispScale = this.options.get('disp_scale');
        if(dispScale === "normal")
        {
            g.setJiku(new NormalJiku());
        }
        else
        {
            g.setJiku(new ReverseJiku());
        }
    }
}

module.exports = PreJiku;