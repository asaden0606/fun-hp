/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var d3 = require('d3');
var ChartBase = require('../charts/ChartBase');


class PreBodyColor extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "body_color";
    }

    draw(g)
    {
        //本当はクラス化する必要もないけど、こんなこともできますよ
        //的な意味でクラス化

        var bgColor = this.options.get("bg_color");
        if(bgColor === "black")
        {
            g.changeStyleSheet("body","../../../../css/black_back.css");
        }
        else
        {
            g.changeStyleSheet("body","../../../../css/white_back.css");
        }
    }
}

module.exports = PreBodyColor;