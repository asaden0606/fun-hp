/**
 * Created by taichi on 16/10/14.
 */
"use strict";

var d3 = require('d3');
var ChartBase = require('../charts/ChartBase');


class PreFont extends ChartBase{
    construnctor()
    {
    }

    getGraphic(layout)
    {
        return layout.getGraphic(ChartBase.PRICE_GRAPHIC);
    }

    getChartID()
    {
        return "font_change";
    }

    draw(g)
    {
        //本当はクラス化する必要もないけど、こんなこともできますよ
        //的な意味でクラス化

        var fontSize = this.options.get("disp_bidask_size");
        if(fontSize === "large")
        {
            g.changeStyleSheet("font","../../../../css/big_font.css");
        }
        else
        {
            g.changeStyleSheet("font","../../../../css/middle_font.css");
        }
    }
}

module.exports = PreFont;