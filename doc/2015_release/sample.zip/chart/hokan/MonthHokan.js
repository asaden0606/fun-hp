"use strict";
var HokanBase = require('./HokanBase');

class MonthHokan extends HokanBase
{
    add(date)
    {
        date.setMonth(date.getMonth() + 1);
        return date;
    }
}

module.exports = MonthHokan;