/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var d3 = require('d3');
/**
 * データから補間日時を生成する基底クラス
 */
class HokanBase
{
    add()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }


    /**
     * 指定した時刻を探すメソッド
     */
    findDate(dates,element)
    {
        for(var i = 0; i < dates.length; i++)
        {
            var date = dates[i];
            if(date.getTime() === element.getTime())
            {
                return true;
            }
        }

        return false;
    }


    /**
     * dataの補間を行うメソッド
     */
    createDummyHokan(data)
    {
        var result = data.slice(0);
        var dateMap = data;
        var extent = d3.extent(dateMap);
        var lastDate = extent[1];
        var currentDate = extent[0];
        var addCount = 0;
        while(currentDate.getTime() < lastDate.getTime())
        {
            currentDate = this.add(new Date(currentDate.getTime()));
            if(this.findDate(dateMap,currentDate) === false)
            {
                addCount++;
            }
            else
            {
                for(var i = 0; i < addCount; i++)
                {
                    result.push(currentDate);
                }
                addCount = 0;
            }
        }

        result = result.sort(function(a, b){return a.getTime() - b.getTime();});


        return result;
    }

    /**
     * dataの末尾に追加するメソッド
     */
    createDummyDataAfter(data)
    {
        var addDummyNum = data.length * 0.3;
        var result = data.slice(0);
        var currentNum = data.length;
        var extent = d3.extent(data);
        var add = (extent[1].getTime() - extent[0].getTime()) / currentNum;
        var currentDate = extent[1];
        for(var i = 0; i < addDummyNum; i++)
        {
            currentDate = new Date(currentDate.getTime() + add);
            result.push(currentDate);
        }

        return result;
    }

    dummyHokanFlag()
    {
        return true;
    }

    dummyAfterFlag()
    {
        return true;
    }

    action(x)
    {
        var all = x;
        if(this.dummyAfterFlag())
        {
            all = this.createDummyDataAfter(all);
        }

        if(this.dummyHokanFlag())
        {
            all = this.createDummyHokan(all);
        }

        return all;
    }
}


module.exports = HokanBase;