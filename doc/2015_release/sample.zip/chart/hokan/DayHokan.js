/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var HokanBase = require('./HokanBase');

/**
 * 日足から補間日時を生成するクラス
 */
class DayHokan extends HokanBase
{
    add(date)
    {
        date.setDate(date.getDate() + 1);
        return date;
    }
}


module.exports = DayHokan;