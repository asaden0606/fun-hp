"use strict";
var HokanBase = require('./HokanBase');

class WeekHokan extends HokanBase
{
    add(date)
    {
        date.setDate(date.getDate() + 7);
        return date;
    }
}

module.exports = WeekHokan;