/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var HokanBase = require('./HokanBase');

/**
 * 日足から補間日時を生成するクラス
 */
class AfterOnlyHokan extends HokanBase
{
    dummyHokanFlag()
    {
        return false;
    }

    dummyAfterFlag()
    {
        return true;
    }
}

module.exports = AfterOnlyHokan;

