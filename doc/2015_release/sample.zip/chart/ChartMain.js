'use strict';

var d3 = window.d3 = require('d3');
var BasicScenario = require('./scenarios/BasicScenario');
var AllKikanScenario = require('./scenarios/AllKikanScenario');

class ChartMain
{
    constructor()
    {
    }

    make(key)
    {
        if(key === 'basic')
        {
            return new BasicScenario();
        }
        else
        {
            return new AllKikanScenario();
        }
    }
}

window.ChartMain = ChartMain;