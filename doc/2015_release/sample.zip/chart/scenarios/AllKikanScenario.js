'use strict';

var d3 = require('d3');
var techan = require('techan');

var ScenarioBase = require('./ScenarioBase');
var FOptions = require('../items/FOptions.js');
var FLayout = require('../FLayout.js');
var ChartBase = require('../charts/ChartBase');
//M系



//F系
var FAllKikanChart = require('../fcharts/FAllKikanChart');





class AllKikanScenario extends ScenarioBase
{
    constructor()
    {
        super();
        this.options = {};

        this.param = this.GetQueryString();


        this.hostname = location.host;
        this.code = this.param["code"];


        this.type = "all_kikan";
        var span = this.param["span"];
        if(span === undefined)
        {
            span = "day";
        }

        this.begin = this.param["begin"];
        if(this.begin === undefined)
        {
            this.begin = 0;
        }
        else
        {
            this.begin = Number(this.begin);
        }

        var num = this.param["num"];
        if(num === undefined)
        {
            num = 350;
        }
        else
        {
            num = Number(num);
        }

        var width = this.param["width"];
        if(width === undefined)
        {
            width = 1000;
        }
        else
        {
            width = Number(width);
        }

        var height = this.param["height"];
        if(height === undefined)
        {
            height = 650;
        }
        else
        {
            height = Number(height);
        }



        this.oldBegin = this.begin;

        this.setValue('span',span);
        this.setValue('num',num);

        this.key = this.code + "@" + span;



        var writeControl = this.param["control"] !== "hide";

        this.width = width;
        this.height = height;
        this.layout = new FLayout('body',this.width,this.height,writeControl);
        this.parseDate = d3.timeParse("%d-%b-%y");
        this.options = new FOptions();

        this.onLoad();
    }





    reload()
    {
        var num = this.getValue('num');
        var host = this.hostname.replace("3001","8080");
        var min = this.begin;
        var max = this.begin + num;
        var span = this.getValue('span');


        var getURL = "http://" + host +"/gui/graph?code=" + this.code + "&span=" + span + "&type=" + this.type + "&min=" + min + "&max=" + max;
        console.log(getURL);

        var t = this;
        d3.json(getURL, function(error, srcData)
        {
            if(srcData[0].prices.length === 0)
            {
                t.begin = t.oldBegin;

                return;
            }


            t.setData(srcData);
            t.plot();
        });
    }

    loadCharts()
    {
        this.charts = [];
        this.charts.push(new FAllKikanChart());
    }


    setData(rawData)
    {
        this.rawData = rawData;
        this.data = this.rawData[0].prices;
    }
}


module.exports = AllKikanScenario;