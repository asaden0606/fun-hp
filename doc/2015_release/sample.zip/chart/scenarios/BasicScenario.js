'use strict';

var d3 = require('d3');
var techan = require('techan');

var ScenarioBase = require('./ScenarioBase');
var FOptions = require('../items/FOptions.js');
var FLayout = require('../FLayout.js');
var ChartBase = require('../charts/ChartBase');
//M系
var ModoriZaraba = require('../charts/ModoriZaraba');
var RSI = require('../charts/RSI');
var Ichimoku = require('../charts/Ichimoku');
var RWatch = require('../charts/RWatch');
var Kakakutai = require('../charts/Kakakutai');
var KagiAshi = require('../charts/KagiAshi');
var VolumeMa0 = require('../charts/VolumeMa0');
var ParaPori = require('../charts/ParaPori');
var DiffMA = require('../charts/DiffMA');
var PSL = require('../charts/PSL');
var TimeShineAshi = require('../charts/TimeShineAshi');


//F系
var FPointFigure = require('../fcharts/FPointFigure');
var FRWatch = require('../fcharts/FRWatch');
var FKagiAshi = require('../fcharts/FKagiAshi');
var FCandle = require('../fcharts/FCandle');
var FVolume = require('../fcharts/FVolume');
var FMa0 = require('../fcharts/FMa0');
var FMa1 = require('../fcharts/FMa1');
var FMa2 = require('../fcharts/FMa2');
var FMa3 = require('../fcharts/FMa3');
var FPoli = require('../fcharts/FPoli');
var FClose = require('../fcharts/FClose');
var FSupstance = require('../fcharts/FSupstance');
var FTradeArrow = require('../fcharts/FTradeArrow');
var FTrendline = require('../fcharts/FTrendline');
var FMarkerX = require('../fcharts/FMarkerX');




class BasicScenario extends ScenarioBase
{
    constructor()
    {
        super();
        this.options = {};

        this.param = this.GetQueryString();

        if(this.param["trend"] === "f")
        {
            this.setCheck('trend',false);
        }

        if(this.param["support"] === "f")
        {
            this.setCheck('sup',false);
        }

        if(this.param["avg_srt"] === "f")
        {
            this.setCheck('avg_srt',false);
        }

        if(this.param["avg_mid"] === "f")
        {
            this.setCheck('avg_mid',false);
        }

        if(this.param["avg_lng"] === "f")
        {
            this.setCheck('avg_lng',false);
        }

        this.hostname = location.host;
        this.code = this.param["code"];


        this.type = this.param["type"];
        if(this.type === undefined)
        {
            this.type = "price";
        }

        var span = this.param["span"];
        if(span === undefined)
        {
            span = "day";
        }

        this.begin = this.param["begin"];
        if(this.begin === undefined)
        {
            this.begin = 0;
        }
        else
        {
            this.begin = Number(this.begin);
        }

        var num = this.param["num"];
        if(num === undefined)
        {
            num = 350;
        }
        else
        {
            num = Number(num);
        }

        var width = this.param["width"];
        if(width === undefined)
        {
            width = 1000;
        }
        else
        {
            width = Number(width);
        }

        var height = this.param["height"];
        if(height === undefined)
        {
            height = 650;
        }
        else
        {
            height = Number(height);
        }

        if(this.param["control"] === "hide")
        {
            this.hideItem('control');
        }




        this.oldBegin = this.begin;

        this.setValue('span',span);
        this.setValue('num',num);

        this.key = this.code + "@" + span;



        var isWriteButton = FLayout.isCandle(this.param);
        if(isWriteButton === false)
        {
            this.hideItem('hyouji');
        }


        var writeControl = this.param["control"] !== "hide";

        this.width = width;
        this.height = height;
        this.layout = new FLayout('body',this.width,this.height,writeControl);
        this.parseDate = d3.timeParse("%d-%b-%y");
        this.chartMap = {};

        this.chartMap["price"] = BasicScenario.getChartPrice;
        this.chartMap["pkikan"] = BasicScenario.getChartNoneVolume;
        this.chartMap["nagi"] = BasicScenario.getChartNoneVolume;
        this.chartMap["day_higara"] = BasicScenario.getChartNoneVolume;
        this.chartMap["sim"] = BasicScenario.getChartNoneVolume;
        this.chartMap["week_higara"] = BasicScenario.getChartNoneVolume;
        this.chartMap["month_higara"] = BasicScenario.getChartNoneVolume;

        this.options = new FOptions();

        this.onLoad();
    }





    reload()
    {
        var num = this.getValue('num');
        var host = this.hostname.replace("3001","8080");
        var min = this.begin;
        var max = this.begin + num;
        var span = this.getValue('span');


        var getURL = "http://" + host +"/gui/graph?code=" + this.code + "&span=" + span + "&type=" + this.type + "&min=" + min + "&max=" + max;
        console.log(getURL);

        var t = this;
        d3.json(getURL, function(error, srcData)
        {
            if(srcData.prices.length === 0)
            {
                t.begin = t.oldBegin;

                return;
            }


            t.setData(srcData);
            t.plot();
        });
    }

    loadCharts()
    {
        var type = this.param["type"];
        if(type in this.chartMap)
        {
            var func = this.chartMap[type];
            this.charts = func();
        }
        else
        {
            this.charts = BasicScenario.getChartClose();
        }
    }



    static getChartClose()
    {
        var result = [];
        result.push(new FClose());
        result.push(new FMarkerX());
        return result;
    }


    static getChartNoneVolume()
    {
        var result = [];
        result.push(new FCandle());

        if(BasicScenario.isCheck('avg_srt'))
        {
            result.push(new FMa0());
        }

        if(BasicScenario.isCheck('avg_mid'))
        {
            result.push(new FMa1());
        }

        if(BasicScenario.isCheck('avg_lng'))
        {
            result.push(new FMa2());
        }

        if(BasicScenario.isCheck('avg_lngst'))
        {
            result.push(new FMa3());
        }

        if(BasicScenario.isCheck('poli'))
        {
            result.push(new FPoli());
        }

        if(BasicScenario.isCheck('modori'))
        {
            result.push(new ModoriZaraba());
        }

        if(BasicScenario.isCheck('sup'))
        {
            result.push(new FSupstance());
        }

        if(BasicScenario.isCheck('trend'))
        {
            result.push(new FTrendline());
        }

        if(BasicScenario.isCheck('arrow'))
        {
            result.push(new FTradeArrow());
        }

        if(BasicScenario.isCheck('rsi'))
        {
            result.push(new RSI());
        }

        if(BasicScenario.isCheck('ichimoku'))
        {
            result.push(new Ichimoku());
        }

        if(BasicScenario.isCheck('pfigure'))
        {
            result.push(new FPointFigure());
        }

        if(BasicScenario.isCheck('rwatch'))
        {
            result.push(new FRWatch());
        }

        if(BasicScenario.isCheck('kakaku'))
        {
            result.push(new Kakakutai());
        }

        if(BasicScenario.isCheck('kagi'))
        {
            result.push(new FKagiAshi());
        }

        if(BasicScenario.isCheck('parabo'))
        {
            result.push(new ParaPori());
        }

        if(BasicScenario.isCheck('kairi'))
        {
            result.push(new DiffMA());
        }

        if(BasicScenario.isCheck('saiko'))
        {
            result.push(new PSL());
        }


        if(BasicScenario.isCheck('time_shine'))
        {
            result.push(new TimeShineAshi());
        }



        result.push(new FMarkerX());

        return result;
    }

    static getChartPrice()
    {
        var result = BasicScenario.getChartNoneVolume();

        if(BasicScenario.isCheck('volume'))
        {
            result.push(new FVolume());
            if(BasicScenario.isCheck('volumema0'))
            {
                result.push(new VolumeMa0());
            }
        }

       return result;
    }


    parseData(srcData)
    {
        var parseDate = d3.timeParse("%d-%b-%y");
        var acc = techan.plot.candlestick().accessor();
        var data = srcData["prices"].map(function(d) {
        return {
            date: parseDate(d[0]),
            open: d[1],
            high: d[2],
            low: d[3],
            close: d[4],
            volume: d[5]
        };}).sort(function(a, b) { return d3.ascending(acc.d(a), acc.d(b)); });

        return data;
    }

    setData(rawData)
    {
        this.rawData = rawData;
        var data = this.parseData(this.rawData);
        this.data = this.layout.sortByDate(data);
    }
}


module.exports = BasicScenario;