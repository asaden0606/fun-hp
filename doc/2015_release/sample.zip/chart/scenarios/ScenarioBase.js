"use strict";

var d3 = require('d3');
var techan = require('techan');
var ChartBase = require('../charts/ChartBase');
var CookieWriter = require('../cookie/CookieWriter');
var CookieReader = require('../cookie/CookieReader');
var FChartBase = require('../fcharts/FChartBase');

class ScenarioBase
{
    constructor()
    {

    }

    setCheck(itemName,check)
    {
        document.getElementById(itemName).checked = check;
    }


    setValue(itemName,value)
    {
        document.getElementById(itemName).value = value;
    }


    hideItem(itemName)
    {
        var item = document.getElementById(itemName);
        if(item === null)
        {
            alert("itemが見つかりませんでした。名前=" + itemName);
        }
        else
        {
            item.style.display="none";
        }
    }

    static isCheck(itemName)
    {
        return document.getElementById(itemName).checked;
    }


    getValue(itemName)
    {
        return document.getElementById(itemName).value;
    }


    wideWindow()
    {
        var g = this.layout.getGraphic(ChartBase.PRICE_GRAPHIC);
        var text = d3.select("#wide").text();
        if(text === "拡大")
        {
            this.width = 3700;
            this.layout.setFixAxisFlag(false);
            this.layout.changeCanvas(this.width,this.height);
            this.layout.setDomainX(g.candle2domainX(this.data));
            d3.select("#wide").text("縮小");
        }
        else
        {
            this.width = 1000;
            this.layout.setFixAxisFlag(true);
            this.layout.changeCanvas(this.width,this.height);
            this.layout.setDomainX(g.candle2domainX(this.data));
            d3.select("#wide").text("拡大");
        }

        this.layout.refreshCanvasSize();
        g.commonRefresh();
    }

    onAllDisSelect()
    {
        for(var i = 0; i < this.getCheckItems().length;i++)
        {
            this.setChecked(this.getCheckItems()[i],"");
        }

        this.plot();
    }


    onOpeChange(opeID)
    {
        this.layout.setMouseAction(opeID);
    }


    onLeftOffset()
    {
        this.oldBegin = this.begin;

        this.begin += Number(this.getValue('num'));

        this.reload();
    }

    onRightOffset()
    {
        this.oldBegin = this.begin;

        this.begin -= Number(this.getValue('num'));
        this.begin = Math.max(0,this.begin);


        this.reload();
    }

    onSpanChange()
    {
        this.reload();
    }

    onNumChange()
    {
        this.reload();
    }



    onPop()
    {
        this.layout.popMouseAction();
    }

    onDisplayChange()
    {
        this.plot();
    }


    onLoad()
    {
        var reader = new CookieReader(this.key + "@main");
        if(reader.length === 0)
        {
            return;
        }

        for(var i = 0; i < this.getCheckItems().length;i++)
        {
            reader.readCheck(this.getCheckItems()[i]);
        }

        reader.readValue('span');
        reader.readValue('num');

        this.layout.getDragInfo().load(this.key);
    }


    onSave()
    {
        var writer = new CookieWriter(this.key + "@main");
        for(var i = 0; i < this.getCheckItems().length;i++)
        {
            writer.writeCheck(this.getCheckItems()[i]);
        }


        writer.writeValue('span');
        writer.writeValue('num');


        this.layout.getDragInfo().save(this.key);

        alert("現在の状態を保存しました");
    }


    getCheckItems()
    {
        var result = [];
        d3.select("#hyouji")
          .selectAll("input")
          .each(function(d,i)
          {
              result.push(d3.select(this).attr("id"));
          });

        return result;
    }

    GetQueryString()
    {
        if (1 < document.location.search.length)
        {
            var query = document.location.search.substring(1);
            var parameters = query.split('&');
            var result = new Object();
            for (var i = 0; i < parameters.length; i++)
            {
                var element = parameters[i].split('=');
                var paramName = decodeURIComponent(element[0]);
                var paramValue = decodeURIComponent(element[1]);
                result[paramName] = decodeURIComponent(paramValue);
            }
            return result;
        }
        return null;
    }

    setChecked(itemName,checked)
    {
        var item = document.getElementById(itemName);
        item.checked = checked;
    }

    getChecked(itemName)
    {
        var item = document.getElementById(itemName);
        return item.checked;
    }

    loadCharts()
    {

    }


    plot(){
        this.layout.beginScene();

        this.loadCharts();

        for(var i = 0; i < this.charts.length; i++)
        {
            var chart = this.charts[i];
            chart.createGraphic(this.layout);
            chart.setOptions(this.options);
            chart.setData(this.data);
            if(chart instanceof FChartBase)
            {
                chart.setRawData(this.rawData);
                chart.setParam(this.param);
            }
        }
        this.layout.refreshCanvasSize();

        var graphics = this.layout.getGraphics();
        var graphic;


        for(i in graphics)
        {
            graphic = graphics[i];
            graphic.beginDraw();
        }

        for(i = 0; i < this.charts.length;i++)
        {
            chart = this.charts[i];
            chart.refresh();
        }


        for(i in graphics)
        {
            graphic = graphics[i];
            graphic.drawAxisX();
            graphic.drawAxisY();
            graphic.endDraw();
        }

        this.layout.endScene();
    }
}

module.exports = ScenarioBase;