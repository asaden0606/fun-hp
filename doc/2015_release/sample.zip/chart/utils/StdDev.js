"use strict";

/**
 * 標準偏差
 */
class StdDev
{
    /**
     * 標準偏差
     */
    static getStdDev(data) {
        var v = StdDev.getVariance(data);
        return Math.sqrt(v);
    }

    /**
     * 平均
     */
    static getMean(data) {
        var sum = data.reduce((a, b) => a + b, 0);
        return sum / data.length;
    }

    /**
     * 分散
     */
    static getVariance(data) {
        var mean = StdDev.getMean(data);
        var v = 0, m;

        data.forEach((d) => {
            m = (d - mean);
            v += m * m;
        });

        return v / data.length;
    }

    /**
     * 中央値
     */
    static getMedian(_data) {
        var data = _data.slice();

        data.sort((a, b) => a - b);

        var m, len = data.length;
        if (len % 2 === 0) {
            m = (data[(len/ 2) - 1] + data[len / 2]) / 2;
        } else {
            m = data[len / 2];
        }

        return m;
    }
}

module.exports = StdDev;