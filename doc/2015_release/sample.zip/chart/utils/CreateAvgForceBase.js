/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


/**
 * 平均データを作成する基底クラス
 * CreateAvgBaseは日時が規定値（例えば２５日平均線なら２５日）
 * に溜まっていなくても強引に線を生成する。
 */
class CreateAvgBase
{
    _create(samples)
    {
        var date = samples[samples.length - 1].date;
        var sum = this.toArray(samples[0]);

        for(var i = 1; i < samples.length; i++)
        {
            var addArr = this.toArray(samples[i]);
            for(var j = 0; j < sum.length; j++)
            {
                sum[j] += addArr[j];
            }
        }

        for(var k = 0; k < sum.length; k++)
        {
            sum[k] /= samples.length;
        }

        return this.toValue(date,sum);
    }

    toArray()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    toValue()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }




    create(datas,period)
    {
        var samples = [];
        var result = [];
        for(var i = 0;i < datas.length; i++)
        {
            samples.push(datas[i]);
            if(samples.length > period)
            {
                samples.shift();
            }


            var addItem = this._create(samples);
            if(addItem !== null)
            {
                result.push(addItem);
            }
        }

        return result;
    }
}

module.exports = CreateAvgBase;