/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var d3 = require('d3');

/**
 * 共通の便利メソッドの集約クラス
 */
class GraphicsUtils
{
    /**
     * 表示範囲内のデータを取得するメソッド
     */
    static findInnerDatas(left,right,x,datas)
    {
        var result = [];
        for(var i = 0; i < datas.length; i++)
        {
            var candle = datas[i];
            var screenX = x(candle.date);

            if(left <= screenX && screenX <= right)
            {
                result.push(candle);
            }
        }
        return result;
    }

    /**
     * Rangeを拡張するメソッド
     */
    static wideRange(range,scale)
    {
        var min = range[0];
        var max = range[1];
        var center = (min + max) / 2.0;
        var direction = max - center;


        var newMax = direction * scale + center;
        var newMin = -direction * scale + center;

        return [newMin,newMax];
    }

    /**
     * 最大値を取得するメソッド
     */
    static max(data,d)
    {
        return d3.max(data,d);
    }

    /**
     * 最小値を取得するメソッド
     */
    static min(data,d)
    {
        return d3.min(data,d);
    }

    /**
     * 表示を指定した範囲にクリップする
     */
    static clip(pos,left,right,top,bottom)
    {
        var x = pos[0];
        var y = pos[1];

        if(x < left)
        {
            x = left;
        }

        if(right < x)
        {
            x = right;
        }

        if(y < top)
        {
            y = top;
        }

        if(bottom < y)
        {
            y = bottom;
        }

        return [x,y];
    }

    /**
     * ローソク足の指定した範囲の最大値・最小値を取得するメソッド
     * 今思えば,d3.min,d3.max,d3.filterを使えば、楽できた・・・
     */
    static candle2MinMax(left,right,x,datas)
    {
        datas = GraphicsUtils.findInnerDatas(left,right,x,datas);



        var defaultMin = 1000000;
        var defaultMax = -1;
        var min = defaultMin;
        var max = defaultMax;
        for(var i = 0; i < datas.length; i++)
        {
            var candle = datas[i];
            var high = candle.high;
            var low = candle.low;

            if(min > low)
            {
                min = low;
            }

            if(max < high)
            {
                max = high;
            }
        }

        if(min === defaultMin || max === defaultMax)
        {
            return null;
        }
        else
        {
            return [min,max];
        }
    }
}


module.exports = GraphicsUtils;