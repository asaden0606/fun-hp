/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var d3 = require('d3');
var techan = require('techan');
var GraphicsBase = require('./GraphicsBase');


/**
 * Graphicsクラスと基本は同じようなクラス
 * Graphicsとの最大の違いはPopupはスクロールされても
 * 定位置で表示される。
 * また、Graphicsは横軸は時間軸であるが、
 * GraphicsPopupは横軸がスケール(0,1,2,3等)である。
 */
class GraphicsPopup extends GraphicsBase
{
    /**
     * どこにも寄せない
     */
    static get NONE_FIX() {
        return 0;
    }

    /**
     * 左寄せ
     */
    static get LEFT_FIX() {
        return 1;
    }

    /**
     * 右寄せ
     */
    static get RIGHT_FIX() {
        return 2;
    }

    /**
     * 上寄せ
     */
    static get TOP_FIX() {
        return 3;
    }

    /**
     * 下寄せ
     */
    static get BOTTOM_FIX() {
        return 4;
    }

    /**
     * 中央寄せ
     */
    static get CENTER_FIX() {
        return 5;
    }


    /**
     * コンストラクタ
     * なお、GraphicsPopupはスクリーン座標を用いない。
     * （様々な画面サイズに対応するため）
     * @layout レイアウト
     * @id 本オブジェクトのID
     * @xRatio X座標（0.0～1.0）
     * @yRatio Y座標(0.0～1.0)
     * @heightRatio 高さ(0.0～1.0)
     * @widthRatio 幅(0.0～1.0)
     * @xFix X座標の寄せ。LEFT,RIGHT,CENTER,NONEがある
     * @yFix Y座標の寄せ。TOP,BOTTOM,CENTER,NONEがある
     */
    constructor(layout,id,xRatio,yRatio,widthRatio,heightRatio,xFix,yFix)
    {
        super();
        this.margin = layout.getMargin();
        this.xRatio = xRatio;
        this.yRatio = yRatio;
        this.widthRatio = widthRatio;
        this.heightRatio = heightRatio;
        this.layout = layout;
        this.xFix = this.createFixX(xFix);
        this.yFix = this.createFixY(yFix);

        this.x = xRatio * this.layout.getDisplayWidth();
        this.y = yRatio * this.layout.getDisplayHeight();
        this.width = widthRatio * this.layout.getDisplayWidth();
        this.height = heightRatio * this.layout.getDisplayHeight();

        this.id = id;
        this.clipid = this.id + "_clip";



        this.scaleX = d3.scaleLinear()
                      .range([0,this.width]);

        this.scaleY = d3.scaleLinear()
                      .range([0,this.height]);


        this.noneClipSvg = layout.getNoneClipUserSvg()
                                 .append("g")
                                 .attr("id","none-cliped-" + id)
                                 .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");


        this.svg = layout.getClipUserSvg()
                         .append("g")
                         .attr("id","cliped-" + id)
                         .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")")
                         .attr("clip-path", "url(#" + this.clipid + ")");

        this.noneClipRect = this.svg.append("rect")
                        .attr("width",this.width)
                        .attr("x","1")
                        .attr("height",this.height)
                        .attr("class","popup_none_draw");


        this.axisScaleX = this.scaleX.copy()
                              .range([this.x,this.x + this.width]);

        this.axisScaleY = this.scaleY.copy()
                               .range([this.y,this.y + this.height]);

        this.defs = layout.getDefs();

        this.axisTop = d3.axisTop()
            .scale(this.axisScaleX)
            .tickSizeInner(-1 * this.height)
            .tickSizeOuter(0)
            .tickPadding(5)
            .ticks(5);



        this.axisBottom = d3.axisBottom()
                .scale(this.axisScaleX)
                .tickSizeInner(-1 * this.height)
                .tickSizeOuter(0)
                .tickPadding(5)
                .ticks(5);


        this.axisLeft = d3.axisLeft()
                .scale(this.axisScaleY)
                .tickSizeInner(-1 * this.width)
                .tickSizeOuter(0)
                .tickPadding(5)
                .ticks(5);

        this.axisRight = d3.axisRight()
                .scale(this.axisScaleY)
                .ticks(5)
                .tickSizeOuter(0);

        this.clipPathRect = this.defs.append("clipPath")
                .attr("id", this.clipid)
                .append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", this.width)
                .attr("height", this.height);

        this.annotationX = techan.plot.axisannotation()
                            .axis(this.axisBottom)
                            .format(d3.format('d'))
                            .orient('bottom')
                            .width(100)
                            .translate([0, this.height]);

        this.annotationY = techan.plot.axisannotation()
                        .axis(this.axisRight)
                        .orient('right')
                        .width(80)
                        .translate([0, 0]);


        this.candlestick = techan.plot.candlestick();
        this.drawAxisTopFlag = true;
        this.drawAxisLeftFlag = true;
        this.drawAxisRightFlag = true;
        this.drawAxisBottomFlag = true;

        this.create(this.svg);
    }

    /**
     * 縦軸の表示フォーマットを指定する
     */
    setAxisFormatY(format)
    {
        this.axisLeft.tickFormat(format);
        this.axisRight.tickFormat(format);
    }

    /**
     * 横軸の表示フォーマットを指定する
     */
    setAxisFormatX(format)
    {
        this.axisTop.tickFormat(format);
        this.axisBottom.tickFormat(format);
    }

    /**
     * 高さの割合を指定する
     */
    setHeightRatio(heightRatio)
    {
        this.heightRatio = heightRatio;
    }

    /**
     * 上にある横軸を表示するか指定する。
     */
    setDrawAxisTopFlag(flag)
    {
        this.drawAxisTopFlag = flag;
    }

    /**
     * 左にある縦軸を表示するか指定する。
     */
    setDrawAxisLeftFlag(flag)
    {
        this.drawAxisLeftFlag = flag;
    }

    /**
     * 右にある縦軸を表示するか指定する。
     */
    setDrawAxisRightFlag(flag)
    {
        this.drawAxisRightFlag = flag;
    }

    /**
     * 下にある横軸を表示するか指定する。
     */
    setDrawAxisBottomFlag(flag)
    {
        this.drawAxisBottomFlag = flag;
    }

    /**
     * 背景を描画する
     */
    drawBackground()
    {
        this.noneClipRect.attr("class","popup_draw");
    }


    /**
     * X座標の幅寄せの座標計算する。
     */
    createFixX(fix)
    {
        if(fix === GraphicsPopup.LEFT_FIX)
        {
            return new LeftFix();
        }
        else if(fix === GraphicsPopup.RIGHT_FIX)
        {
            return new RightFix();
        }
        else if(fix === GraphicsPopup.CENTER_FIX)
        {
            return new CenterX();
        }
        else
        {
            return new NoneFixX();
        }
    }

    /**
     * Y座標の幅寄せの座標計算する。
     */
    createFixY(fix)
    {
        if(fix === GraphicsPopup.TOP_FIX)
        {
            return new TopFix();
        }
        else if(fix === GraphicsPopup.BOTTOM_FIX)
        {
            return new BottomFix();
        }
        else if(fix === GraphicsPopup.CENTER_FIX)
        {
            return new CenterY();
        }
        else
        {
            return new NoneFixY();
        }
    }

    /**
     * GraphicsのIDを取得する
     */
    getID()
    {
        return this.id;
    }

    /**
     * Layoutを取得する
     */
    getLayout()
    {
        return this.layout;
    }

    /**
     * X座標の座標変換オブジェクトを取得する
     */
    getScaleX()
    {
        return this.scaleX;
    }

    /**
     * Y座標の座標変換オブジェクトを取得する
     */
    getScaleY()
    {
        return this.scaleY;
    }

    /**
     * X座標を取得する
     */
    getX()
    {
        return this.x;
    }

    /**
     * Y座標を取得する
     */
    getY()
    {
        return this.y;
    }

    /**
     * 幅を取得する
     */
    getWidth()
    {
        return this.width;
    }

    /**
     * 高さを取得する
     */
    getHeight()
    {
        return this.height;
    }

    /**
     * 描画開始メソッド
     */
    beginDraw()
    {
        this.svg
            .selectAll("g")
            .remove();


        this.noneClipSvg
            .selectAll("g")
            .remove();
    }

    /**
     * 描画終了メソッド
     */
    endDraw()
    {
        this.commonRefresh();
    }

    /**
     * X座標のアノテーションを取得するメソッド
     */
    getAnnotationX()
    {
        if(this.drawAxisBottomFlag)
        {
            return this.annotationX;
        }
        else
        {
            return null;
        }
    }

    /**
     * Y座標のアノテーションを取得するメソッド
     */
    getAnnotationY()
    {
        if(this.drawAxisRightFlag)
        {
            return this.annotationY;
        }
        else
        {
            return null;
        }
    }

    /**
     * X座標のドメインを設定するメソッド
     */
    setDomainX(x)
    {
        this.scaleX.domain(x);
        this.axisScaleX.domain(x);
    }

    /**
     * Y座標のドメインを設定するメソッド
     */
    setDomainY(y)
    {
        this.scaleY.domain(y);
        this.axisScaleY.domain(y);
    }

    /**
     * GraphicsPopupであるため、trueを返す
     */
    isPopup()
    {
        return true;
    }

    /**
     * データをソートするメソッド
     */
    sortByDate(data)
    {
        var accessor = this.candlestick.accessor();
        return data.sort(function(a, b)
        {
            return d3.ascending(accessor.d(a), accessor.d(b));
        });
    }

    /**
     * 共通の再描画メソッド
     */
    commonRefresh()
    {
        this.x = this.layout.getDisplayWidth() * this.xRatio;
        this.y = this.layout.getDisplayHeight() * this.yRatio;
        this.width = this.layout.getDisplayWidth() * this.widthRatio;
        this.height = this.layout.getDisplayHeight() * this.heightRatio;
        var rawLeft = this.xFix.calcPos(this,this.layout);
        var rawTop = this.yFix.calcPos(this,this.layout);
        var clipLeft = rawLeft + this.margin.left;
        var clipTop =  rawTop + this.margin.top;


        //this.noneClipSvg.attr("transform", "translate(" + clipLeft + "," + clipTop + ")");
        this.svg.attr("transform", "translate(" + clipLeft + "," + clipTop + ")");

        this.scaleX.range([0,this.width]);
        this.scaleY.range([0,this.height]);

        this.axisScaleX.range([rawLeft,rawLeft + this.width]);
        this.axisScaleY.range([rawTop,rawTop + this.height]);

        this.noneClipRect.attr("width",this.width)
                          .attr("height",this.height);

        this.axisTop.tickSizeInner(-1 * this.height);

        var top = rawTop;
        var left = rawLeft;
        var right = rawLeft + this.width;
        var bottom = rawTop + this.height;
        this.axisBottom.tickSizeInner(-1 * this.height);
        this.axisLeft.tickSizeInner(-1 * this.width);

        this.clipPathRect.attr("width", this.width)
                          .attr("height", this.height);

        this.noneClipSvg.select("g.axis.top")
                        .attr("transform", "translate(0," + top + ")")
                        .call(this.axisTop);

        this.noneClipSvg.select("g.axis.left")
                         .attr("transform", "translate(" + left + ",0)")
                         .call(this.axisLeft);

        this.noneClipSvg.select("g.axis.right")
                         .attr("transform", "translate(" + right + ",0)")
                         .call(this.axisRight);


        this.noneClipSvg.select("g.axis.bottom")
                         .attr("transform", "translate(0," + bottom + ")")
                         .call(this.axisBottom);


        this.annotationY
        .translate([rawLeft + this.width,0]);


        this.annotationX
        .translate([0, rawTop + this.height]);
    }

    /**
     * スククロールされた際に呼び出されるメソッド
     */
    onScroll()
    {
        this.commonRefresh();

        for(var i = 0; i < this.charts.length; i++)
        {
            var chart = this.charts[i];
            chart.onScroll();
        }

        this.commonRefresh();
    }

    /**
     * サイズが変更された際に呼び出されるメソッド
     */
    onResize()
    {
        this.commonRefresh();

        for(var i = 0; i < this.charts.length; i++)
        {
            var chart = this.charts[i];
            chart.onResize();
        }

        this.commonRefresh();
    }

    /**
     * 縦軸を描画するメソッド
     */
    drawAxisY()
    {
        if(this.drawAxisLeftFlag)
        {
            var posLeft = 0;
            this.noneClipSvg.append("g")
                    .attr("class", "axis left")
                    .attr("transform", "translate(" + posLeft + ",0)")
                    .call(this.axisLeft);
        }

        if(this.drawAxisRightFlag)
        {
            var posRight = this.width;
            this.noneClipSvg.append("g")
                    .attr("class", "axis right")
                    .attr("transform", "translate(" + posRight + ",0)")
                    .call(this.axisRight);
        }
    }

    drawTitle(text)
    {
        /*
        this.svg.append('text')
        .attr("class", "title")
        .attr("id",this.chartID)
        .attr("x", 10)
        .attr("y", 10)
        .text(text);
        */

    }


    /**
     * 横軸を描画するメソッド
     */
    drawAxisX()
    {
        if(this.drawAxisTopFlag)
        {
            var top = 0;
            this.noneClipSvg.append("g")
                .attr("class", "axis top")
                .attr("transform", "translate(0," + top + ")")
                .call(this.axisTop);
        }

        if(this.drawAxisBottomFlag)
        {
            var clipTop = this.yFix.calcPos(this,this.layout) + this.layout.getMargin().top;

            var bottom = clipTop + this.height;
            this.noneClipSvg.append("g")
                .attr("class", "axis bottom")
                .attr("transform", "translate(0," + bottom + ")")
                .call(this.axisBottom);
        }
    }
}

/**
 * 寄せをしない、ただ値をそのまま返すクラス
 */
class NoneFixX
{
    calcPos(g)
    {
        return g.x;
    }
}

/**
 * 寄せをしない、ただ値をそのまま返すクラス
 */
class NoneFixY
{
    calcPos(g)
    {
        return g.y;
    }
}

/**
 * X座標の中央寄せを行うクラス
 */
class CenterX
{
    calcPos(g)
    {
        var right = g.getDisplayRight();
        var left = g.getDisplayLeft();
        var width = g.width;
        var center = (left + right) / 2.0;
        return center - width / 2.0;
    }
}

/**
 * Y座標の中央寄せをおこなクラス
 */
class CenterY
{
    calcPos(g)
    {
        var center = g.layout.getHeight() / 2.0;

        return center - g.getHeight() / 2.0;
    }
}

/**
 * X座標の左寄せのクラス
 */
class LeftFix
{
    calcPos(g)
    {
        return g.x + g.getDisplayLeft();
    }
}

/**
 * X座標の右寄せのクラス
 */
class RightFix
{
    calcPos(g)
    {
        return g.getDisplayRight() - g.width - g.x;
    }
}

/**
 * Y座標の上寄せのクラス
 */
class TopFix
{
    calcPos(g)
    {
        return g.y;
    }
}


/**
 * Y座標の下寄せのクラス
 */
class BottomFix
{
    calcPos(g,layout)
    {
        return layout.getHeight() - g.height - g.y;
    }
}

module.exports = GraphicsPopup;