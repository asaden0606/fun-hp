/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');


/**
 * トレンドラインの選択状態時の動作
 */
class EnableYLineMode extends ModeBase
{
    addMouseOverLine(circle,line)
    {
        line.on("mouseover",  function(){ line.style("stroke", "red"); })
        .on("mouseout",   function(){ line.style("stroke", "skyblue");  });
    }

    addMouseOverCircle()
    {
    }

    addDragCircle()
    {
    }



    addDragLine(circle,line,text)
    {
        var t = this;
        line.call(d3.drag()
                .on("drag",function()
             {
             circle
                 .attr("cy",function(d) { return d.y += d3.event.dy; });


             line
                .attr("y1",function(d){return d.begin.y;})
                .attr("y2",function(d){return d.end.y;})
                    ;

             text
               .attr("y",function(d){return d.y;})
               .text(function(d){
                   var value = t.y.invert(d.y);
                   if(value === undefined)
                   {
                       return "";
                   }

                   return Math.round(value);
                 });
             })
       );
    }

    actionRect(parent,rect)
    {
        console.log("actionRect");

        var g = parent;
        if(rect === null)
        {
            return;
        }
        var start;
        rect.call(d3.drag()
                .on("start",function()
                {
                    start = d3.mouse(this);
                })
                .on("drag",function()
                {
                    var end = d3.mouse(this) ;
                    g.drawTempTrendline(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                })
                .on("end",function()
                {
                    var end = d3.mouse(this);
                    g.clearTemp();
                    g.pushData(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                    start = null;
                })
      );
    }

    actionItem(parent,group)
    {
        var line = group.selectAll("line");
        var circle = group.selectAll("circle");
        var text = group.selectAll("text");

        this.addMouseOverLine(circle,line);
        this.addDragLine(circle,line,text);
    }
}


module.exports = EnableYLineMode;