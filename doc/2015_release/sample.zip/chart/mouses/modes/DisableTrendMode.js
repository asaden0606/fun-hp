/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * トレンドラインの非選択状態時の動作
 */
class DisableTrendMode extends ModeBase
{
    addMouseOverLine(line)
    {
        line.on("mouseover", null)
            .on("mouseout",  null)
            .on("mousedown",null);
    }

    addMouseOverCircle(parent,circle)
    {
        circle.on("mouseover", null)
              .on("mouseout",  null);
    }

    addDragCircle(circle)
    {
        circle.call(d3.drag(),null);
    }

    addDragLine(line)
    {
        line.call(d3.drag(),null);
    }

    actionRect()
    {
        return;
    }

    actionItem(parent,group)
    {
        var line = group.selectAll("line");
        var circle = group.selectAll("circle");

        this.addMouseOverLine(line);
        this.addMouseOverCircle(parent,circle);

        this.addDragLine(line);
        this.addDragCircle(circle);
    }
}





module.exports = DisableTrendMode;