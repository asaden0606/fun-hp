/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');


/**
 * ペンタゴンの消去モード時の動作
 */
class ErasePentagonMode extends ModeBase
{
    addMouseOverLine(parent,group,data)
    {
        var edges = group.selectAll("line");
        var points = group.selectAll("#penta_points");
        var id = data.id;

        console.log(edges);
        var t = parent;
        edges
        .on("mouseover",function(){edges.style("stroke", "gray");points.style("fill", "gray");})
        .on("mouseout",function(){edges.style("stroke", "skyblue");points.style("fill", "skyblue");})
        .on("mousedown",function(){t.deleteData(id);});
    }

    addMouseOverPoint(parent,group)
    {
        var edges = group.selectAll("line");
        var points = group.selectAll("#penta_points");

        points
           .on("mouseover",function(){edges.style("stroke", "gray");points.style("fill", "gray");})
           .on("mouseout", function(){edges.style("stroke", "skyblue");points.style("fill", "skyblue");});
    }


    addMouseOverCircle(parent,group)
    {
        var circles = group.selectAll("#penta_circle");

        circles
           .on("mouseover",null)
           .on("mouseout", null)
           .on("click",null)
           .call(d3.drag(),null);
    }


    actionItem(parent,group,data)
    {
        console.log("on erase penta");
        this.addMouseOverLine(parent,group,data);
        this.addMouseOverPoint(parent,group,data);
        this.addMouseOverCircle(parent,group,data);
    }
}


module.exports = ErasePentagonMode;