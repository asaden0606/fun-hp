/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


var ModeBase = require('./ModeBase');
var d3 = require('d3');


/**
 * デフォルトのモード
 *
 */
class NoneMode extends ModeBase
{
    actionRect(parent,rect)
    {
        rect.call(d3.drag());
    }

    actionItem()
    {
        return;
    }
}


module.exports = NoneMode;