/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * 日柄の選択状態時の動作
 */
class EnableHigaraMode extends ModeBase
{
    actionRect(parent,rect)
    {
        var g = parent;
        var start;
        rect.call(d3.drag()
                      .on("start",function()
                      {
                          start = d3.mouse(this);
                      })
                      .on("drag",function()
                      {
                          var end = d3.mouse(this) ;
                          g.drawTempHigara(g.createHigaraData(end,start[0],start[1],end[0],end[1]));
                      })
                      .on("end",function()
                      {
                          var end = d3.mouse(this);
                          g.clearTemp();
                          g.pushData(g.createHigaraData(end,start[0],start[1],end[0],end[1]));
                          start = null;
                      })
            );
    }

    addDragEvent(parent,group,data)
    {
        var addLines = group.select("line");

        var hosoku = group.append("text");

        addLines
        .on("mouseover",  function(){
            var cur = d3.mouse(this);
            addLines.style("stroke", "red");
            hosoku
            .attr("x",cur[0])
            .attr("y",cur[1])
            .text("ドラッグでコピー");
        })
        .on("mousedown",null)
        .on("mouseout",   function(){
            addLines.style("stroke", "skyblue");
            hosoku.text("");
        });

        var start;
        var beginX = parent.x(data.start.date);
        var beginY = parent.y(data.start.value);
        var endX = parent.x(data.end.date);
        var endY = parent.y(data.end.value);

        var g = parent;

        addLines.call(d3.drag()
                  .on("start",function()
                  {
                      start = d3.mouse(this);
                  })
                  .on("drag",function()
                  {
                      var end = d3.mouse(this);
                      var sub = [end[0] - start[0],end[1] - start[1]];
                      g.drawTempHigara(g.createHigaraData(end,beginX + sub[0],beginY + sub[1],endX + sub[0],endY + sub[1]));
                  })
                  .on("end",function()
                  {
                      var end = d3.mouse(this);

                      var sub = [end[0] - start[0],end[1] - start[1]];

                      g.clearTemp();

                      g.pushData(g.createHigaraData(end,beginX + sub[0],beginY + sub[1],endX + sub[0],endY + sub[1]));
                      start = null;
                  })
            );
    }

    actionItem(parent,group,data)
    {
        this.addDragEvent(parent,group,data);
    }
}





module.exports = EnableHigaraMode;