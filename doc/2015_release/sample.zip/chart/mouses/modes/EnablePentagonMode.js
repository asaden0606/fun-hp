/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


var ModeBase = require('./ModeBase');
var d3 = require('d3');

const PI = 3.14;
const HANTEN_ISOU = 180 / 360 * 2 * PI;

/**
 * ペンタゴンの選択状態時の動作
 */
class EnablePentagonMode extends ModeBase
{
    actionRect(parent,rect)
    {
        var start;
        var g = parent;
        rect.call(d3.drag()
                      .on("start",function()
                      {
                          start = d3.mouse(g.svg.node());
                      })
                      .on("drag",function()
                      {
                          if(g.countItem() <= 0)
                          {
                              var end = d3.mouse(g.svg.node());
                              var sub = [end[0] - start[0],end[1] - start[1]];
                              g.drawTempPentagon(g.createPentagonData(end,start[0],start[1],sub[0],sub[1]));
                          }
                      })
                      .on("end",function()
                      {
                          if(g.countItem() <= 0)
                          {
                              var end = d3.mouse(g.svg.node());
                              var sub = [end[0] - start[0],end[1] - start[1]];
                              g.clearTemp();
                              g.pushData(g.createPentagonData(end,start[0],start[1],sub[0],sub[1]));
                          }
                      })
            );
    }


    addMouseOverLine(parent,group)
    {
        var edges = group.selectAll("line").filter(function(d){return d.click_flag;});

        var t = parent;
        edges
        .on("mouseover",  function(){ d3.select(this).style("stroke", "red"); })
        .on("mouseout",   function(){ d3.select(this).style("stroke", "skyblue");  })
        .on("mousedown",null)
        .on("click",function(d){

            var mx = (d.begin.x + d.end.x) / 2.0;
            var my = (d.begin.y + d.end.y) / 2.0;
            var newX = (mx - d.src.x) * 2 + d.src.x;
            var newY = (my - d.src.y) * 2 + d.src.y;


            t.pushData({
                x:newX,
                y:newY,
                radius:d.src.radius,
                isou:d.src.isou + HANTEN_ISOU,
                nears:[d.line_index]
            });

            d.src.nears.push(d.line_index);


            d3.select(this)
                .style("stroke","skyblue")
                .on("mouseover",null)
                .on("mouseout",null)
                .on("click",null);
        });
    }



    addMouseOverPoint(parent,group)
    {
        var points = group.selectAll("#penta_points");


        points
           .on("mouseover",  function(){ d3.select(this).style("fill", "red"); })
           .on("mouseout",   function(){ d3.select(this).style("fill", "skyblue");  });


        var start;
        var t = parent;
        var oldDataset;
        var oldPos;
        points.call(d3.drag()
                .on("start",function()
                {
                    start = d3.mouse(t.svg.node());
                    oldDataset = t.dataset.slice(0);
                    oldPos = start;
                })
                .on("drag",function(d)
                {
                    var newPos = d3.mouse(t.svg.node());
                    var sub = [newPos[0] - oldPos[0],newPos[1] - oldPos[1]];
                    t.onScale(start,newPos,sub,d,oldDataset);
                    oldPos = newPos;
                })
                .on("end",function()
                {

                })
              );
    }


    addMouseOverCircle(parent,group)
    {
        var circles = group.selectAll("#penta_circle");

        circles
           .on("mouseover",  function(){ d3.select(this).style("fill", "red"); })
           .on("mouseout",   function(){ d3.select(this).style("fill", "skyblue");  });

        var t = parent;

        circles.on("click",function()
        {
            if(t.dataset.length !== 1)
            {
                return;
            }

            t.dataset[0].isou += HANTEN_ISOU;

            t.refresh();
        }
        );

        var oldPos;
        circles.call(d3.drag()
                .on("start",function()
                {
                    oldPos = d3.mouse(t.svg.node());
                })
                .on("drag",function()
                {
                    var newPos = d3.mouse(t.svg.node());
                    var sub = [newPos[0] - oldPos[0],newPos[1] - oldPos[1]];
                    for(var i = 0; i < t.dataset.length;i++)
                    {
                        var item = t.dataset[i];
                        item.x += sub[0];
                        item.y += sub[1];
                    }

                    oldPos = newPos;

                    t.refresh();
                })
              );
    }


    actionItem(parent,group)
    {
        console.log("on enable penta");
        this.addMouseOverLine(parent,group);
        this.addMouseOverPoint(parent,group);
        this.addMouseOverCircle(parent,group);
    }
}



module.exports = EnablePentagonMode;