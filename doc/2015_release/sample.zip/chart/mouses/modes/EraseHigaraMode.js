/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * 日柄の消去モード時の動作
 */
class EraseHigaraMode extends ModeBase
{
    actionRect()
    {
    }

    addDragEvent(parent,group,data)
    {
        var lines = group.selectAll("line");
        var texts = group.selectAll("text");


        var t = parent;
        var id = data.id;
        lines
        .on("mouseover",function(){lines.style("stroke","gray");texts.style("fill","gray");})
        .on("mouseout", function(){lines.style("stroke","skyblue");texts.style("fill","skyblue");})
        .on("mousedown",function(){t.deleteData(id);})
        .call(d3.drag().on("drag",null));
    }

    actionItem(parent,group,data)
    {
        this.addDragEvent(parent,group,data);
    }
}




module.exports = EraseHigaraMode;