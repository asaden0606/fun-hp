/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";


/**
 * モードの基底クラス
 */
class ModeBase
{
    actionRect()
    {

    }

    actionItem()
    {

    }
}



module.exports = ModeBase;