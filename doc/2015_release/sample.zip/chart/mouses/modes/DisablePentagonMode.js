/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * ペンタゴンの非選択状態時の動作
 */
class DisablePentagonMode extends ModeBase
{
    actionRect()
    {
    }


    addMouseOverLine(parent,group)
    {
        var edges = group.selectAll("line").filter(function(d){return d.click_flag;});

        edges
        .on("mouseover",null)
        .on("mouseout", null)
        .on("mousedown", null)
        .on("click",null);
    }



    addMouseOverPoint(parent,group)
    {
        var points = group.selectAll("#penta_points");

        points
           .on("mouseover",null)
           .on("mouseout", null);
    }


    addMouseOverCircle(parent,group)
    {
        var circles = group.selectAll("#penta_circle");

        circles
           .on("mouseover",null)
           .on("mouseout", null)
           .on("click",null)
           .call(d3.drag(),null);
    }


    actionItem(parent,group)
    {
        console.log("on disable penta");
        this.addMouseOverLine(parent,group);
        this.addMouseOverPoint(parent,group);
        this.addMouseOverCircle(parent,group);
    }
}

module.exports = DisablePentagonMode;