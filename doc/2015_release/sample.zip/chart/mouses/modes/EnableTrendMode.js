/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * トレンドラインの選択状態時の動作
 */
class EnableTrendMode extends ModeBase
{
    addMouseOverLine(parent,line,hosoku)
    {
        line.on("mouseover",  function(){
            var pos = d3.mouse(this);

            line.style("stroke", "red");
            hosoku
            .attr("x",pos[0])
            .attr("y",pos[1])
            .text("ドラッグで平行線");
        })
        .on("mousedown",null)
        .on("mouseout",   function(){
            line.style("stroke", "skyblue");
            hosoku.text("");
        });
    }

    addMouseOverCircle(parent,circle)
    {
        circle.on("mouseover",  function(){ d3.select(this).style("fill", "rgba(255,0,0,1)"); })
              .on("mouseout",   function(){ d3.select(this).style("fill", "rgba(0,0,0,0)");  });
    }

    addDragCircle(parent,circle,line)
    {
        circle.call(d3.drag()
            .on("drag",function()
            {
                d3.select(this)
                    .attr("cx",function(d) { return d.x += d3.event.dx; })
                    .attr("cy",function(d) { return d.y += d3.event.dy; });

                line
                    .attr("x1",function(d){return d.begin.x;})
                    .attr("y1",function(d){return d.begin.y;})
                    .attr("x2",function(d){return d.end.x;})
                    .attr("y2",function(d){return d.end.y;});
            })
        );
    }

    addDragLine(parent,line)
    {
        var g = parent;
        var start;
        line.call(d3.drag()
              .on("start",function()
              {
                  start = d3.mouse(this);
              })
              .on("drag",function(d)
              {
                  var end = d3.mouse(this);
                  var beginX = d.begin.x;
                  var beginY = d.begin.y;
                  var endX = d.end.x;
                  var endY = d.end.y;
                  var sub = [end[0] - start[0],end[1] - start[1]];
                  g.drawTempTrendline(g.createTrendLineData(end,beginX + sub[0],beginY + sub[1],endX + sub[0],endY + sub[1]));
              })
              .on("end",function(d)
              {
                  var end = d3.mouse(this);
                  var sub = [end[0] - start[0],end[1] - start[1]];
                  var beginX = d.begin.x;
                  var beginY = d.begin.y;
                  var endX = d.end.x;
                  var endY = d.end.y;
                  g.clearTemp();
                  g.pushData(g.createTrendLineData(end,beginX + sub[0],beginY + sub[1],endX + sub[0],endY + sub[1]));
                  start = null;
              })
        );
    }

    actionRect(parent,rect)
    {
        var g = parent;
        if(rect === null)
        {
            return;
        }
        var start;
        rect.call(d3.drag()
                      .on("start",function()
                      {
                          start = d3.mouse(this);
                      })
                      .on("drag",function()
                      {
                          var end = d3.mouse(this) ;
                          g.drawTempTrendline(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                      })
                      .on("end",function()
                      {
                          var end = d3.mouse(this);
                          g.clearTemp();
                          g.pushData(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                          start = null;
                      })
            );
    }

    actionItem(parent,group)
    {
        var line = group.selectAll("line");
        var circle = group.selectAll("circle");
        var hosoku = group.selectAll("text");

        this.addMouseOverLine(parent,line,hosoku);
        this.addMouseOverCircle(parent,circle);

        this.addDragLine(parent,line,circle);
        this.addDragCircle(parent,circle,line);
    }
}






module.exports = EnableTrendMode;