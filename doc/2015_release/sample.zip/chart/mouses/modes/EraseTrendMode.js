/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * トレンドラインの消去モード時の動作
 */
class EraseTrendMode extends ModeBase
{
    addMouseOverLine(parent,group,data)
    {
        var line = group.selectAll("line");

        var t = parent;
        var id = data.id;
        line.on("mousedown",function(){t.deleteData(id);})
            .on("mouseover", function(){line.style("stroke","gray");})
            .on("mouseout",  function(){line.style("stroke","skyblue");})
            .call(d3.drag().on("drag",null));
    }


    actionItem(parent,group,data)
    {
        this.addMouseOverLine(parent,group,data);
    }
}

module.exports = EraseTrendMode;