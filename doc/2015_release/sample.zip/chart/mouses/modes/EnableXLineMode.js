/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');


/**
 * トレンドラインの選択状態時の動作
 */
class EnableXLineMode extends ModeBase
{
    addDragLine(circle,line,text)
    {
        var t = this;
        line.call(d3.drag()
                .on("drag",function()
             {
                 circle
                     .attr("cx",function(d) { return d.x += d3.event.dx; });


                 line
                    .attr("x1",function(d){return d.begin.x;})
                    .attr("x2",function(d){return d.end.x;});


                 text
                     .attr("x",function(d){return d.x;})
                     .text(function(d){
                         var dateTick = t.x.invert(d.x);
                         if(dateTick === undefined)
                         {
                             return "";
                         }
                         var date = new Date(dateTick);
                         var month = date.getMonth() + 1;
                         var dateText = month + "/" + date.getDate();

                         return dateText;
                        });
             })
       );
    }



    addMouseOverLine(line)
    {
        line.on("mouseover",  function(){ line.style("stroke", "red"); })
        .on("mouseout",   function(){ line.style("stroke", "skyblue");  });
    }

    addMouseOverCircle()
    {
    }

    addDragCircle()
    {
    }

    actionRect(parent,rect)
    {
        console.log("actionRect");

        var g = parent;
        if(rect === null)
        {
            return;
        }
        var start;
        rect.call(d3.drag()
                .on("start",function()
                {
                    start = d3.mouse(this);
                })
                .on("drag",function()
                {
                    var end = d3.mouse(this) ;
                    g.drawTempTrendline(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                })
                .on("end",function()
                {
                    var end = d3.mouse(this);
                    g.clearTemp();
                    g.pushData(g.createTrendLineData(end,start[0],start[1],end[0],end[1]));
                    start = null;
                })
          );
    }

    actionItem(parent,group)
    {
        var line = group.selectAll("line");
        var circle = group.selectAll("circle");
        var text = group.selectAll("text");

        this.addMouseOverLine(line);
        this.addDragLine(circle,line,text);
    }
}


module.exports = EnableXLineMode;