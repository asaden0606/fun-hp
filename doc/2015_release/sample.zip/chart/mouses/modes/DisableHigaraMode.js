/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var ModeBase = require('./ModeBase');
var d3 = require('d3');

/**
 * 日柄の非選択状態時の動作
 */
class DisableHigaraMode extends ModeBase
{
    actionRect()
    {
    }

    addDragEvent(parent,group)
    {
        var addLines = group.select("line");

        addLines
        .on("mouseover",  null)
        .on("mouseout",  null)
        .on("mousedown",null)
        .call(d3.drag(),null);
    }

    actionItem(parent,group)
    {
        this.addDragEvent(parent,group);
    }
}




module.exports = DisableHigaraMode;