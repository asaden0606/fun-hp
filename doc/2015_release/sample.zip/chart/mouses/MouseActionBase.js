/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var Events = require('../Events');
var NoneMode = require('./modes/NoneMode');

/**
 * トレンドライン等のマウス操作により、チャートを描く基底クラス
 */
class MouseActionBase
{
    constructor()
    {
        this.dataset = [];
        this.tempDrawID ="temp_draw";
        this.current_id = 0;
        this.id_header = "fix_";
        this.writeFlag = true;
        this.changeEvents = new Events();
        this.mode = new NoneMode();
    }

    /**
     * 次のIDを生成するメソッド
     */
    nextID()
    {
        var id = this.id_header + this.current_id;
        this.current_id++;
        return id;
    }

    /**
     * 数を取得するメソッド
     */
    countItem()
    {
        return this.dataset.length;
    }

    /**
     * データをバインドするメソッド
     */
    bind()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * データをアンバインドするメソッド
     */
    unbind()
    {
        this.changeEvents.clear();
    }

    /**
     * 文字列化するメソッド
     */
    toString()
    {
        var result = "";
        result += "writeFlag:";
        result += this.writeFlag;

        return result;
    }

    /**
     * 初期化済みであるかを判定するメソッド
     */
    isInit()
    {
        return this.getLayout() !== null;
    }

    /**
     * 書き込みフラグを設定するメソッド
     */
    setWriteFlag(flag)
    {
        this.writeFlag = flag;
    }

    /**
     * 書き込みフラグを取得するメソッド
     */
    getWriteFlag()
    {
        return this.writeFlag;
    }

    /**
     * SVGを取得するメソッド
     */
    getSvg()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * TEMPIDを取得するメソッド
     */
    getTempID()
    {
        return this.tempDrawID;
    }

    /**
     * 指定した直線と衝突するか判定するメソッド
     * トレンドラインブレークで用いる
     */
    isCollision()
    {
        return false;
    }

    /**
     * データを追加するメソッド
     */
    pushData(data)
    {
        var id = this.nextID();
        data["id"] = id;
        this.dataset.push(data);
        var group = this.drawData(data,id);
        this.mode.actionItem(this,group,data);
        this.changeEvents.event2(this,data);
    }

    /**
     * データを取得するメソッド
     */
    popData()
    {
        if(this.dataset.length <= 0)
        {
            return;
        }

        var data = this.dataset.pop();
        var deleteId = data.id;
        this.getSvg().selectAll("#" + deleteId)
                     .remove();

        this.changeEvents.event2(this,data);
    }

    deleteData(id)
    {
        var deleteIndex = this.findIndex(id);
        console.log("id=" + id + ",index=" + deleteIndex);
        if(deleteIndex === -1)
        {
            return;
        }


        this.dataset.splice(deleteIndex, 1);
        this.getSvg().selectAll("#" + id)
            .remove();


        this.changeEvents.event2(this,null);
    }


    findIndex(id)
    {
        for(var i = 0; i < this.dataset.length;i++)
        {
            if(this.dataset[i].id === id)
            {
                return i;
            }
        }

        return -1;
    }

    /**
     * データを有効化するメソッド
     */
    enable()
    {
        //console.log("enable:" + this.getName());
        this.mode = this.getEnableAction();
        if(this.rect !== null)
        {
            this.mode.actionRect(this,this.rect);
        }

        for(var i = 0; i < this.dataset.length; i++)
        {
            var data = this.dataset[i];
            var group = this.svg.select("#" + data.id);
            this.mode.actionItem(this,group,data);
        }
    }

    disable()
    {
        //console.log("disable:" + this.getName());
        this.mode = this.getDisableAction();
        for(var i = 0; i < this.dataset.length; i++)
        {
            var data = this.dataset[i];
            var group = this.svg.select("#" + data.id);
            this.mode.actionItem(this,group,data);
        }
    }

    erase()
    {
        //console.log("erase:" + this.getName());
        this.mode = this.getEraseAction();
        for(var i = 0; i < this.dataset.length; i++)
        {
            var data = this.dataset[i];
            var group = this.svg.select("#" + data.id);
            this.mode.actionItem(this,group,data);
        }
    }



    /**
     * データ表示を呼び出すメソッド
     */
    drawData()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }


    getEnableAction()
    {
        return new NoneMode();
    }

    getDisableAction()
    {
        return new NoneMode();
    }

    getEraseAction()
    {
        return new NoneMode();
    }

    /**
     * クラスの名前を取得するメソッド
     */
    getName()
    {
        throw new TypeError("このメソッドは必ず実装してね.");
    }

    /**
     * 再描画要求メソッド
     */
    refresh()
    {
        if(this.getSvg() === undefined || this.getSvg() === null)
        {
            return;
        }

        this.getSvg().selectAll("*").remove();
        if(this.writeFlag === false)
        {
            return;
        }

        for(var i = 0; i < this.dataset.length; i++)
        {
            var data = this.dataset[i];
            var group = this.drawData(data,data.id);
            this.mode.actionItem(this,group,data);
        }
    }

    /**
     * 表示左情報を取得するメソッド
     */
    getDisplayLeft()
    {
        return this.getLayout().getDisplayLeft();
    }

    /**
     * 表示右情報を取得するメソッド
     */
    getDisplayRight()
    {
        return this.getLayout().getDisplayRight();
    }

    /**
     * スクロールする際に呼び出されるメソッド
     */
    onScroll()
    {

    }

    /**
     * サイズ変更する際に呼び出されるメソッド
     */
    onResize()
    {

    }

    /**
     * データセットを消去するメソッド
     */
    clear()
    {
        this.dataset = [];
    }

    /**
     * 添付情報を消去するメソッド
     */
    clearTemp()
    {
        this.getSvg().selectAll("#" + this.tempDrawID)
                .remove();
    }

    /**
     * 情報を保存するメソッド
     */
    save()
    {
    }

    /**
     * 情報を読み込むメソッド
     */
    load()
    {
    }
}

module.exports = MouseActionBase;