"use strict";
var MouseActionBase = require('./MouseActionBase');
var d3 = require('d3');
var EnableYLineMode = require('./modes/EnableYLineMode');
var DisableTrendMode = require('./modes/DisableTrendMode');
var EraseTrendMode = require('./modes/EraseTrendMode');

class YLineMouseAction extends MouseActionBase
{
    constructor()
    {
        super();
        this.layout = null;
        this.rect = null;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.rect = rect;
    }



    getLayout()
    {
        return this.layout;
    }

    getSvg()
    {
        return this.svg;
    }

    getName()
    {
        return "yline";
    }



    printData(data,id)
    {
        var extent = d3.extent(this.x.domain());
        var circleDatas =
            [
                {
                    x:this.x(extent[0]),
                    y:this.y(data.value),
                    value:data.value,
                    pos:"left"
                },
                {
                    x:this.x(extent[1]),
                    y:this.y(data.value),
                    value:data.value,
                    pos:"right"
                }
            ];

        var linkDatas =[
            {
                begin:circleDatas[0],
                end:circleDatas[1]
            }
        ];

        var group = this.svg.append("g")
                         .attr("id",id);


        group.selectAll("line")
            .data(linkDatas)
            .enter()
            .append("line")
            .attr("class","trendline")
            .attr("x1", function(d) { return d.begin.x; })
            .attr("y1", function(d) { return d.begin.y; })
            .attr("x2", function(d) { return d.end.x; })
            .attr("y2", function(d) { return d.end.y; });

        group.selectAll("circle")
        .data(circleDatas)
        .enter()
        .append("circle")
        .attr("cx",function(d) { return d.x; })
        .attr("cy",function(d) { return d.y; })
        .attr("r","5")
        .style("fill","rgba(0,0,0,0)");


        var lay = this.layout;
        group.selectAll("text")
        .data(circleDatas)
        .enter()
        .append("text")
        .attr("y",function(d){return d.y;})
        .style("fill","skyblue")
        .style("font-weight","bold")
        .attr("id","yline_text")
        .text(function(d){return Math.round(d.value);})
        .attr("x",function(d){return d.x;})
        .attr("x",function(d){
                if(d.pos ===  "left")
                {
                    return lay.getDisplayLeft() + 10;
                }
                else
                {
                    return lay.getDisplayRight() - 50;
                }
            });

        return group;
    }

    drawData(data,id)
    {
        var group = this.printData(data,id);
        return group;
    }

    drawTempTrendline(data)
    {
        this.clearTemp();

        this.printData(data,this.getTempID());
    }

    clip(cur,min,max)
    {
        if(Math.abs(cur - min) < Math.abs(cur - max))
        {
            return min + 1;
        }
        else
        {
            return max - 1;
        }
    }

    onScroll()
    {
        if(this.layout === undefined)
        {
            return;
        }



        this.refresh();
    }

    onResize()
    {
        if(this.layout === undefined)
        {
            return;
        }

        this.x.range([0, this.layout.getWidth()]);
        this.refresh();
    }


    createTrendLineData(cur,inX1,inY1,inX2,inY2)
    {
        var y2 = this.y.invert(inY2);
        if(y2 === null)
        {
            y2 = this.y.invert(this.clip(cur[1],this.top,this.bottom));
        }

        return {
            value: y2
        };
    }

    getEnableAction()
    {
        return new EnableYLineMode();
    }

    getDisableAction()
    {
        return new DisableTrendMode();
    }

    getEraseAction()
    {
        return new EraseTrendMode();
    }



    save(writer)
    {
        writer.write("num",this.dataset.length);

        for(var i = 0; i < this.dataset.length;i++)
        {
            var data = this.dataset[i];

            var valueKey = "value_" + i;

            writer.write(valueKey,data.value);
        }
    }


    load(reader)
    {
        var num = reader.read("num");
        if(num === undefined)
        {
            return;
        }

        for(var i = 0; i < num;i++)
        {
            var valueKey = "value_" + i;

            var value = reader.read(valueKey);
            var id = this.nextID();


            this.dataset.push({
                value:Number(value),
                id:id
            });
        }
    }

}


module.exports = YLineMouseAction;