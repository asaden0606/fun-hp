/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var MouseActionBase = require('./MouseActionBase');
var EnableHigaraMode = require('./modes/EnableHigaraMode');
var DisableHigaraMode = require('./modes/DisableHigaraMode');
var EraseHigaraMode = require('./modes/EraseHigaraMode');


/**
 * 日柄カウンターの基底クラス
 */
class HigaraMouseActionBase extends MouseActionBase
{
    constructor()
    {
        super();
        this.dates = [];
        this.higaraID = "higara";
        this.layout = null;
        this.rect = null;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.dates = dates;
        this.rect = rect;
    }


    getLayout()
    {
        return this.layout;
    }

    getSvg()
    {
        return this.svg;
    }

    drawTempHigara(rawData)
    {
        this.clearTemp();
        this.printGroup(rawData,this.getTempID());
    }


    dupulicateLineData(data)
    {
        return [data];
    }



    drawData(rawData,id)
    {
        var g = this.printGroup(rawData,id);
        return g;
    }


    printGroup(rawData,id)
    {
        console.log(id);
        var group = this.svg.append("g")
                .attr("id",id);

        var lineDatas = this.dupulicateLineData(rawData);
        var writeFlag = false;
        for(var i = 0; i < lineDatas.length; i++)
        {
            var lines = this.toLine(lineDatas[i],i);
            if(lines !== null)
            {
                this.printLine(group,i,lines);
                writeFlag = true;
            }
        }

        if(writeFlag === false)
        {
            group.remove();
            return null;
        }
        else
        {
            return group;
        }
    }



    printLine(group,index,lineDatas)
    {
        var g = group.append("g")
                       .attr("id",index);


        g.selectAll("line")
          .data(lineDatas.line)
          .enter()
          .append("line")
          .attr("id","line_" + index)
          .attr("class", function(d){return d.classdata;})
          .attr("x1", function(d){return d.begin.x;})
          .attr("y1", function(d){return d.begin.y;})
          .attr("x2", function(d){return d.end.x;})
          .attr("y2", function(d){return d.end.y;})
          .style("stroke-width",function(d){return d.stroke;})
          .style("stroke","skyblue");


        g.append("text")
            .attr("x", (lineDatas.line[0].begin.x + lineDatas.line[0].end.x) / 2)
            .attr("y", (lineDatas.line[0].begin.y + lineDatas.line[0].end.y) / 2)
            .attr("class","higara")
            .style("fill","skyblue")
            .text(lineDatas.span);
        return g;
    }

    pushData(data)
    {
        if(data === null)
        {
            return;
        }

        var span = this.date2Index(data.start.date) - this.date2Index(data.end.date);
        if(span === 0)
        {
            return;
        }

        super.pushData(data);
    }

    toLine(data,index)
    {
        var height  = 1000;
        var index1 = this.date2Index(data.start.date);
        var index2 = this.date2Index(data.end.date);
        var span = Math.abs(index1 - index2) + 1;
        if(span === 1)
        {
            return null;
        }

        var drawdata =
            {
                begin:
                {
                    x:this.x(data.start.date),
                    y:this.y(data.start.value) + index * 30
                },
                end:
                {
                    x:this.x(data.end.date),
                    y:this.y(data.end.value) + index * 30
                },
                stroke:5,
                classdata:"higara_center"
            };

        var leftdata =
            {
                begin:
                {
                    x:this.x(data.start.date),
                    y:0
                },
                end:
                {
                    x:this.x(data.start.date),
                    y:height
                },
                stroke:2,
                classdata:"higara_side"
            };

        var rightdata =
            {
                begin:
                {
                    x:this.x(data.end.date),
                    y:0
                },
                end:
                {
                    x:this.x(data.end.date),
                    y:height
                },
                stroke:2,
                classdata:"higara_side"
            };

        return {
            span:span,
            line:[drawdata,leftdata,rightdata]
        };
    }

    clip(cur,min,max)
    {
        if(Math.abs(cur - min) < Math.abs(cur - max))
        {
            return min + 1;
        }
        else
        {
            return max - 1;
        }
    }


    span2Higara(span)
    {
        if(0 <= span)
        {
            return span + 1;
        }
        else
        {
            return span - 1;
        }
    }

    higara2Span(higara)
    {
        if(0 <= higara)
        {
            return higara - 1;
        }
        else
        {
            return higara + 1;
        }
    }

    date2Index(date)
    {
        for(var i = 0; i < this.dates.length; i++)
        {
            var x = this.dates[i];
            if(x.getTime() === date.getTime())
            {
                return i;
            }
        }

        return -1;
    }


    index2Date(index)
    {
        if(index < 0)
        {
            return this.dates[0];
        }
        else if(this.dates.length <= index)
        {
            return this.dates[this.dates.length - 1];
        }
        else
        {
            return this.dates[index];
        }
    }

    createHigaraData(cur,inX1,inY1,inX2,inY2)
    {
        var x1 = this.x.invert(inX1);
        var y1 = this.y.invert(inY1);
        var x2 = this.x.invert(inX2);
        var y2 = this.y.invert(inY2);

        if(x1 === null)
        {
            x1 = this.x.invert(this.clip(cur[0],this.left,this.right));
        }

        if(x2 === null)
        {
            x2 = this.x.invert(this.clip(cur[0],this.left,this.right));
        }

        if(y1 === null)
        {
            y1 = this.y.invert(this.clip(cur[1],this.top,this.bottom));
        }

        if(y2 === null)
        {
            y2 = this.y.invert(this.clip(cur[1],this.top,this.bottom));
        }

        if(x1 === null || x2 === null || y1 === null || y2 === null)
        {
            return null;
        }


        return {
            start: { date: x1, value: y1  },
            end:   { date: x2, value: y1  },
        };
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        this.refresh();
    }

    save(writer)
    {
        writer.write("num",this.dataset.length);

        for(var i = 0; i < this.dataset.length;i++)
        {
            var data = this.dataset[i];

            var startDateKey = "startDate_" + i;
            var startValueKey = "startValue_" + i;
            var endDateKey = "endDate_" + i;
            var endValueKey = "endValue_" + i;

            writer.write(startDateKey,data.start.date);
            writer.write(startValueKey,data.start.value);
            writer.write(endDateKey,data.end.date);
            writer.write(endValueKey,data.end.value);
        }
    }

    load(reader)
    {
        var num = reader.read("num");
        if(num === undefined)
        {
            return;
        }

        for(var i = 0; i < num;i++)
        {
            var startDateKey = "startDate_" + i;
            var startValueKey = "startValue_" + i;
            var endDateKey = "endDate_" + i;
            var endValueKey = "endValue_" + i;

            var startDate = reader.read(startDateKey);
            var startValue = reader.read(startValueKey);
            var endDate = reader.read(endDateKey);
            var endValue = reader.read(endValueKey);
            var id = this.nextID();


            this.dataset.push({
                start:{date:new Date(startDate),value:startValue},
                end:{date:new Date(endDate),value:endValue},
                id:id
            });
        }

        this.current_id = num;
    }

    getEnableAction()
    {
        return new EnableHigaraMode();
    }

    getDisableAction()
    {
        return new DisableHigaraMode();
    }

    getEraseAction()
    {
        return new EraseHigaraMode();
    }
}





module.exports = HigaraMouseActionBase;