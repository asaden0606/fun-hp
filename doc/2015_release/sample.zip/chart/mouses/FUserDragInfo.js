"use strict";

var YLineMouseAction = require('./YLineMouseAction');
var XLineMouseAction = require('./XLineMouseAction');
var UserDragInfo = require('./UserDragInfo');
var CookieWriter = require('../cookie/CookieWriter');
var CookieReader = require('../cookie/CookieReader');

class FUserDragInfo extends UserDragInfo
{
    static get YLINE()
    {
        return "yline";
    }

    static get XLINE()
    {
        return "xline";
    }

    constructor()
    {
        super();
        this.mouses[FUserDragInfo.XLINE] = new XLineMouseAction();
        this.mouses[FUserDragInfo.YLINE] = new YLineMouseAction();
    }

    save(inSaveKey)
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            var writer = new CookieWriter(inSaveKey + "@" + mouse.getName());
            mouse.save(writer);
        }
    }


    load(inSaveKey)
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            var reader = new CookieReader(inSaveKey + "@" + mouse.getName());
            mouse.load(reader);
        }
    }


}

module.exports = FUserDragInfo;