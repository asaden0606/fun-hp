/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var TrendlineMouseAction = require('./TrendlineMouseAction');
var HigaraMouseActionA = require('./HigaraMouseActionA');
var HigaraMouseActionB = require('./HigaraMouseActionB');
var HigaraMouseActionC = require('./HigaraMouseActionC');
var PentagonMouseAction = require('./PentagonMouseAction');
var EraseMouseAction = require('./EraseMouseAction');

/**
 * 各種MouseActionをラッパーするクラス
 */
class UserDragInfo
{
    static get TREND()
    {
        return 'trend';
    }

    static get HIGARA_A()
    {
        return 'higaraA';
    }

    static get HIGARA_B()
    {
        return 'higaraB';
    }

    static get HIGARA_C()
    {
        return 'higaraC';
    }

    static get PENTA()
    {
        return 'penta';
    }

    static get ERASE()
    {
        return 'erase';
    }

    erase()
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            mouse.erase();
        }
    }

    constructor()
    {
        this.mouses = {};
        this.mouses[UserDragInfo.TREND] = new TrendlineMouseAction();
        this.mouses[UserDragInfo.HIGARA_A] = new HigaraMouseActionA();
        this.mouses[UserDragInfo.HIGARA_B] = new HigaraMouseActionB();
        this.mouses[UserDragInfo.HIGARA_C] = new HigaraMouseActionC();
        this.mouses[UserDragInfo.PENTA] = new PentagonMouseAction();
        this.mouses[UserDragInfo.ERASE] = new EraseMouseAction(this);

        this.currentID = UserDragInfo.TREND;
    }

    get(id)
    {
        return this.mouses[id];
    }

    gets()
    {
        return this.mouses;
    }

    /**
     * 全情報に書き込みフラグを設定する
     */
    setWriteFlagAll(flag)
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            mouse.setWriteFlag(flag);
        }
    }

    /**
     * 書き込みフラグを設定する
     */
    setWriteFlag(id,flag)
    {
        this.mouses[id].setWriteFlag(flag);
    }

    /**
     * Layoutと本オブジェクトをバインドするメソッド
     */
    bind(layout,svg,x,y,dates,rect)
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            mouse.bind(layout,svg,x,y,dates,rect);
            mouse.refresh();
        }
    }

    /**
     * バインドを開放するメソッド
     */
    unbind()
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            mouse.unbind();
        }
    }

    /**
     * 衝突するか判定するメソッド
     * トレンドラインブレークで用いる
     */
    isCollision(begin,end)
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            if(mouse.isCollision(begin,end))
            {
                return true;
            }
        }

        return false;
    }




    getNames()
    {
        var result = [];
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            var name = mouse.getName();
            result.push(name);
        }

        return result;
    }

    onScroll()
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            if(mouse.isInit())
            {
                mouse.onScroll();
            }
        }
    }

    onResize()
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            if(mouse.isInit())
            {
                mouse.onResize();
            }
        }
    }

    refresh()
    {
        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            if(mouse.isInit())
            {
                mouse.refresh();
            }
        }
    }

    setCurrent(id)
    {
        if(this.currentID in this.mouses)
        {
            this.mouses[this.currentID].disable();
        }

        this.currentID = id;
        this.mouses[id].enable();
    }

    current()
    {
        return this.mouses[this.currentID];
    }

    toString()
    {
        var result = "";

        for(var key in this.mouses)
        {
            var mouse = this.mouses[key];
            result += "key:";
            result += key;
            result += "\n";
            result += mouse.toString();

            result +="\n";
        }

        return result;
    }
}

module.exports = UserDragInfo;