"use strict";
var MouseActionBase = require('./MouseActionBase');
var d3 = require('d3');
var EnableXLineMode = require('./modes/EnableXLineMode');
var DisableTrendMode = require('./modes/DisableTrendMode');
var EraseTrendMode = require('./modes/EraseTrendMode');


class XLineMouseAction extends MouseActionBase
{
    constructor()
    {
        super();
        this.layout = null;
        this.rect = null;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.rect = rect;
    }


    getLayout()
    {
        return this.layout;
    }

    getSvg()
    {
        return this.svg;
    }

    getName()
    {
        return "xline";
    }



    printData(data,id)
    {
        var circleDatas =
            [
                {
                    x:this.x(data.date),
                    y:this.layout.getHeight(),
                },
                {
                    x:this.x(data.date),
                    y:10
                }
            ];


        var linkDatas =[
            {
                begin:circleDatas[0],
                end:circleDatas[1],
                date:data.date
            }
        ];

        var group = this.svg.append("g")
                         .attr("id",id);


        group.selectAll("line")
            .data(linkDatas)
            .enter()
            .append("line")
            .attr("class","trendline")
            .attr("x1", function(d) { return d.begin.x; })
            .attr("y1", function(d) { return d.begin.y; })
            .attr("x2", function(d) { return d.end.x; })
            .attr("y2", function(d) { return d.end.y; });

        group.selectAll("circle")
        .data(circleDatas)
        .enter()
        .append("circle")
        .attr("cx",function(d) { return d.x; })
        .attr("cy",function(d) { return d.y; })
        .attr("r","5")
        .style("fill","rgba(0,0,0,0)");


        var t = this;
        group.selectAll("text")
             .data(circleDatas)
             .enter()
             .append("text")
             .attr("x",function(d){return d.x;})
             .attr("y",function(d){return d.y;})
             .style("fill","skyblue")
             .style("font-weight","bold")
             .text(function(d){
                 var dateTick = t.x.invert(d.x);
                 if(dateTick === undefined)
                 {
                     return "";
                 }
                 var date = new Date(dateTick);
                 var month = date.getMonth() + 1;
                 var dateText = month + "/" + date.getDate();

                 return dateText;
                });



        return group;
    }

    drawData(data,id)
    {
        return  this.printData(data,id);
    }






    drawTempTrendline(data)
    {
        this.clearTemp();

        this.printData(data,this.getTempID());
    }

    clip(cur,min,max)
    {
        if(Math.abs(cur - min) < Math.abs(cur - max))
        {
            return min + 1;
        }
        else
        {
            return max - 1;
        }
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        if(this.layout === undefined)
        {
            return;
        }

        this.x.range([0, this.layout.getWidth()]);
        this.refresh();
    }


    createTrendLineData(cur,inX1,inY1,inX2,inY2)
    {
        inX1 = inY1;
        inX1 = inY2;

        var x2 = this.x.invert(inX2);
        if(x2 === null)
        {
            x2 = this.x.invert(this.clip(cur[0],this.left,this.right));
        }
        return {
            date: x2
        };
    }

    getEnableAction()
    {
        return new EnableXLineMode();
    }

    getDisableAction()
    {
        return new DisableTrendMode();
    }

    getEraseAction()
    {
        return new EraseTrendMode();
    }

    save(writer)
    {
        writer.write("num",this.dataset.length);

        for(var i = 0; i < this.dataset.length;i++)
        {
            var data = this.dataset[i];

            var dateKey = "date_" + i;


            writer.write(dateKey,data.date);
        }
    }


    load(reader)
    {
        var num = reader.read("num");
        if(num === undefined)
        {
            return;
        }

        for(var i = 0; i < num;i++)
        {
            var dateKey = "date_" + i;
            var dateValue = reader.read(dateKey);
            var id = this.nextID();


            this.dataset.push({
                date:new Date(dateValue),
                id:id
            });
        }
    }
}


module.exports = XLineMouseAction;