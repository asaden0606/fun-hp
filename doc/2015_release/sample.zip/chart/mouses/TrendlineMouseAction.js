/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var MouseActionBase = require('./MouseActionBase');
var d3 = require('d3');
var EnableTrendMode = require('./modes/EnableTrendMode');
var DisableTrendMode = require('./modes/DisableTrendMode');
var EraseTrendMode = require('./modes/EraseTrendMode');

/**
 * トレンドラインのクラス
 */
class TrendlineMouseAction extends MouseActionBase
{
    constructor()
    {
        super();
        this.xRaw = d3.scaleLinear();
        this.layout = null;
        this.rect = null;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.rect = rect;
        this.xRaw.range([0, layout.getWidth()]);
        this.xRaw.domain(d3.extent(dates));
    }

    getLayout()
    {
        return this.layout;
    }

    getSvg()
    {
        return this.svg;
    }

    getName()
    {
        return "trend";
    }

    printData(data,id)
    {
        var circleDatas =
            [
                {
                    x:this.xRaw(data.start.date),
                    y:this.y(data.start.value)
                },
                {
                    x:this.xRaw(data.end.date),
                    y:this.y(data.end.value)
                }
            ];

        var linkDatas =[
            {
                begin:circleDatas[0],
                end:circleDatas[1]
            }
        ];

        var group = this.svg.append("g")
                         .attr("id",id);


        group.selectAll("line")
            .data(linkDatas)
            .enter()
            .append("line")
            .attr("class","trendline")
            .attr("x1", function(d) { return d.begin.x; })
            .attr("y1", function(d) { return d.begin.y; })
            .attr("x2", function(d) { return d.end.x; })
            .attr("y2", function(d) { return d.end.y; });

        group.selectAll("circle")
        .data(circleDatas)
        .enter()
        .append("circle")
        .attr("cx",function(d) { return d.x; })
        .attr("cy",function(d) { return d.y; })
        .attr("r","5")
        .style("fill","rgba(0,0,0,0)");

        group.append("text")
             .attr("id","hosoku");



        return group;
    }

    drawData(data,id)
    {
        return this.printData(data,id);
    }

    drawTempTrendline(data)
    {
        this.clearTemp();

        this.printData(data,this.getTempID());
    }

    clip(cur,min,max)
    {
        if(Math.abs(cur - min) < Math.abs(cur - max))
        {
            return min + 1;
        }
        else
        {
            return max - 1;
        }
    }

    onScroll()
    {
        this.refresh();
    }

    onResize()
    {
        if(this.layout === undefined)
        {
            return;
        }

        this.xRaw.range([0, this.layout.getWidth()]);
        this.refresh();
    }


    createTrendLineData(cur,inX1,inY1,inX2,inY2)
    {
        var x1 = this.xRaw.invert(inX1);
        var y1 = this.y.invert(inY1);

        var x2 = this.xRaw.invert(inX2);
        var y2 = this.y.invert(inY2);

        if(x1 === null)
        {
            x1 = this.xRaw.invert(this.clip(cur[0],this.left,this.right));
        }

        if(x2 === null)
        {
            x2 = this.xRaw.invert(this.clip(cur[0],this.left,this.right));
        }

        if(y1 === null)
        {
            y1 = this.y.invert(this.clip(cur[1],this.top,this.bottom));
        }

        if(y2 === null)
        {
            y2 = this.y.invert(this.clip(cur[1],this.top,this.bottom));
        }

        return {
            start: { date: x1, value: y1 },
            end:   { date: x2, value: y2 }
        };
    }





    toPos(data)
    {
        var x = this.xRaw(data.date);
        var y = this.y(data.value);

        return [x,y];
    }



    cross(ax,ay,bx,by,cx,cy)
    {
        return (by - ay) / (bx - ax) * cx + (ay - (by - ay) / (bx - ax) * ax) - cy;
    }


    _isCollision(a,b,c,d)
    {
        var cross1 = this.cross(a[0],a[1],b[0],b[1],c[0],c[1]);
        var cross2 = this.cross(a[0],a[1],b[0],b[1],d[0],d[1]);
        var cross3 = this.cross(c[0],c[1],d[0],d[1],a[0],a[1]);
        var cross4 = this.cross(c[0],c[1],d[0],d[1],b[0],b[1]);
        return cross1 * cross2 < 0 && cross3 * cross4 < 0;
    }

    isCollision(priceBegin,priceEnd)
    {
        for(var i = 0; i < this.dataset.length;i++)
        {
            var trendData = this.dataset[i];
            var trendBegin = this.toPos(trendData.start);
            var trendEnd = this.toPos(trendData.end);

            if(this._isCollision(priceBegin,priceEnd,trendBegin,trendEnd))
            {
                return true;
            }
        }

        return false;
    }

    getEnableAction()
    {
        return new EnableTrendMode();
    }

    getDisableAction()
    {
        return new DisableTrendMode();
    }

    getEraseAction()
    {
        return new EraseTrendMode();
    }


    save(writer)
    {
        writer.write("num",this.dataset.length);

        for(var i = 0; i < this.dataset.length;i++)
        {
            var data = this.dataset[i];

            var startDateKey = "startDate_" + i;
            var startValueKey = "startValue_" + i;
            var endDateKey = "endDate_" + i;
            var endValueKey = "endValue_" + i;

            writer.write(startDateKey,data.start.date);
            writer.write(startValueKey,data.start.value);
            writer.write(endDateKey,data.end.date);
            writer.write(endValueKey,data.end.value);
        }
    }

    load(reader)
    {
        var num = reader.read("num");
        if(num === undefined)
        {
            return;
        }

        for(var i = 0; i < num;i++)
        {
            var startDateKey = "startDate_" + i;
            var startValueKey = "startValue_" + i;
            var endDateKey = "endDate_" + i;
            var endValueKey = "endValue_" + i;
            var idKey = "id_" + i;

            var startDate = reader.read(startDateKey);
            var startValue = reader.read(startValueKey);
            var endDate = reader.read(endDateKey);
            var endValue = reader.read(endValueKey);
            var id = this.nextID();


            this.dataset.push({
                start:{date:startDate,value:startValue},
                end:{date:endDate,value:endValue},
                id:id
            });
        }
    }
}


module.exports = TrendlineMouseAction;