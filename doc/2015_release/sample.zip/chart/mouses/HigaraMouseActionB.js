/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var HigaraMouseActionBase = require('./HigaraMouseActionBase');

/**
 * 日柄カウンターBのクラス
 */
class HigaraMouseActionB extends HigaraMouseActionBase
{
    constructor()
    {
        super();
    }

    getName()
    {
        return "higaraB";
    }


    dupulicateLineData(inData)
    {
        var startDate = inData.start.date;
        var endDate = inData.end.date;
        var value = inData.start.value;


        var startIndex = this.date2Index(startDate);
        var span = this.date2Index(endDate) - this.date2Index(startDate);
        var higara = this.span2Higara(span);


        var endDate2 = this.index2Date(startIndex + this.higara2Span(higara * 2));
        var endDate3 = this.index2Date(startIndex + this.higara2Span(higara * 3));

        var data2 = {
            start:{date:startDate,value:value},
            end:{date:endDate2,value:value}
        };

        var data3 = {
            start:{date:startDate,value:value},
            end:{date:endDate3,value:value}
        };

        return [inData,data2,data3];
    }
}



module.exports = HigaraMouseActionB;