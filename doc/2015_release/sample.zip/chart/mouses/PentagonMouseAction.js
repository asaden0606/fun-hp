/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var MouseActionBase = require('./MouseActionBase');
var ErasePentagonMode = require('./modes/ErasePentagonMode');
var EnablePentagonMode = require('./modes/EnablePentagonMode');
var DisablePentagonMode = require('./modes/DisablePentagonMode');

var d3 = require('d3');

const PI = 3.14;
const HANTEN_ISOU = 180 / 360 * 2 * PI;
const KADO_NUM = 5;
const RADIUS_SCALE = 10;

/**
 * ペンタゴンチャートのクラス
 */
class PentagonMouseAction extends MouseActionBase
{
    constructor()
    {
        super();
        this.layout = null;
        this.rect = null;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.rect = rect;
        this.line = d3.line()
                .x(function(d) { return d.x; })
                .y(function(d) { return d.y; });

        var left = this.getDisplayLeft();
        this.svg.attr("transform", "translate(" + left + "," + 0 + ")");
    }

    getLayout()
    {
        return this.layout;
    }


    getSvg()
    {
        return this.svg;
    }

    getName()
    {
        return "pentagon";
    }


    onScale(start,end,sub,circle,oldDataset)
    {
        var newDataset = [];
        //半径の計算
        var zettaiSub = [end[0] - start[0],end[1] - start[1]];
        var radius = circle.src.radius * (1.0 + 0.01 * (zettaiSub[0] + zettaiSub[1]));
        radius = Math.max(radius,0);

        var cx = circle.src.x;
        var cy = circle.src.y;
        var scale = radius / oldDataset[0].radius;


        for(var i = 0; i < oldDataset.length;i++)
        {
            var d = oldDataset[i];
            var vecX = (d.x - cx);
            var vecY = (d.y - cy);
            var id = this.nextID();

            var lengthPow = (vecX * vecX) + (vecY * vecY);
            if(lengthPow === 0)
            {
                newDataset.push({
                    x:d.x,
                    y:d.y,
                    radius:radius,
                    isou:d.isou,
                    nears:d.nears,
                    id:id
                });
            }
            else
            {
                var length = Math.sqrt(lengthPow);

                var dirX = vecX / length;
                var dirY = vecY / length;

                var newX = cx + dirX * length * scale;
                var newY = cy + dirY * length * scale;


                newDataset.push({
                    x:newX,
                    y:newY,
                    radius:radius,
                    isou:d.isou,
                    nears:d.nears,
                    id:id
                });
            }
        }

        this.dataset = newDataset;

        this.refresh();
    }


    drawData(data,id)
    {
        var group = this.printPentagon(data,id);
        return group;
    }

    onScroll()
    {
        var left = this.getDisplayLeft();
        this.svg.attr("transform", "translate(" + left + "," + 0 + ")");
    }


    createPentagonLines(cx,cy,radius,isou,nears)
    {
        var src ={
            x:cx,
            y:cy,
            radius:radius,
            isou:isou,
            nears:nears
        } ;

        var i;

        //ポイントの付与
        var points = [];
        for (i = 0; i < KADO_NUM; i++)
        {
            var rad = 2 * i * PI / KADO_NUM - PI / 2 + isou;


            points.push({
                x:radius * Math.cos(rad) + cx,
                y:radius * Math.sin(rad) + cy,
                src:src
            });
        }


        //ラインの付与
        var lines = [];
        var lineIndex = 0;
        for(i = 0; i < KADO_NUM - 1; i++)
        {
            for(var j = 1; j < KADO_NUM; j++)
            {
                var pointBegin = points[i];
                var pointEnd = points[j];

                var edgeFlag = Math.abs(i - j) === 1 || j - i === KADO_NUM - 1;
                lines.push({
                    begin:pointBegin,
                    end:pointEnd,
                    click_flag:edgeFlag,
                    line_index:lineIndex,
                    stroke_width:edgeFlag?4 : 1,
                    src:src,
                });

                lineIndex++;
            }
        }
        for(i = 0; i < nears.length; i++)
        {
            lines[nears[i]].click_flag = false;
        }


        //巨大円の付与
        var circle = {
            src:src
        };


        //情報の付与
        var infoRad = (PI * 1 / 2 + isou);
        var infoRadius = radius * 0.8;


        return {
            info:{
                text:Math.round(radius / 10),
                x:cx + infoRadius * Math.cos(infoRad),
                y:cy + infoRadius * Math.sin(infoRad),
                src:src
            },

            circle:circle,
            points:points,
            lines:lines
        };
    }


    data2PentagonLines(data)
    {
        return this.createPentagonLines(data.x,data.y,data.radius,data.isou,data.nears);
    }


    printPentagon(data,id)
    {
        var group = this.svg.append("g")
        .attr("id",id);

        var penta = this.data2PentagonLines(data);
        if(penta === null)
        {
            return;
        }



        group.append("circle")
             .datum(penta.circle)
            .attr("id","penta_circle")
            .attr("cx",function(d) { return d.src.x; })
            .attr("cy",function(d) { return d.src.y; })
            .attr("r",function(d){return d.src.radius;})
            .style("fill","skyblue")
            .style("opacity","0.0")
            ;

        group.selectAll("line")
        .data(penta.lines)
        .enter()
        .append("line")
        .attr("id","penta_lines")
        .attr("x1", function(d){return d.begin.x;})
        .attr("y1", function(d){return d.begin.y;})
        .attr("x2", function(d){return d.end.x;})
        .attr("y2", function(d){return d.end.y;})
        .style("stroke-width",function(d){return d.stroke_width;})
        .style("stroke","skyblue");

        group.append("text")
        .attr("x", penta.info.x)
        .attr("y", penta.info.y)
        .style("fill","skyblue")
        .text(penta.info.text);

        group.selectAll("#penta_points")
        .data(penta.points)
        .enter()
        .append("circle")
        .attr("id","penta_points")
        .attr("cx",function(d) { return d.x; })
        .attr("cy",function(d) { return d.y; })
        .attr("r","5")
        .style("fill","skyblue");

        return group;
    }


    drawTempPentagon(data)
    {
        this.clearTemp();
        if(data === null)
        {
            return;
        }

        this.printPentagon(data,this.getTempID());
    }

    clip(cur,min,max)
    {
        if(Math.abs(cur - min) < Math.abs(cur - max))
        {
            return min + 1;
        }
        else
        {
            return max - 1;
        }
    }

    createPentagonData(cur,inStartX,inStartY,inSubX,inSubY)
    {
        var moveLengthPow = inSubX * inSubX + inSubY * inSubY;
        var moveLength = 0 < moveLengthPow?Math.sqrt(moveLengthPow) : 1;
        var hantenFlag = 0 < inSubY;
        return {
            x:inStartX,
            y:inStartY,
            radius:moveLength * RADIUS_SCALE,
            isou:hantenFlag ? HANTEN_ISOU : 0,
            nears:[]
        };
    }

    getEnableAction()
    {
        return new EnablePentagonMode();
    }

    getDisableAction()
    {
        return new DisablePentagonMode();
    }

    getEraseAction()
    {
        return new ErasePentagonMode();
    }


    save(writer)
    {
        writer.write("num",this.dataset.length);

        for(var i = 0; i < this.dataset.length;i++)
        {
            var data = this.dataset[i];

            var xKey = "x_" + i;
            var yKey = "y_" + i;
            var radiusKey = "radius_" + i;
            var isouKey = "isou_" + i;
            var nearsKey = "nears_" + i;

            writer.write(xKey,data.x);
            writer.write(yKey,data.y);
            writer.write(radiusKey,data.radius);
            writer.write(isouKey,data.isou);
            writer.write(nearsKey,data.nears);
        }
    }


    load(reader)
    {
        var num = reader.read("num");
        if(num === undefined)
        {
            return;
        }

        for(var i = 0; i < num;i++)
        {
            var xKey = "x_" + i;
            var yKey = "y_" + i;
            var radiusKey = "radius_" + i;
            var isouKey = "isou_" + i;
            var nearsKey = "nears_" + i;

            var x = reader.read(xKey);
            var y = reader.read(yKey);
            var radius = reader.read(radiusKey);
            var isou = reader.read(isouKey);
            var nears = reader.read(nearsKey);
            var id = this.nextID();


            nears = nears.split(",").map(function(d){return Number(d);});

            var addItem = {
                x:Number(x),
                y:Number(y),
                radius:Number(radius),
                isou:Number(isou),
                nears:nears,
                id:id
            };


            this.dataset.push(addItem);
        }
    }

}





module.exports = PentagonMouseAction;