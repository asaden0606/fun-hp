/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var HigaraMouseActionBase = require('./HigaraMouseActionBase');


/**
 * 日柄カウンターAのクラス
 */
class HigaraMouseActionA extends HigaraMouseActionBase
{
    constructor()
    {
        super();
    }

    getName()
    {
        return "higaraA";
    }

    dupulicateLineData(inData)
    {
        return [inData];
    }
}



module.exports = HigaraMouseActionA;