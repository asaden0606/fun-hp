/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";

var UserDragInfo = require('./UserDragInfo');

/**
 * UserDragクラスを管理するクラス
 * 銘柄を切り替えた際の、保存、復旧を行う。
 */
class UserDragManager
{
    constructor()
    {
        this.dragMaps = {};
    }

    /**
     * キー情報を生成するメソッド
     */
    getKey(options)
    {
        var meigara = options.get('ric');
        var hun = options.get('interval');

        return meigara + "@" + hun;
    }

    /**
     * Optionsの情報を元に、UserDragを取得するメソッド
     * もしデータが無かった場合は新規生成する
     */
    current(options)
    {
        var key = this.getKey(options);
        if(key in this.dragMaps)
        {
            //既存を取得
            return this.dragMaps[key];
        }
        else
        {
            //新規生成
            var addDrag =  new UserDragInfo();
            this.dragMaps[key] = addDrag;
            return addDrag;
        }
    }
}

module.exports = UserDragManager;