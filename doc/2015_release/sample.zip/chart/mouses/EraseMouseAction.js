/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var MouseActionBase = require('./MouseActionBase');

/**
 * 消去モードのクラス
 */
class EraseMouseAction extends MouseActionBase
{
    constructor(parent)
    {
        super();
        this.parent = parent;
    }

    bind(layout,svg,x,y,dates,rect)
    {
        this.layout = layout;
        this.svg = svg.select("#" + this.getName());
        this.x = x;
        this.y = y;
        this.rect = rect;
    }

    enable()
    {
        this.parent.erase();
        super.enable();
        //Eraseの肝！

    }

    getLayout()
    {
        return this.layout;
    }

    getSvg()
    {
        return this.svg;
    }

    getName()
    {
        return "erase";
    }

    drawData()
    {

    }
    onScroll()
    {
    }

    onResize()
    {
    }


    save()
    {
    }


    load()
    {

    }
}

module.exports = EraseMouseAction;
