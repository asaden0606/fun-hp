/**
 * Created by y.takahiro on 16/11/01.
 */
"use strict";
var GraphicsPopup = require('./GraphicsPopup');


/**
 * 新値足のように、横軸が時間以外のチャートに用いる。
 * 画面全体に表示される。
 */
class GraphicsFullPopup extends GraphicsPopup
{
    /**
     * コンストラクタ
     * フルスクリーンのため、余計なオプションも無し
     */
    constructor(layout,id)
    {
        super(layout,id,0,0,0.95,0.95,GraphicsPopup.LEFT_FIX,GraphicsPopup.TOP_FIX);

        this.setDrawAxisTopFlag(false);
        this.setDrawAxisBottomFlag(false);
    }
}

module.exports = GraphicsFullPopup;